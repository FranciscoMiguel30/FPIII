/**********************************************************************************************/
/* Ficheiro.: Analise.java																																		*/
/* Data.: 08 De Junho de 2016																																	*/
/* Autor.: Francisco André Miguel																															*/
/* Descricao.: Criar um sistema para gerenciar os Cliente e Contas de Um Banco								*/
/**********************************************************************************************/

/*
1. Definicao do Problema: Criar um sistema para gerenciar os Cliente e Contas de Um Banco com as seguintes funcionalidades:

1.1 Objectivo
   # Pretende-se desenvolver uma aplicacao para automatizar a gestao de clientes e contas.

2. Analise

2.1. Interface com o Utilizador
    #Formularios
			-Apresentacao
			-MenuPrincipal
			-Cliente
      -Funcionario
			-Conta
			-Deposito
			-Levantamento
			-Transferencia

    #Apresentacao
     *Não Concordo
      -sair do programa
     *Concordo
      -MenuPrincipal

    #MenuPrincipal
     *Ficheiro
      -Logout
      -Sair

     #Clientes
      -Inserir Cliente
      -Alterar/Editar
      -Eliminar
      -Listar

		 #Contas
			-Criar Nova Conta
			-Alterar/Editar
			-Eliminar
      -Consultar

     #Operacoes De Conta
			 	* Depositar
				* Levantamento
				* Transferencia
				* Extracto

      - Pesquisar
          *Pesquisar Cliente Por Nome
          *Pesquisar Cliente Por Numero Da Conta

			- Tabela
				* Provincias
				* Municipios
				* Bairros
				* TipoConta
        * Ordem De Deposito
        * Sexo
        * Estado Civil
        * Documento De Identificacao
        * Nacionalidade
        * Balcao

			- Ajuda
				* Sobre o Autor
				* Sobre o Sistema

2.2. Entidades Ligadas ao Interface Com o Utilizador (IU)

      - Entidade Pessoa
          atributo nome, apelido	                      : String
          atributo filiacao		                          : String
          atributo nacionalidade                        : Int
          atributo numeroDeContribuInte                 : String
          atributo residencia	        	                : MoradaModelo
          atributo dataNascimento	                      : DataModelo
          atributo contacto                             : String
          atributo sexo                                 : Int { MASCULINO, FEMENINO }
          atributo estadoCivil                          : Int { SOLTEIRO, CASADO, DIVORCIADO, VIUVO }
          atributo email                                : String
          atributo documentoId                          : Int { CARTA_DE_CONDUCAO, BILHETE_DE_IDENTIDADE, PASSAPORTE}
          atributo numeroDocumentoId                    : String
          atributo dataEmissao                          : DataModelo
          atributo habilitacao                          : Int {12ºClasse,Licenciatura,Mestrado,N/HA}
        FimPessoa

      Entidade DataModelo
  			* Atributo dia                                  :int
  			* Atributo mes                                  :String
  	  	* Atributo ano                                  :int
   		Fim DataModelo

      Entidade Cliente extensao Pessoa
        * atributo codigoCliente                        :int
      FimEntidadeCliente

      Entidade Funcionario extensao Pessoa
        * atributo codigoDoFuncionario 		              :int
      FimFuncionario

			- Entidade ContaModelo
        * Atributo numeroConta                          :int
        * Atributo CodigoTitutar1                       :ClienteModelo
        * Atributo titular1                             :ClienteModelo
        * Atributo CodigoTitutar2                       :ClienteModelo
        * Atributo titular1                             :ClienteModelo
        * Atributo CodigoTitutar3                       :ClienteModelo
        * Atributo titular2                             :ClienteModelo
        * Atributo saldo                                :Double
				* Atributo dataAbertura                         :DataModelo
        * Atributo tipoConta                            :int {Conjunta,Individual,...}
        * Atributo balcao                               :int {Cazenga,Rangel,...}
        * Atributo OrdemDeDeposito                      :int {USD,KZ,...}
        * Atributo codigoFuncionario                    :FuncionarioModelo
        * Atributo nomeFuncionario                      :FuncionarioModelo

      - Entidade Deposito
	    	* Atributo NumeroContaDepositar                 :numeroConta
	    	* Atributo NomeTitular                          :String
	    	* Atributo valorDeposito                        :Double
        * Atributo DataDeposito                         :DataModelo
	   	Fim Deposito

      - Entidade Levantamento
	    	 * Atributo NumeroContaLevantar                 :numeroConta
	    	 * Atributo NomeTitular                         :String
	    	 * Atributo saldoActual                         :Double
				 * Atributo valorLevantar                       :Double
				 * Atributo DataLevantar                        :DataModelo
	   	Fim Levantamento

      - Entidade Transferencia
    	    * Atributo NumeroContaLevantar                 :numeroConta
    	    * Atributo NomeTitular                         :Cliente
    		 	* Atributo NumeroContaDepositar                :numeroConta
    	    * Atributo saldoDisponivel                     :Double
        	* Atributo valorTransferir                     :Double
          * Atributo DataTransferencia                   :DataModelo
    	Fim Levantamento

	---------------------------------------------------------------------------------------------------

	2.3 Identificacao das Entidades Persistentes

				* Ficheiros de Dados
							Clientes.dat     ---->     ClientesModelo     ----->  Clientes.dat
              Funcionario.dat  ---->     FuncionarioModelo	----->  Funcionario.dat
              Contas.dat       ---->     ContasModelo   		----->  Contas.dat

				* Tabelas
						Provincias.tab
						Municipios.tab
						Bairros.tab
						TipoConta.tab
            OrdemDeDeposito.tab
            Sexo.tab
            dominioEmail.tab
            habilitacao.tab
            EstadoCivil.tab
            DocumentoDeIdentificacao.tab
            Nacionalidade.tab
            Balcao.tab

	3. Implementacao:

  		Implementado em java.

  4. Documentacao

    	# Java Como Programar 8 - Edicoes
    	# Manual On-Line do Java (API)
      # Data Structures and Algorithms with Object-Oriented Design Patterns in Java - Bruno R. Preiss
    	# Biblioteca de Classes de Java da FEUCAN

  *********************************************************************************************************************

 	6. Entrega ao Cliente:

  		Entregue Ao Professor Doutor Engenheiro Aires Veloso.

*/
