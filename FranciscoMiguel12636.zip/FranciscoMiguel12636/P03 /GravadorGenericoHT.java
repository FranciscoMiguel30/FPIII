/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package yb.hashtableyb;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

/**
 *
 * @author yuri
 */
public abstract  class GravadorGenericoHT
{
    /**
     * Posicao nula e representada por esse valor
     */
    private final long NULO = -1;

    /**
     * ProximoRegisto + Apagado
     */
    private final int TAMANHO_ADICIONL = 9;

    private long  proximaPosicao;
    private boolean apagado;
    private boolean overflow = false;
    private final String TMP_FILE= "tmp.yb";
    private String nomeDoFicheiro;
    private int tamanhoDaTabela;
    private int numeroDeRegistos;
    private Gravavel gravavel;

    public GravadorGenericoHT(String nomeDoFicheiro, int tamanhoDaTabela, Gravavel gravavel)
    {
        this.nomeDoFicheiro = nomeDoFicheiro;
        this.tamanhoDaTabela = tamanhoDaTabela;
        this.gravavel = gravavel;

        if( !estaInicializado() )
            initFicheiro(nomeDoFicheiro, tamanhoDaTabela,0);
    }


    private void initFicheiro( String nomeDoFile, int tamanhoTab, int numeroReg )
    {
        RandomAccessFile stream = null;

        try
        {
            stream = new RandomAccessFile(nomeDoFile, "rw");

            stream.writeInt(tamanhoTab);
            stream.writeInt(numeroReg);//Numero de elementos gravados;

            for( int i =0; i< tamanhoTab; i++ )
            {
                gravavel.gravarRegistoVazio(stream);
                stream.writeLong(NULO);//Proximo registo quando houver colisao
                stream.writeBoolean( true );//Esta apagado
            }


        }
        catch( IOException expt )
        {
            expt.printStackTrace();
        }
        finally
        {
            try
            {
                stream.close();
            }
            catch( IOException expto )
            {
                expto.printStackTrace();
            }
        }

    }



    private boolean estaInicializado()
    {

        RandomAccessFile stream = null;

        try
        {
            stream = new RandomAccessFile(nomeDoFicheiro, "rw");

            if( stream.length() > 0 )
                return true;

        }
        catch( IOException expt )
        {
            expt.printStackTrace();
        }
        finally
        {
            try
            {
                stream.close();
            }
            catch( IOException expto )
            {
                expto.printStackTrace();
            }
        }

        return false;
    }



    private long getPosicao( int i )
    {
        return ( i* ( gravavel.getSizeof()+ TAMANHO_ADICIONL ) )+8;
    }


    public Gravavel ler( Object key ) throws IOException
    {
        long posicao = getPosicao( calcularHashCode( ""+key ) );

        Gravavel gv = ler(posicao);

        if( apagado )
        {
            return null;
        }
        else if(!String.valueOf(gv.getChave()).equalsIgnoreCase(String.valueOf(key)) )//Em caso de colisao;
        {
            while( proximaPosicao != NULO )
            {
                gv = ler( proximaPosicao );
                if( String.valueOf(gv.getChave()).equalsIgnoreCase(String.valueOf(key)) )
                    return gv;

            }
            return null;
        }
        else
        {
            return gv;
        }


    }




    public Gravavel ler( long posicao ) throws IOException
    {
        RandomAccessFile stream = new RandomAccessFile(nomeDoFicheiro, "rw");
        Gravavel gv = gravavel.getNovaInstancia();
        gv = ler(posicao, stream);

        stream.close();

        return gv;
    }

    public Gravavel ler( long posicao, RandomAccessFile stream ) throws IOException
    {
        Gravavel gv = gravavel.getNovaInstancia();

        stream.seek(posicao);
        gv.lerRegisto( stream);
        stream.seek(posicao+gravavel.getSizeof());

        proximaPosicao = stream.readLong();
        apagado = stream.readBoolean();

        return gv;
    }


    public ArrayList<Gravavel> lerTodos() throws IOException
    {
        int tamanhoTab = getTamanhoDaTabela();

        ArrayList<Gravavel> lista = new ArrayList<Gravavel>();

        Gravavel gv;

        for( int i = 0; i < tamanhoTab; i++ )
        {
            gv = ler( getPosicao(i) );
            if( !apagado )
            {
                lista.add(gv);
            }
        }

        return lista;
    }



    public boolean gravar( Gravavel gv ) throws IOException
    {
        RandomAccessFile stream = new RandomAccessFile(nomeDoFicheiro, "rw");

        boolean gravou = gravar(gv, stream);

        stream.close();

        return gravou;
    }

    public boolean gravar( Gravavel gv, RandomAccessFile stream ) throws IOException
    {

        boolean gravou = false;
        long posicao = getPosicao( calcularHashCode( ""+gv.getChave() ) );

        Gravavel tmp = ler(posicao, stream);

        if( apagado )//Registo nao existente
        {
            stream.seek(posicao);

            gv.gravarRegisto(stream);

            stream.seek(posicao+gravavel.getSizeof());
            stream.writeLong(NULO);
            stream.writeBoolean(false);

            setNumeroDeRegistos( getNumeroDeRegistos() + 1 );
            gravou = true;
        }
        else
        {


            if( String.valueOf(tmp.getChave()).equalsIgnoreCase(String.valueOf(gv.getChave())) )//Registo ja existente
            {
                gravou = false;
            }
            else
            {
                gravou =   gravarColisao(gv, stream);//colisao
            }
        }

        verificarOverFlow( );

        return gravou;
    }


    private boolean gravarColisao( Gravavel gv, RandomAccessFile stream ) throws IOException
    {
        System.out.println(" ***Colisao***\n ");
        long posicao = getPosicao( calcularHashCode( ""+gv.getChave() ) );

        Gravavel tmp = ler(posicao, stream);

        while( proximaPosicao != NULO )
        {
            System.out.print(".");

            posicao = proximaPosicao;

            tmp = ler(proximaPosicao, stream);

            if( String.valueOf(tmp.getChave()).equalsIgnoreCase(String.valueOf(gv.getChave())) )
                return false;

        }

        long novaPosicao = getPosicaoLivre();

        stream.seek(novaPosicao);

        gv.gravarRegisto(stream);

        stream.seek(novaPosicao+gravavel.getSizeof());
        stream.writeLong(NULO);
        stream.writeBoolean(false);

        stream.seek(posicao+gravavel.getSizeof());
        stream.writeLong(novaPosicao);

        setNumeroDeRegistos( getNumeroDeRegistos() + 1 );
        return true;
    }


    private long getPosicaoLivre()throws IOException
    {
        long posicao = 0;
        for ( int i = getTamanhoDaTabela()-1; i > 0; i-- )
        {
            posicao = getPosicao(i);
            ler(posicao);
            if( apagado )
                break;
        }
        return posicao;
    }


    private void verificarOverFlow( ) throws IOException
    {
        double over = ((double)(getNumeroDeRegistos()  )/(double)getTamanhoDaTabela());

        //System.out.println("OVER-->" +over );

        if( over > 0.8 )
        {
            //stream.close();
            overflow = true;
            System.out.println("***ReHash***");

            int tamanhoAntigo=getTamanhoDaTabela();

            rehash(tamanhoAntigo * 2 );



        }
    }



    private void rehash( int tamanhoNovo )throws IOException
    {
            int tamanhoAntigo = getTamanhoDaTabela();

            initFicheiro( TMP_FILE, tamanhoNovo, getNumeroDeRegistos() );

            File x = new File(TMP_FILE);
            File tmp1 = new File("tmp1.yb");
            x.renameTo(tmp1);

            File y = new File( nomeDoFicheiro );
            File tmp2 = new File("tmp2.yb");
            y.renameTo(tmp2);

            tmp1.renameTo(new File( nomeDoFicheiro ));
            tmp2.renameTo(new File( TMP_FILE ));



            RandomAccessFile streamNovo = new RandomAccessFile(nomeDoFicheiro, "rw");

            RandomAccessFile streamAntigo = new RandomAccessFile(TMP_FILE, "rw");

            Gravavel tmpGravavel;

            for ( int i =0; i < tamanhoAntigo; i++ )
            {
                long posicao = getPosicao(i);

               tmpGravavel = ler( posicao, streamAntigo );




               if( !apagado )
               {
                   System.out.println("*REASH* A regravar a chave => "+tmpGravavel.getChave());
                   gravar(tmpGravavel, streamNovo);
               }

            }
            System.out.println();


            streamNovo.close();
            streamAntigo.close();



            File temporario = new File( TMP_FILE );
            //File antigo = new File(nomeDoFicheiro);


            temporario.delete();

    }


    public boolean remover( Object key ) throws IOException
    {
        Gravavel gv = ler(key);

        if( gv == null )
            return false;
        long posicao = getPosicao( calcularHashCode( ""+key ) );

        RandomAccessFile stream = new RandomAccessFile(nomeDoFicheiro, "rw");

        stream.seek(posicao+gravavel.getSizeof()+8);
        stream.writeBoolean(true);

        rehash(getTamanhoDaTabela());

        setNumeroDeRegistos( getNumeroDeRegistos()-1 );

        return true;
    }


    public boolean editar( Gravavel antigo, Gravavel novo ) throws IOException
    {
        return editar(antigo.getChave(), novo);
    }

    public boolean editar( Object keyAntigo, Gravavel novo ) throws IOException
    {
        Gravavel tmp = ler(novo.getChave());

        if( tmp != null && ( ! String.valueOf(keyAntigo).equalsIgnoreCase( String.valueOf( novo.getChave() ) ) ) )
        {
            if( String.valueOf(tmp.getChave()).equalsIgnoreCase( String.valueOf( novo.getChave() ) ) && !apagado )
                return false;
        }

        return remover(keyAntigo) && gravar(novo);
    }



    /**
     *
     * @param key Chave para calcular o hashcode.
     * @return Hashcode.
     */
    private int calcularHashCode(String key)
    {
        return  Math.abs(key.toUpperCase().hashCode()) % getTamanhoDaTabela();
    }




    private int getNumeroDeRegistos()
    {
        RandomAccessFile stream = null;

        try
        {
            stream = new RandomAccessFile(nomeDoFicheiro, "rw");
            stream.seek(4);

            numeroDeRegistos = stream.readInt();

        }
        catch( IOException expt )
        {
            numeroDeRegistos = -1;
            expt.printStackTrace();
        }
        finally
        {
            try
            {
                stream.close();
            }
            catch( IOException expto )
            {
                expto.printStackTrace();
            }
        }
        return numeroDeRegistos;
    }


    private void setNumeroDeRegistos(int numeroDeRegistos)
    {
        RandomAccessFile stream = null;

        try
        {
            stream = new RandomAccessFile(nomeDoFicheiro, "rw");
            stream.seek(4);

            stream.writeInt(numeroDeRegistos);

        }
        catch( IOException expt )
        {

            expt.printStackTrace();
        }
        finally
        {
            try
            {
                stream.close();
            }
            catch( IOException expto )
            {
                expto.printStackTrace();
            }
        }

    }


    private int getTamanhoDaTabela()
    {
        RandomAccessFile stream = null;

        try
        {
            stream = new RandomAccessFile(nomeDoFicheiro, "rw");
            stream.seek(0);

            tamanhoDaTabela = stream.readInt();

        }
        catch( IOException expt )
        {
            tamanhoDaTabela = -1;
            expt.printStackTrace();
        }
        finally
        {
            try
            {
                stream.close();
            }
            catch( IOException expto )
            {
                expto.printStackTrace();
            }
        }
        return tamanhoDaTabela;
    }

    private void setTamanhoDaTabela(int tamanhoDaTabela)
    {
        RandomAccessFile stream = null;

        try
        {
            stream = new RandomAccessFile(nomeDoFicheiro, "rw");
            stream.seek(0);

            stream.writeInt(tamanhoDaTabela);

        }
        catch( IOException expt )
        {

            expt.printStackTrace();
        }
        finally
        {
            try
            {
                stream.close();
            }
            catch( IOException expto )
            {
                expto.printStackTrace();
            }
        }
    }








}
