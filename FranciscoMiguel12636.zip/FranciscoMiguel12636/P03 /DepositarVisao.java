
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: DepositarVisao.java
**	Objectivo: Fazer a operacao De Deposito De Uma Conta
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import java.util.regex.*;
import yb.hashtableyb.GravadorGenericoHT;
import java.io.*;

public class DepositarVisao extends JFrame
{
  private JComboBox numeroContaDepositarJcb;
  private JTextField nomeTitularJtf,valorDepositoJtf;
  private JTextFieldData dataDepositarJtfd;
  private JPanel painelCentro,painelBotoes;
  private JButton okJb,limparJb,cancelJb;
  private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
  private GravadorContaModelo gravador = new GravadorContaModelo();

  public DepositarVisao ()
  {
      super("Deposito - BFA");
      geraPainelCentro();
      geraPainelBotoes();
      Container ct = this.getContentPane();
      ct.add(painelCentro, BorderLayout.CENTER);
      ct.add(painelBotoes, BorderLayout.SOUTH);
      pack ();
      //setSize(300, 200);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
      setLocationRelativeTo ( null );
      setVisible(true);
      TrataEventos eventos = new TrataEventos ();
      okJb.addActionListener (eventos);

      numeroContaDepositarJcb.addActionListener ( new EventoComboBox ( ) );
      limparJb.addActionListener (eventos);
      cancelJb.addActionListener (eventos);
  }

  public String getValorDeposito ()
  {
    return valorDepositoJtf.getText ().toString ().trim ();
  }

  public String getNumeroContaDepositar ()
  {
    return numeroContaDepositarJcb.getSelectedItem ().toString ();
  }

  public String getDataDepositar ()
  {
    return dataDepositarJtfd.getDTestField ().getText ().toString ().trim ();
  }

  public void geraPainelCentro()
  {
    painelCentro = new JPanel();
    painelCentro.setLayout(new GridLayout( 4,1));

    addNumeroContaDepositar ();
    addNomeTitular ();
    addValorDeposito ();
    addDataAbertura ();
  }


  public JPanel createPanelDataDepositar()
  {
    JPanel panel = new JPanel();
    panel.setLayout(new GridLayout(1, 2));
    dataDepositarJtfd = new JTextFieldData ("");
    panel.add (dataDepositarJtfd.getDTestField());
    panel.add (dataDepositarJtfd.getDButton());
    return panel;
  }

  private class EventoComboBox implements ActionListener
  {
    public void actionPerformed ( ActionEvent evento )
    {
      if ( evento.getSource ( ) ==  numeroContaDepositarJcb)
      {
          preencherNomeClienteModelo ( nomeDoClienteModelo ( numeroContaDepositarJcb.getSelectedItem ().toString ().trim ()));
      }
    }
  }

  public Vector<String> carregarNumeroConta()
  {
    Vector<String> listaNumeroConta = new Vector<String>();

    try
    {
       ContaModelo modelo;
       lista = gravador.lerTodos();
       for(Gravavel gravavel : lista)
       {
         modelo = (ContaModelo) gravavel;
         listaNumeroConta.add(modelo.getNumeroConta());
       }
       ordenarComboBox ( listaNumeroConta );
     }catch(IOException e){}
    return listaNumeroConta;
  }

  public ContaModelo nomeDoClienteModelo ( String numeroConta )
  {

    try
    {
       lista = gravador.lerTodos();
       ContaModelo modelo;
       for(Gravavel gravavel : lista)
       {
         modelo = (ContaModelo) gravavel;
         //JOptionPane.showMessageDialog (null,"nome ComboBox : " + nome + "nome File" + modelo.getNomeCompleto () );
         if (numeroConta.equals (modelo.getNumeroConta ()))
            return modelo;
       }
     }catch(IOException e){}

    return new ContaModelo ( );
  }

  public void preencherNomeClienteModelo ( ContaModelo clienteConta )
  {
    nomeTitularJtf.setText ("" + clienteConta.getNomeCompleto ( ) );
  }

  public void addDataAbertura ()
  {
    painelCentro.add( new JLabel ("Data do Deposito"));
    painelCentro.add(createPanelDataDepositar());
  }

  public void addNumeroContaDepositar ()
  {
    painelCentro.add (new JLabel ("Numero Da Conta A Depositar"));
    numeroContaDepositarJcb = new JComboBox (carregarNumeroConta ());
    painelCentro.add (numeroContaDepositarJcb);
  }

  public void addNomeTitular ()
  {

    painelCentro.add(new JLabel ("Titular"));
    nomeTitularJtf = new JTextField ();
    nomeTitularJtf.setEnabled (false);
    painelCentro.add(nomeTitularJtf);
  }

  public void addValorDeposito ()
  {

    painelCentro.add(new JLabel ("Valor Do Deposito"));
    valorDepositoJtf = new JTextField ();
    painelCentro.add(valorDepositoJtf);
  }

  public void geraPainelBotoes()
  {
    painelBotoes = new JPanel();
    okJb = new JButton("Ok");
    limparJb = new JButton("Limpar");
    cancelJb = new JButton("Cancelar");
    painelBotoes.setLayout(new FlowLayout());
    painelBotoes.add(okJb);
    painelBotoes.add(limparJb);
    painelBotoes.add(cancelJb);
  }

  public void depositoConta ()
  {
    ContaModelo modelo = new ContaModelo ();
    try
    {
      if (validarCampos ())
      {
        modelo = (ContaModelo) gravador.ler(getNumeroContaDepositar());
        if (modelo != null)
        {
         //JOptionPane.showMessageDialog (null,"nome ComboBox : " + nome + "nome File" + modelo.getNomeCompleto () );
         if (getNumeroContaDepositar ().equals (modelo.getNumeroConta ()))
            {
               try
               {
                 double valor1 = Double.parseDouble (modelo.getSaldoConta ());
                 double valor2 = Double.parseDouble ( getValorDeposito () );
                 double total = valor1 + valor2;
                 modelo.setSaldoConta ("" + total);
                 modelo.setDataDepositar ("" + getDataDepositar ());
                 gravador.editar(modelo.getNumeroConta (), modelo);

                // new DepositaExtractoControlo ();

                 //extracto.seeExtracto ();
                 JOptionPane.showMessageDialog (null,"Deposito Efectuado Com Sucesso","Informacao",JOptionPane.INFORMATION_MESSAGE);
               }catch (NumberFormatException ex)
               {
                 JOptionPane.showMessageDialog (null,"Error Digite Um Numero Meu Caro","Error",JOptionPane.ERROR_MESSAGE);
               };
            }
          }
        }
    }catch(IOException e){}
  }

  /*public void extractoDeposito(String saldo){
    String op = "Deposito";
    ExtratoModelo mod = new ExtratoModelo();
    GravadorExtracto gravador = new GravadorExtracto();

    mod.setNumExtracto(""+geraNumExtracto());
    incrementaNumExctrato(geraNumExtracto());
    mod.setNome(jtfNomeTitular.getText().trim());
    mod.setNumConta(jtfNumConta.getText().trim());
    mod.setDataOperacao(txfdataLevant.getDTestField().getText());
    mod.setTipoOperacao(op);
    mod.setSaldoActual(saldo);
    mod.setValor(jtfValorLevantar.getText().trim());

    try{
           boolean validar = gravador.gravar( mod );
           if( validar )
           {
             ste +="Extracto criado com sucesso";
           }
           else
            {
                   JOptionPane.showMessageDialog(null, "Chave de extrato ja existente!", "Erro!",JOptionPane.ERROR_MESSAGE);
            }
    }catch(IOException exc){
      JOptionPane.showMessageDialog(this, "Ocorreu um erro ao criar o extracto");
    }
  }*/

  public Boolean validarCampos ()
  {
    if (nomeTitularJtf.getText ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite O Nome Do Titular A Depositar","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if (valorDepositoJtf.getText ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite O Valor A Depositar","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if (dataDepositarJtfd.getDTestField ().getText ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite A Data A Depositar","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    return true;
  }
  public void limparFormulario()
  {
    dataDepositarJtfd.setDtestField("");
    nomeTitularJtf.setText("");
    valorDepositoJtf.setText("");
  }//Fim do metodo limparFormulario()--------------------------------------------------------

  // metodo Para Ordenar Um Vector
  public JComboBox ordenarComboBox ( Vector vectorItens)
  {
    Collections.sort ( vectorItens );

    return new JComboBox ( vectorItens );
  }//Fim do metodo ordenarComboBox()

  private class TrataEventos implements ActionListener
  {
      public void actionPerformed(ActionEvent evento)
      {
          if (evento.getSource() == okJb)
          {
              depositoConta ();
          }//Fim Botao Salvar--------------------------------------------------------

          else if (evento.getSource() == cancelJb)
          {
              dispose();
          }//Fim Botao cancelar--------------------------------------------------------

          else if (evento.getSource() == limparJb)
          {
              limparFormulario();
          }//Fim Botao Limpar -------------------------------------------------------
      }
    }//Fim Da Classe TrataEventos -----------------------------------------------------
}
