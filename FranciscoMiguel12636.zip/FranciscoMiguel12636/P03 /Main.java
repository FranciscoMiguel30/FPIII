
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: Login.java
**  Nome: Francisco André Miguel
**	Data: 8 de Junho de 2016
**	Numero: 12636
*********************************************************************************************************************
********************************************************************************************************************/



	import javax.swing.*;
	import javax.swing.event.*;

	import java.awt.*;
	import java.awt.event.*;


	import javax.swing.UIManager;

	public class Main
	{


		public static void main ( String args [ ] )
		{

			try
     {
       //UIManager.setLookAndFeel ("javax.swing.plaf.metal.MetalLookAndFeel");
       //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
       UIManager.setLookAndFeel ("javax.swing.plaf.nimbus.NimbusLookAndFeel");
       //UIManager.setLookAndFeel ("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
       //UIManager.setLookAndFeel ("com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); // Não é suportado no ubunto
			 Vector_Tabelas.inic();
 			new ApresentacaoVisao ();
		 }
     catch (Exception ex)
     {
       System.out.println (""+ex.getMessage ());
     }


		}
	}
