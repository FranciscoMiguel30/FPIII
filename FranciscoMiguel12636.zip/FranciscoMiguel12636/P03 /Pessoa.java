/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: Pessoa.java
**	Objectivo: Classe que serão extendidas pelos Clientes e Funcionario
**  Nome: Francisco André Miguel
**	Data: 15 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.*;
import java.io.RandomAccessFile;
import java.io.IOException;
import yb.hashtableyb.*;

public class Pessoa
{
	protected StringBufferModelo numeroBi;
	protected StringBufferModelo nomeCompleto,apelido, numeroDeContribuinte, estadoCivil,dominioEmail;
	protected StringBufferModelo dataDeNascimento, provincia, municipio, bairro,habilitacao;
	protected StringBufferModelo nomeDoPai, nomeDaMae, nacionalidade, email, sexo, telefone,documentoId,dataEmissao;

    public Pessoa(String numeroBi,String apelido, String nomeCompleto, String numeroDeContribuinte,String dominioEmail,
											   String estadoCivil,String dataDeNascimento, String provincia, String municipio, String bairro,
                     		 String nomeDoPai, String nomeDaMae, String nacionalidade, String email, String sexo, String telefone,
												 String documentoId,String dataEmissao,String habilitacao)
    {
        setNumeroBi(numeroBi);
        setNomeCompleto(nomeCompleto);
				setApelido(apelido);
        setNumeroDeContribuinte(numeroDeContribuinte);
				setDominioEmail(dominioEmail);
        setEstadoCivil(estadoCivil);
        setDataDeNascimento(dataDeNascimento);
        setProvincia(provincia);
        setMunicipio(municipio);
        setBairro(bairro);
        setNomeDoPai(nomeDoPai);
        setNomeDaMae(nomeDaMae);
        setNacionalidade(nacionalidade);
        setEmail(email);
        setSexo(sexo);
        setTelefone(telefone);
				setDocumentoId(documentoId);
				setDataEmissao(dataEmissao);
				setHabilitacao(habilitacao);
    }

	public void setNumeroBi(String numeroBi) {
		this.numeroBi = new StringBufferModelo(numeroBi, 50);
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = new StringBufferModelo(nomeCompleto, 50);
	}

	public void setApelido(String apelido) {
		this.apelido = new StringBufferModelo(apelido, 50);
	}

	public void setNumeroDeContribuinte(String numeroDeContribuinte) {
		this.numeroDeContribuinte = new StringBufferModelo(numeroDeContribuinte, 50);
	}

	public void setEstadoCivil(String estadoCivil) {
		this.estadoCivil = new StringBufferModelo(estadoCivil, 50);
	}

	public void setDominioEmail(String dominioEmail) {
		this.dominioEmail = new StringBufferModelo(dominioEmail, 50);
	}

	public void setDataDeNascimento(String dataDeNascimento) {
		this.dataDeNascimento = new StringBufferModelo( dataDeNascimento, 50);
	}

	public void setProvincia(String provincia) {
		this.provincia = new StringBufferModelo( provincia, 50);
	}

	public void setMunicipio(String municipio) {
		this.municipio = new StringBufferModelo( municipio, 50);
	}

	public void setBairro(String bairro) {
		this.bairro = new StringBufferModelo(bairro, 50);
	}

	public void setNomeDoPai(String nomeDoPai) {
		this.nomeDoPai = new StringBufferModelo(nomeDoPai, 50);
	}

	public void setNomeDaMae(String nomeDaMae) {
		this.nomeDaMae = new StringBufferModelo(nomeDaMae, 50);
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = new StringBufferModelo( nacionalidade, 50);
	}

	public void setEmail(String email) {
		this.email = new StringBufferModelo( email, 50);
	}

	public void setSexo(String sexo) {
		this.sexo = new StringBufferModelo( sexo, 50);
	}

	public void setTelefone(String telefone) {
		this.telefone = new StringBufferModelo( telefone, 50);
	}

	public void setDocumentoId(String documentoId) {
		this.documentoId = new StringBufferModelo( documentoId, 50);
	}

	public void setDataEmissao(String dataEmissao) {
		this.dataEmissao = new StringBufferModelo( dataEmissao, 50);
	}

	public void setHabilitacao(String habilitacao) {
		this.habilitacao = new StringBufferModelo( habilitacao, 50);
	}

	//---------------------! Area dos Gets !------------------------

	public String getNumeroBi() {
		return numeroBi.toStringEliminatingSpaces();
	}

	public String getNomeCompleto() {
		return nomeCompleto.toStringEliminatingSpaces();
	}

	public String getApelido() {
		return apelido.toStringEliminatingSpaces();
	}

	public String getNumeroDeContribuinte() {
		return numeroDeContribuinte.toStringEliminatingSpaces();
	}

	public String getEstadoCivil() {
		return estadoCivil.toStringEliminatingSpaces();
	}

	public String getDominioEmail() {
		return dominioEmail.toStringEliminatingSpaces();
	}

	public String getDataDeNascimento() {
		return dataDeNascimento.toStringEliminatingSpaces();
	}

	public String getProvincia() {
		return provincia.toStringEliminatingSpaces();
	}

	public String getMunicipio() {
		return municipio.toStringEliminatingSpaces();
	}

	public String getBairro() {
		return bairro.toStringEliminatingSpaces();
	}

	public String getNomeDoPai() {
		return nomeDoPai.toStringEliminatingSpaces();
	}

	public String getNomeDaMae() {
		return nomeDaMae.toStringEliminatingSpaces();
	}

	public String getNacionalidade() {
		return nacionalidade.toStringEliminatingSpaces();
	}

	public String getEmail() {
		return email.toStringEliminatingSpaces();
	}

	public String getSexo() {
		return sexo.toStringEliminatingSpaces();
	}

	public String getTelefone() {
		return telefone.toStringEliminatingSpaces();
	}

	public String getDataEmissao() {
		return dataEmissao.toStringEliminatingSpaces();
	}

	public String getDocumentoId() {
		return documentoId.toStringEliminatingSpaces();
	}

	public String getHabilitacao() {
		return habilitacao.toStringEliminatingSpaces();
	}
}
