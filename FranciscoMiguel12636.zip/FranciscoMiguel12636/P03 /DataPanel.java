import javax.swing.*;
import java.awt.*;
import javax.swing.UIManager;

public class DataPanel extends JPanel
{
	JLabel dLabel;
	JTextField dTestField;
	
		public DataPanel(String label)
		{
			try
     		{
				UIManager.setLookAndFeel ("javax.swing.plaf.nimbus.NimbusLookAndFeel");
				
				JTextFieldData jTextFieldData = new JTextFieldData(label);
				setLayout(new GridLayout(1, 2));
				dTestField = jTextFieldData.getDTestField();
				add(dTestField);
				add(jTextFieldData.getDButton());
			}
     		catch (Exception ex)
     		{
       			System.out.println (""+ex.getMessage ());
     		}
		}	
	public JTextField getDTestField()
		{ return dTestField; }
	
}
