/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: GravadorClienteModelo.java
**	Objectivo: Armazenar cliente na HashTable
**  Nome: Francisco André Miguel
**	Data: 17 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import yb.hashtableyb.GravadorGenericoHT;

public class GravadorClienteModelo extends GravadorGenericoHT
{
  public GravadorClienteModelo ()
  {
    super(Definicoes.FILECLIENTES, 50, new ClienteModelo());
  }
}
