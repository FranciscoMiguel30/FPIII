/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: ImageSystem.java
**	Objectivo: Responsavel pelas imagens do Software
**  Nome: Francisco André Miguel
**	Data: 8 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/


	import javax.swing.*;
	import java.awt.*;

	public class ImageSystem
	{

		public static String ALTERAR_IMG = "Imagens/alterar.png";


		public static String DEFAULT_USER_IMG = "Imagens/user.png";
		public static String BFA_IMG = "Imagens/bfa.jpg";


		public static String UCAN_IMG = "Imagens/ucan1.jpg";


		// Caminhos para os ícones dos botões
		public static String GRAVAR_BOTAO_IMG = "Imagens/save.png";
		public static String ADD_IMG = "Imagens/add.png";
		public static String EDIT_IMG = "Imagens/edit.png";
		public static String DELETE_IMG = "Imagens/delete.png";
		public static String LIMPAR_BOTAO_IMG = "Imagens/clean.png";
		public static String SEARCH_IMG = "Imagens/search.png";
		public static String MENU_IMG = "Imagens/menu.png";
		public static String HELP_IMG = "Imagens/help.png";
		public static String FIND_IMG = "Imagens/find.png";
		public static String ENCERRAR_IMG = "Imagens/exit.png";
		public static String LOGOUT_IMG = "Imagens/logout2.png";
		public static String DEPOSITAR_IMG = "Imagens/depositar.png";
		public static String TRANSFERIR_IMG = "Imagens/transferir.png";
		public static String LEVANTAR_IMG = "Imagens/levantar.png";
		public static String EXTRACTO_IMG = "Imagens/listarC.png";
		public static String CORRESPONDENCIA_BOTAO_IMG = "Imagens/document_2.png";
		public static String FERRAMENTAS_BOTAO_IMG = "Imagens/tools_1.png";
		public static String AJUDA_BOTAO_IMG = "Imagens/help_1.png";
		public static String TABELAS_BOTAO_IMG = "Imagens/table.png";
		public static String AD_CORRESP_BOTAO_IMG = "Imagens/add_doc.png";

		public static String DEFESA_BOTAO_IMG = "Imagens/defesa.png";

		public static String FUNDO_BOTOES_PRINCIPAL = "Imagens/button1.gif";

		public static String LOCKER = "Imagens/encrypted.png";

		public static String OK =	"Imagens/aplicar.png";

		public static String CANCEL ="Imagens/sair.png";

		public static String ESTATISTICAS_MENU_IMG = "Imagens/statistics.png";



		public static String ERRO_IMG = "Imagens/error.png";
		public static String SUCESSO_IMG = "Imagens/correct.png";


		public static ImageIcon criarIcone ( String caminhoImagem )
		{
			return new ImageIcon ( caminhoImagem );
		}
	}
