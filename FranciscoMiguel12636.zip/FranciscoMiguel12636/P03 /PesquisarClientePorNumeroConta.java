
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: PesquisarClientePorNumeroConta.java
**  Nome: Francisco André Miguel
**	Data: 29 de Junho de 2016
**	Numero: 12636
**  Objectivo: Pesquisar Cliente Por Numero Da Conta
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.List;
import java.util.ArrayList;
import java.util.List;
import yb.hashtableyb.Gravavel;

public class PesquisarClientePorNumeroConta extends JFrame  implements ActionListener{

	  private JPanel painelNome,painelData, painelData1, painelData2, painelCentro, painelBtn,painelTabela,painelJediEpainelJuntos,painelmedia;
	  private JTextArea editorPane;
	  private JLabel jlbNumeroConta;
	  private JTextField jtfNumeroConta;
	  private JScrollPane editorScrollPane,jspTabela;
	  private JButton btnPesquisar, btnCancelar,btnVerTodos;
	  // Dados para Tabela
	  private Object[][] dados = new Object[][]{{}};
	  private JTable table;
	  private DefaultTableModel modelo;

		private String[] colunas = new String[]{"Numero Da Conta","Codigo Do Cliente","Nome Do Cliente"};

		private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
	  private GravadorContaModelo gravador = new GravadorContaModelo();

	  private String str = "";

	  public PesquisarClientePorNumeroConta(){
			setTitle("Pesquisar Clientes Por Numero De Conta");
			setLayout(new BorderLayout());
			setSize(800,600);
			setLocationRelativeTo(null);
			setResizable(true);
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			criaGui();
			setVisible(true);
	  }

	  public void criaGui(){
	   //Instanciado JEditorPane
		editorPane = new JTextArea("");
		editorPane.setEditable(false);
		editorScrollPane = new JScrollPane(editorPane,editorScrollPane.VERTICAL_SCROLLBAR_ALWAYS, editorScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		editorScrollPane.setPreferredSize(new Dimension(700,150));

		//Instanciando Paineis
		painelTabela = new JPanel(new GridBagLayout());
		painelmedia = new JPanel(new GridBagLayout());
		painelBtn = new JPanel(new FlowLayout());
    painelNome = new JPanel(new FlowLayout());
		painelData = new JPanel(new FlowLayout());
		painelData1 = new JPanel();
		painelData2 = new JPanel();
		painelCentro = new JPanel(new BorderLayout());

		//Instanciando os Botãoes
		btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(this);
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(this);
		btnVerTodos = new JButton("Ver Todos");
		btnVerTodos.addActionListener(this);

		//Labels e Cambos de Edicao
		jlbNumeroConta = new JLabel("Digite O Numero Da Conta: ");
		jtfNumeroConta = new JTextField(10);


		//  Criando a Tabela
		modelo = (new DefaultTableModel(dados, colunas)
		{
			public boolean isCellEditable(int row, int column) {
					return false;
			}
		});

		Mouse mouse = new Mouse();
		table = new JTable();

		final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(modelo);

		table.setRowSorter(sorter);
		modelo.setRowCount(0);

		//Acoes nos Botoes
		table.addMouseListener(mouse);
  	table.addKeyListener(mouse);

		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setModel(modelo);

		//Ajuste da Tabela
		table.getColumnModel().getColumn(0).setPreferredWidth(200);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(2).setPreferredWidth(200);


		jspTabela = new JScrollPane(table, jspTabela.VERTICAL_SCROLLBAR_ALWAYS, jspTabela.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jspTabela.setPreferredSize(new Dimension(700,200));
		painelTabela.add(jspTabela, new GridBagConstraints(0,2,12,1,0,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5,5,5,5),0,0));
		painelmedia.add(editorScrollPane, new GridBagConstraints(0,0,8,1,0,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(10,10,10,0),0,0));

		painelTabela.setBorder(BorderFactory.createTitledBorder("Dados Encontrados"));

		painelNome.add(jlbNumeroConta);
		painelNome.add(jtfNumeroConta);
		painelNome.setBorder(BorderFactory.createTitledBorder("Numero Conta"));

		painelBtn.add(btnPesquisar);
		painelBtn.add(btnVerTodos);
		painelBtn.add(btnCancelar);

		painelCentro.add(painelTabela, BorderLayout.CENTER);
		painelCentro.add(painelmedia, BorderLayout.SOUTH);

		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(painelNome, BorderLayout.NORTH);
		getContentPane().add(painelCentro, BorderLayout.CENTER);
		getContentPane().add( painelBtn, BorderLayout.SOUTH);

	  }

	  //Eventos de Mouse
	  public class Mouse implements MouseListener,KeyListener
	  {
	    	    public void mouseClicked(MouseEvent e){
 						ContaModelo elemento = (ContaModelo) lista.get (table.getSelectedRow ());

						editorPane.setText(elemento.toString());
						editorPane.setFont(new Font("Arial", Font.ITALIC, 16));
						editorPane.setBackground(Color.blue);
						editorPane.setForeground(Color.WHITE);
					}

					public void mousePressed(MouseEvent e)
					{  }
					public void mouseReleased(MouseEvent e) { }
					public void mouseEntered(MouseEvent e){}
					public void mouseExited(MouseEvent e){}
					public void keyPressed(KeyEvent k){}


					public void keyReleased(KeyEvent k)
					{

					}

					public void keyTyped(KeyEvent k)
  					{  }
		}

		public void mostrarTudo(){
     modelo.setRowCount(0);
     try
     {
       lista = gravador.lerTodos();
       ContaModelo formulario;
       for( Gravavel gravavel : lista )
       {
         formulario = (ContaModelo) gravavel;
         Object[] object = new Object[3];
         object[0]= formulario.getNumeroConta ();
         object[1]= formulario.getCodigoCliente();
         object[2]= formulario.getNomeCompleto();
         modelo.addRow(object);
         ordenarLista();
       }
     }
     catch (IOException ex)
     {
       JOptionPane.showMessageDialog(this, "Ocorreu um erro ao fazer a leitura do ficheiro");
     }

   	}
		public void ordenarLista(){
      if(table.getRowCount() > 0){
       Collections.sort(lista, getComparadorPessoa());
       modelo.setRowCount(0);
           ContaModelo formulario;
           for( Gravavel gravavel : lista )
           {
             formulario = (ContaModelo) gravavel;
             Object[] object = new Object[3];
             object[0]= formulario.getNumeroConta();
             object[1]= formulario.getCodigoCliente();
             object[2]= formulario.getNomeCompleto();
             modelo.addRow(object);
          }
      }else{
          JOptionPane.showMessageDialog(null, "Carregue primeiro os registos na tabela - click vet todos!!!");
      }


    }

		public void pesquisaClienteNumeroConta(String numeroConta)
		{
			modelo.setRowCount(0);
			Collections.sort(lista, getComparadorPessoa());
				try
				{
					lista = gravador.lerTodos();
					ContaModelo formulario;
					for( Gravavel gravavel : lista )
					{
						formulario = (ContaModelo) gravavel;
						if(numeroConta.equals(formulario.getNumeroConta()))
						{
              Object[] object = new Object[3];
              object[0]= formulario.getNumeroConta();
              object[1]= formulario.getCodigoCliente();
              object[2]= formulario.getNomeCompleto();
							modelo.addRow(object);
							//ordenarLista();
						}
					}
				}catch (IOException ex) {}
	  			int linha = table.getRowCount();
					if(linha == 0)
					{
				    	 JOptionPane.showMessageDialog(null, "Dados Não Encontados!!!", "ERRO NA ENTRADA DE DADOS",JOptionPane.ERROR_MESSAGE );
					}
		} // fim do Metodo


		private Comparator getComparadorPessoa()
    {
       return new Comparator()
       {

           public int compare(Object o1, Object o2)
           {
               ContaModelo dado1 = ( ContaModelo ) o1;
               ContaModelo dado2 = ( ContaModelo ) o2;

               return dado1.getNomeCompleto().compareToIgnoreCase(dado2.getNomeCompleto());
           }
       };
   	}


	   //Tratamento de Eventos nos Botoes
	   public void actionPerformed(ActionEvent eventos)
	   {
		  if(eventos.getSource() == btnCancelar)
			  dispose();
		  else if (eventos.getSource() == btnPesquisar)
		  {
				pesquisaClienteNumeroConta(jtfNumeroConta.getText().toString ().trim ());
		  }
		  else if(eventos.getSource() == btnVerTodos)
			      	mostrarTudo();
	   }
}
