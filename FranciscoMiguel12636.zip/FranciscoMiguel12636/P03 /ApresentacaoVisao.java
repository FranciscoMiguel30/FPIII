
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: ApresentacaoVisao.java
**	Objectivo: Responsavel pela Apresentacao
**  Nome: Francisco André Miguel
**	Data: 8 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class ApresentacaoVisao extends JFrame
{

 private JLabel jlbImagem;
 private JTextArea jtaCondicoes;
 private JScrollPane jspRolagem;
 private JButton jbSeguinte, jbCancelar;
 private JRadioButton jrbConcordo;
 private JPanel painelImagem, painelBotoes;

 private ImageSystem image;
 public ApresentacaoVisao ()
 {
  super ("Termos de uso");

  image = new ImageSystem ();
  //Definindo o layout da janela
  setLayout (new BorderLayout ());

  //Intanciando as labels
  jlbImagem = new JLabel ( image.criarIcone ( image.UCAN_IMG ) );

  //Intanciando os botões e grupo de botões
  jrbConcordo = new JRadioButton (" Concordo ");

  jbSeguinte = new JButton ("Seguinte", image.criarIcone ( image.OK ));
  jbSeguinte.setEnabled (false);
  jbCancelar = new JButton ("Cancelar", image.criarIcone ( image.CANCEL ) );

  //Adicionando evento aos botões
  jrbConcordo.addItemListener (new Evento ());

  jbSeguinte.addActionListener (new Evento ());
  jbCancelar.addActionListener (new Evento ());

  //Instanciando os paineis
  painelImagem = new JPanel ( new GridLayout (1,1) );
  painelBotoes = new JPanel ( new GridBagLayout () );

  painelImagem.setBackground ( Color.WHITE );
  painelBotoes.setBackground ( Color.WHITE );

  jtaCondicoes = new JTextArea ( );
  jspRolagem = new JScrollPane (jtaCondicoes, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

  preencherArea ( );

  //Adicionando os componentes nos paineis e definindo as suas cordenadas
  painelImagem.add (jlbImagem);

  painelBotoes.add (jrbConcordo,new GridBagConstraints (0,0,1,2,0,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL, new Insets (10,1,5,1) ,0,0) );
  painelBotoes.add (jbSeguinte,new GridBagConstraints (2,4,1,1,0,0,GridBagConstraints.SOUTHWEST,GridBagConstraints.HORIZONTAL, new Insets (1,140,1,1) ,0,0) );
  painelBotoes.add (jbCancelar,new GridBagConstraints (3,4,1,1,0,0,GridBagConstraints.SOUTHWEST,GridBagConstraints.HORIZONTAL, new Insets (1,1,1,1) ,0,0) );

  //Pegando o contentPane
  Container contentor = getContentPane ();

  //Adicionando os componentes ao container
  contentor.add (painelImagem, BorderLayout.NORTH);
  contentor.add (jspRolagem, BorderLayout.CENTER);
  contentor.add (painelBotoes, BorderLayout.SOUTH);

  setDefaultCloseOperation ( EXIT_ON_CLOSE );
  setSize (460,550);
  setLocationRelativeTo ( null );
  setVisible ( true );
  setResizable (false);
}

 //Classe interna que trata de eventos
 private class Evento implements ActionListener, ItemListener
 {
  public void actionPerformed (ActionEvent eve)
  {
   if (eve.getSource () == jbSeguinte)
   {
    new MenuPrincipal ().show ( );
    dispose ();
   }
   if (eve.getSource () == jbCancelar)
    System.exit (0);
  }

  public void itemStateChanged (ItemEvent eve)
  {
   if ( jrbConcordo.isSelected () )
    jbSeguinte.setEnabled (true);
   else
    jbSeguinte.setEnabled (false);
  }
 }

 public void preencherArea ( )
 {
   jtaCondicoes.setEditable ( false );
   jtaCondicoes.setText ("                                                             \n"
                        +"Descrição:                                                   \n"
                        +"     Gestão do Banco De Fomento De Angola (BFA)        \n\n"
                        +"Software desenvolvido Como Projecto de Fundamentos de Progra-\n"
                        +"mação III por:\n"
                        +"     Francisco André Miguel.\n"
                        +"Sob orientação do:\n"
                        +"     Professor Doutor Engenheiro Aires Veloso.\n\n"
                        +"TERMOS E CONDIÇÕES\n\n"
                        +"     Excluindo o uso na Universidade Católica, todos os direitos de\n"
                        +"autor desta aplicação são reservados.\n\n"
                        +"     É punida nos termos da lei, qualquer tipo de reprodução, cópia,\n"
                        +"comercialização e exibição publica desta aplicação no seu todo ou \n"
                        +"em parte sem autorização expressa\n"
                        +"\n\t\tUcan@Copyright");
   jtaCondicoes.setFont ( new Font ("Serif",Font.BOLD,13) );
   jtaCondicoes.setBackground ( Color.LIGHT_GRAY );
 }

}
