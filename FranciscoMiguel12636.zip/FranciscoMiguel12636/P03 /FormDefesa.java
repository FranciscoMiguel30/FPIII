
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: FormDefesa.java
**  Nome: Francisco André Miguel
**	Data: 17 de Junho de 2016
**	Numero: 12636
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.ArrayList;
import java.util.Date;
import java.text.*;
import java.util.List;
import yb.hashtableyb.Gravavel;

public class FormDefesa extends JFrame  implements ActionListener{

	  private JPanel painelNome,painelList,painelData, painelData1, painelData2, painelCentro, painelBtn,painelTabela;
	  private JTextArea editorPane;
	  private JLabel jlbNome;
	  private JTextField jtfNome,dataNascimento1Jtf,dataNascimento2Jtf;
		private JList jlApelido,jlTipoConta;
		private JComboBox operadoraCb,numeroTitularesJtf;
		private JTextFieldData data1,data2;
	  private JScrollPane editorScrollPane,jspTabela,scrollContas;
	  private JButton btnPesquisar, btnCancelar,btnVerTodos;
	  // Dados para Tabela
	  private Object[][] dados = new Object[][]{{}};
	  private JTable table;
	  private DefaultTableModel modelo;
    private JTextFieldData dataNascimento;
		private JScrollPane scroll;
		private PesquisasControlo controlo = new PesquisasControlo ();
		private String[] colunas = new String[]{"Nº BI","Nome","Sexo","Documento Identificacao","Data de Emissão",
										 "Data Nascimento","Nacionalidade","Comuna","Provincia","Municipio","Estado Civil","Nº Tel.","Nome Mãe",
			"Nome Pai","E - Mail","Nº Contribuinte","Habilitacao"};

		private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
		private ArrayList<Gravavel> listaConta = new ArrayList<Gravavel>();
	  private GravadorClienteModelo gravador = new GravadorClienteModelo();
		private GravadorContaModelo gravadorConta = new GravadorContaModelo();
	  private String str = "";
		private String[] operadoras = {"Unitel","Movicel","Angola-Telecom","Outras"};

	  public FormDefesa(){
			setTitle("Pesquisas");
			setLayout(new BorderLayout());
			setSize(800,600);
			setLocationRelativeTo(null);
			setResizable(true);
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			criaGui();
			setVisible(true);
	  }

	  public void criaGui(){
	   //Instanciado JEditorPane
		editorPane = new JTextArea("");
		jlApelido = new JList (controlo.getApelidos());
		jlTipoConta = new JList (controlo.getTipoContas ());

		numeroTitularesJtf = new JComboBox (controlo.getNumeroTitular ());
		editorPane.setEditable(false);
		editorScrollPane = new JScrollPane(jlApelido,editorScrollPane.VERTICAL_SCROLLBAR_ALWAYS, editorScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		editorScrollPane.setPreferredSize(new Dimension(100,80));
		scrollContas = new JScrollPane(jlTipoConta,editorScrollPane.VERTICAL_SCROLLBAR_ALWAYS, editorScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		editorScrollPane.setPreferredSize(new Dimension(100,80));

		//Instanciando Paineis
		painelTabela = new JPanel(new GridBagLayout());
		painelBtn = new JPanel(new FlowLayout());
    painelNome = new JPanel(new GridLayout(3,2));
		painelList = new JPanel(new FlowLayout());
		painelData = new JPanel(new FlowLayout());
		painelData1 = new JPanel();
		painelData2 = new JPanel();
		painelCentro = new JPanel(new BorderLayout());

		//Instanciando os Botãoes
		btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(this);
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(this);
		btnVerTodos = new JButton("Ver Todos");
		btnVerTodos.addActionListener(this);
		btnVerTodos.setVisible (false);
		//Labels e Cambos de Edicao
		//jlbNome = new JLabel("Digite Nome: ");
		//jtfNome = new JTextField(10);

		//  Criando a Tabela
		modelo = (new DefaultTableModel(dados, colunas)
		{
			public boolean isCellEditable(int row, int column) {
					return false;
			}
		});
		table = new JTable();

		final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(modelo);

		table.setRowSorter(sorter);
		modelo.setRowCount(0);

		//Acoes nos Botoes
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setModel(modelo);

		//Ajuste da Tabela
		table.getColumnModel().getColumn(0).setPreferredWidth(200);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(2).setPreferredWidth(125);
		table.getColumnModel().getColumn(3).setPreferredWidth(125);
		table.getColumnModel().getColumn(4).setPreferredWidth(125);
		table.getColumnModel().getColumn(5).setPreferredWidth(175);
		table.getColumnModel().getColumn(6).setPreferredWidth(175);
		table.getColumnModel().getColumn(7).setPreferredWidth(125);
		table.getColumnModel().getColumn(8).setPreferredWidth(125);
		table.getColumnModel().getColumn(9).setPreferredWidth(175);
		table.getColumnModel().getColumn(10).setPreferredWidth(125);
		table.getColumnModel().getColumn(11).setPreferredWidth(75);
		table.getColumnModel().getColumn(12).setPreferredWidth(75);
		table.getColumnModel().getColumn(13).setPreferredWidth(75);
		table.getColumnModel().getColumn(14).setPreferredWidth(125);
		table.getColumnModel().getColumn(15).setPreferredWidth(175);
		table.getColumnModel().getColumn(16).setPreferredWidth(125);

		painelNome.setPreferredSize(new Dimension(200,200));
		jspTabela = new JScrollPane(table, jspTabela.VERTICAL_SCROLLBAR_ALWAYS, jspTabela.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jspTabela.setPreferredSize(new Dimension(700,200));
		painelTabela.add(jspTabela, new GridBagConstraints(0,2,11,1,0,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5,5,5,5),0,0));

		painelTabela.setBorder(BorderFactory.createTitledBorder("Dados Encontrados"));

		//painelNome.add(jlbNome);
		//painelNome.add(jtfNome);
		painelNome.setBorder(BorderFactory.createTitledBorder("Pesquisas"));
		painelBtn.add(btnPesquisar);
		painelBtn.add(btnVerTodos);
		painelBtn.add(btnCancelar);
		painelList.add (editorPane);
		painelCentro.add(painelTabela, BorderLayout.CENTER);
		addDataNascimento1 ();
		addDataNascimento2 ();
		painelNome.add (new JLabel ("Apelidos"));
		painelNome.add (editorScrollPane);
		painelNome.add (new JLabel ("Tipo De Contas"));
		painelNome.add (jlTipoConta);
		painelNome.add (new JLabel ("Numero De Titulares"));
		painelNome.add (numeroTitularesJtf);
		addOperadora ();
		//painelNome.add (painelList);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(painelNome, BorderLayout.NORTH);
		getContentPane().add(painelCentro, BorderLayout.CENTER);
		getContentPane().add( painelBtn, BorderLayout.SOUTH);
	  }


		public void addOperadora ()
		{
			//painelNome.add( new JLabel ("Operadora"));
	    operadoraCb = new JComboBox (operadoras);
			//painelNome.add(operadoraCb);
		}

		public void addTipoConta ()
		{
			//painelNome.add( new JLabel ("Operadora"));
	    operadoraCb = new JComboBox (operadoras);
			//painelNome.add(operadoraCb);
		}

		public void addDataNascimento1 ()
	  {
	    //painelNome.add( new JLabel ("  Data de Nascimento"));
	    DataPanel dataNascimento1Painel = new DataPanel("");
			dataNascimento1Jtf = new JTextField ();
	    dataNascimento1Jtf = dataNascimento1Painel.getDTestField();
	    //painelNome.add(dataNascimento1Painel);
	  }

		public void addDataNascimento2 ()
	  {
	    //painelNome.add( new JLabel ("  Data de Nascimento"));
	    DataPanel dataNascimentoPainel = new DataPanel("");
			dataNascimento2Jtf = new JTextField ();
	    dataNascimento2Jtf = dataNascimentoPainel.getDTestField();
	    //painelNome.add(dataNascimentoPainel);
	  }

		public void pesquisarOperadora(String operadora)
	  {
			  if (operadora.equals (operadoras[0]))
				{
					String chaveUnitel [] = {"92","93","94"};
					pesquisarOperadoraTable (chaveUnitel);
				}
				else if (operadora.equals (operadoras[1]))
				{
					String chaveMovicel[] = {"91","99"};
					pesquisarOperadoraTable (chaveMovicel);
				}
				else if (operadora.equals (operadoras[2]))
				{
					String chaveTelecom = "222";
					pesquisarOperadoraTableAngolaTelecom (chaveTelecom);
				}
	  }

		public void pesquisarOperadoraTableOutros (String[] operadoras)
		{
			modelo.setRowCount(0);
			try
			{
					lista = gravador.lerTodos();
					ClienteModelo formulario;
					for( Gravavel gravavel : lista )
					{
							formulario = (ClienteModelo) gravavel;
							String chave = formulario.getTelefone().substring (0,2);
							for (int i = 0 ; i < operadoras.length ; ++i)
							{
								if (!operadoras[i].equals (chave))
								{
									Object[] object = new Object[17];
									object[0] = formulario.getNumeroBi();
									object[1] = formulario.getNomeCompleto();
									object[2] = formulario.getSexo();
									object[3] = formulario.getDocumentoId();
									object[4] = formulario.getDataEmissao();
									object[5] = formulario.getDataDeNascimento();
									object[6] = formulario.getNacionalidade();
									object[7] = formulario.getBairro();
									object[8] = formulario.getProvincia();
									object[9] = formulario.getMunicipio();
									object[10] = formulario.getEstadoCivil();
									object[11] = formulario.getTelefone();
									object[12] = formulario.getNomeDaMae();
									object[13] = formulario.getNomeDoPai();
									object[14] = formulario.getEmail();
									object[15] = formulario.getNumeroDeContribuinte();
									object[16] = formulario.getHabilitacao ();
									modelo.addRow(object);
								}
							}
						}
				}catch (IOException ex) {}
				int linha = table.getRowCount();
				if(linha == 0)
				{
						 JOptionPane.showMessageDialog(null, "Dados Não Encontados!!!", "ERRO NA ENTRADA DE DADOS",JOptionPane.ERROR_MESSAGE );
				}
		}
		public void pesquisarOperadoraTableAngolaTelecom (String operadora)
		{
			modelo.setRowCount(0);
			try
			{
					lista = gravador.lerTodos();
					ClienteModelo formulario;
					for( Gravavel gravavel : lista )
					{
							formulario = (ClienteModelo) gravavel;
							String chave = formulario.getTelefone().substring (0,3);
							if (operadora.equals (chave))
							{
								Object[] object = new Object[17];
								object[0] = formulario.getNumeroBi();
								object[1] = formulario.getNomeCompleto();
								object[2] = formulario.getSexo();
								object[3] = formulario.getDocumentoId();
								object[4] = formulario.getDataEmissao();
								object[5] = formulario.getDataDeNascimento();
								object[6] = formulario.getNacionalidade();
								object[7] = formulario.getBairro();
								object[8] = formulario.getProvincia();
								object[9] = formulario.getMunicipio();
								object[10] = formulario.getEstadoCivil();
								object[11] = formulario.getTelefone();
								object[12] = formulario.getNomeDaMae();
								object[13] = formulario.getNomeDoPai();
								object[14] = formulario.getEmail();
								object[15] = formulario.getNumeroDeContribuinte();
								object[16] = formulario.getHabilitacao ();
								modelo.addRow(object);
							}
						}
				}catch (IOException ex) {}
				int linha = table.getRowCount();
				if(linha == 0)
				{
						 JOptionPane.showMessageDialog(null, "Dados Não Encontados!!!", "ERRO NA ENTRADA DE DADOS",JOptionPane.ERROR_MESSAGE );
				}
		}

		public void pesquisarOperadoraTable (String[] operadoras )
		{
			modelo.setRowCount(0);
			try
			{
					lista = gravador.lerTodos();
					ClienteModelo formulario;
					for( Gravavel gravavel : lista )
					{
							formulario = (ClienteModelo) gravavel;
							String chave = formulario.getTelefone().substring (0,2);
							for (int i = 0 ; i < operadoras.length ; ++i)
							{
								if (operadoras[i].equals (chave))
								{
									Object[] object = new Object[17];
									object[0] = formulario.getNumeroBi();
									object[1] = formulario.getNomeCompleto();
									object[2] = formulario.getSexo();
									object[3] = formulario.getDocumentoId();
									object[4] = formulario.getDataEmissao();
									object[5] = formulario.getDataDeNascimento();
									object[6] = formulario.getNacionalidade();
									object[7] = formulario.getBairro();
									object[8] = formulario.getProvincia();
									object[9] = formulario.getMunicipio();
									object[10] = formulario.getEstadoCivil();
									object[11] = formulario.getTelefone();
									object[12] = formulario.getNomeDaMae();
									object[13] = formulario.getNomeDoPai();
									object[14] = formulario.getEmail();
									object[15] = formulario.getNumeroDeContribuinte();
									object[16] = formulario.getHabilitacao ();
									modelo.addRow(object);
								}
							}
						}
				}catch (IOException ex) {}
				int linha = table.getRowCount();
				if(linha == 0)
				{
						 JOptionPane.showMessageDialog(null, "Dados Não Encontados!!!", "ERRO NA ENTRADA DE DADOS",JOptionPane.ERROR_MESSAGE );
				}
		}
		public void defesaProjecto(String primeiraData,String segundaData)
	  {
	    modelo.setRowCount(0);
	    DataModelo data1d = new DataModelo (primeiraData);
	    DataModelo data2d = new DataModelo (segundaData);
	    if (controlo.verificaDatasup (data1d,data2d) == 0)
	    {
	      DataModelo tmp = new DataModelo ();
	      tmp = data1d;
	      data1d = data2d;
	      data2d = tmp;
	    }
	    try
	    {
	      lista = gravador.lerTodos();
	      ClienteModelo formulario;
				Object[] apelidosSelecionados =  jlApelido.getSelectedValues ();
				for ( int i = 0; i < apelidosSelecionados.length; i++)
				{
					String apelidoActual = (String) apelidosSelecionados[i];
			    for( Gravavel gravavel : lista )
		      {

		        formulario = (ClienteModelo) gravavel;
						String[] nomeModelo = formulario.getNomeCompleto().split(" ");
					  DataModelo dataProcModelo = new DataModelo (formulario.getDataDeNascimento ());
						/*if ( apelidoActual.equalsIgnoreCase(nomeModelo[nomeModelo.length - 1]))
		        	if (controlo.verificaDatasup (data1d,dataProcModelo) == 1 ||
								controlo.verificaDatasup (data1d,dataProcModelo) == -1)
		        		if (controlo.verificaDatasup (dataProcModelo,data2d) == 1 ||
									controlo.verificaDatasup (dataProcModelo,data2d) == -1)*/
		          {
		            Object[] object = new Object[17];
		            object[0] = formulario.getNumeroBi();
		            object[1] = formulario.getNomeCompleto();
		            object[2] = formulario.getSexo();
		            object[3] = formulario.getDocumentoId();
		            object[4] = formulario.getDataEmissao();
		            object[5] = formulario.getDataDeNascimento();
		            object[6] = formulario.getNacionalidade();
		            object[7] = formulario.getBairro();
		            object[8] = formulario.getProvincia();
		            object[9] = formulario.getMunicipio();
		            object[10] = formulario.getEstadoCivil();
		            object[11] = formulario.getTelefone();
		            object[12] = formulario.getNomeDaMae();
		            object[13] = formulario.getNomeDoPai();
		            object[14] = formulario.getEmail();
		            object[15] = formulario.getNumeroDeContribuinte();
								object[16] = formulario.getHabilitacao ();
		            modelo.addRow(object);
		          }
		        }
					}
	      }catch (IOException ex) {}
	      int linha = table.getRowCount();
	      if(linha == 0)
	      {
	           JOptionPane.showMessageDialog(null, "Dados Não Encontados!!!", "ERRO NA ENTRADA DE DADOS",JOptionPane.ERROR_MESSAGE );
	      }
	  } // fim do Metodo de Pesquisa

		public void pesquisaDefesa (String numeroTitular)
		{
			modelo.setRowCount(0);
	    Collections.sort(lista, controlo.getComparadorClienteNome());
	    try
	    {
	      lista = gravador.lerTodos();
				listaConta = gravadorConta.lerTodos();
	      ClienteModelo formulario;
				ContaModelo contaModelo;
				Object[] apelidosSelecionados =  jlApelido.getSelectedValues ();
				for ( int i = 0; i < apelidosSelecionados.length; i++)
				{
					String apelidoActual = (String) apelidosSelecionados[i];
			    for( Gravavel gravavel : lista )
		      {

		        formulario = (ClienteModelo) gravavel;
						String[] nomeModelo = formulario.getNomeCompleto().split(" ");
					  if ( apelidoActual.equalsIgnoreCase(nomeModelo[nomeModelo.length - 1]))
						{
							for( Gravavel grav : listaConta )
				      {
								contaModelo = (ContaModelo) grav;
								if (numeroTitular.equals (contaModelo.getNumeroConta() ))
								{
					        Object[] object = new Object[17];
				          object[0] = formulario.getNumeroBi();
				          object[1] = formulario.getNomeCompleto();
				          object[2] = formulario.getSexo();
				          object[3] = formulario.getDocumentoId();
				          object[4] = formulario.getDataEmissao();
				          object[5] = formulario.getDataDeNascimento();
				          object[6] = formulario.getNacionalidade();
				          object[7] = formulario.getBairro();
				          object[8] = formulario.getProvincia();
				          object[9] = formulario.getMunicipio();
				          object[10] = formulario.getEstadoCivil();
				          object[11] = formulario.getTelefone();
				          object[12] = formulario.getNomeDaMae();
				          object[13] = formulario.getNomeDoPai();
				          object[14] = formulario.getEmail();
				          object[15] = formulario.getNumeroDeContribuinte();
									object[16] = formulario.getHabilitacao ();
				          modelo.addRow(object);
								}
							}
	      		}
	      	}
				}
	    }catch (IOException ex) {}
	      int linha = table.getRowCount();
	      if(linha == 0)
	      {
	           JOptionPane.showMessageDialog(null, "Dados Não Encontados!!!", "ERRO NA ENTRADA DE DADOS",JOptionPane.ERROR_MESSAGE );
	      }
		}

		public void pesquisa(String nome)
	  {
	    modelo.setRowCount(0);
	    Collections.sort(lista, controlo.getComparadorPessoa());
	    try
	    {
	      lista = gravador.lerTodos();
	      ClienteModelo formulario;
	      for( Gravavel gravavel : lista )
	      {
	        formulario = (ClienteModelo) gravavel;
	        if(nome.trim ().equalsIgnoreCase(formulario.getNomeCompleto().trim ()))
	        {
	          Object[] object = new Object[17];
	          object[0] = formulario.getNumeroBi();
	          object[1] = formulario.getNomeCompleto();
	          object[2] = formulario.getSexo();
	          object[3] = formulario.getDocumentoId();
	          object[4] = formulario.getDataEmissao();
	          object[5] = formulario.getDataDeNascimento();
	          object[6] = formulario.getNacionalidade();
	          object[7] = formulario.getBairro();
	          object[8] = formulario.getProvincia();
	          object[9] = formulario.getMunicipio();
	          object[10] = formulario.getEstadoCivil();
	          object[11] = formulario.getTelefone();
	          object[12] = formulario.getNomeDaMae();
	          object[13] = formulario.getNomeDoPai();
	          object[14] = formulario.getEmail();
	          object[15] = formulario.getNumeroDeContribuinte();
						object[16] = formulario.getHabilitacao ();
	          modelo.addRow(object);
	          //ordenarLista();
	        }
	      }
	    }catch (IOException ex) {}
	      int linha = table.getRowCount();
	      if(linha == 0)
	      {
	           JOptionPane.showMessageDialog(null, "Dados Não Encontados!!!", "ERRO NA ENTRADA DE DADOS",JOptionPane.ERROR_MESSAGE );
	      }
	  } // fim do Metodo

		public void mostrarTudo(){
	     modelo.setRowCount(0);
	     try
	     {
	       lista = gravador.lerTodos();
	       ClienteModelo formulario;
	       for( Gravavel gravavel : lista )
	       {
	         formulario = (ClienteModelo) gravavel;
	         Object[] object = new Object[18];
	         object[0]= formulario.getNumeroBi();
	         object[1]= formulario.getNomeCompleto();
	         object[1]= formulario.getSexo();
	         object[2]= formulario.getDocumentoId();
	         object[3]= formulario.getDataEmissao();
	         object[4]= formulario.getDataDeNascimento();
	         object[5]= formulario.getNacionalidade();
	         object[6]= formulario.getBairro();
	         object[7]= formulario.getProvincia();
	         object[9]= formulario.getMunicipio();
	         object[10]= formulario.getEstadoCivil();
	         object[11]= formulario.getTelefone();
	         object[12]= formulario.getNomeDaMae();
	         object[13]= formulario.getNomeDoPai();
	         object[14]= formulario.getEmail();
	         object[15]= formulario.getNumeroDeContribuinte();
					 object[16] = formulario.getHabilitacao ();
	         modelo.addRow(object);
	         ordenarLista();
	       }
	   }catch (IOException ex)
	    {
	     JOptionPane.showMessageDialog(this, "Ocorreu um erro ao fazer a leitura do ficheiro");
	    }
	  }

		public void ordenarLista(){
      if(table.getRowCount() > 0){
       Collections.sort(lista, controlo.getComparadorPessoa());
       modelo.setRowCount(0);
           ClienteModelo formulario;
           for( Gravavel gravavel : lista )
           {
             formulario = (ClienteModelo) gravavel;
             Object[] object = new Object[17];
             object[0] = formulario.getNumeroBi();
             object[1] = formulario.getNomeCompleto();
             object[2] = formulario.getSexo();
             object[3] = formulario.getDocumentoId();
             object[4] = formulario.getDataEmissao();
             object[5] = formulario.getDataDeNascimento();
             object[6] = formulario.getNacionalidade();
             object[7] = formulario.getBairro();
             object[8] = formulario.getProvincia();
             object[9] = formulario.getMunicipio();
             object[10] = formulario.getEstadoCivil();
             object[11] = formulario.getTelefone();
             object[12] = formulario.getNomeDaMae();
             object[13] = formulario.getNomeDoPai();
             object[14] = formulario.getEmail();
             object[15] = formulario.getNumeroDeContribuinte();
             modelo.addRow(object);
          }
      }else{
          JOptionPane.showMessageDialog(null, "Carregue primeiro os registos na tabela - click vet todos!!!");
      }
    }
	   //Tratamento de Eventos nos Botoes
	   public void actionPerformed(ActionEvent eventos)
	   {
		  if(eventos.getSource() == btnCancelar)
			  dispose();
		  else if (eventos.getSource() == btnPesquisar)
		  {
					pesquisaDefesa(numeroTitularesJtf.getSelectedItem ().toString ());
			}
		  else if(eventos.getSource() == btnVerTodos)
			    mostrarTudo();
	   }

     public static void main (String args[])
     {
			 Vector_Tabelas.inic();
       new FormDefesa ();
     }
}
