
public class Defs
{

	// Caminhos dos Ficheiros

	public static  final String filePais = "Ficheiros/pais.tab";
	public static  final String fileProvincias = "Ficheiros/provincia.tab";
	public static final String fileMunicipios = "Ficheiros/municipio.tab";
	public static  final String fileComunas = "Ficheiros/bairro.tab";

	public static  final String fileCargo = "Ficheiros/cargo.tab";
	public static final String fileDescricaoMaquina = "Ficheiros/descricaoMaquina.tab";
	public static  final String fileMarcaMaquina = "Ficheiros/marcaMaquina.tab";
	public static  final String fileModeloMarca = "Ficheiros/modeloMarca.tab";
	public static  final String fileEmailsSufixos = "Ficheiros/EmailsSufixos.tab";
	public static  final String fileTecnicos = "Ficheiros/tecnicos.tab";
	public static  final String fileFuncionarios = "Ficheiros/funcionarios.dat";
	public static  final String fileClientes = "Ficheiros/clientes.dat";
	public static  final String fileBIs = "Ficheiros/bis.dat";

	// Tipo de folha de registo selecionada

	public static int   FOLHAENTREGA = 8;
	public static int   FOLHALEVANTAMENTO = 9;


	//public static  final String fileClientes = "clientes.dat";
	//public static final String fileContas = "contas.dat";
	public static final String tmpFile = "___tmpfile";

	public static final int TAMANHO_NOMES = 40;
	public static final int TAMANHO_QUEIXA = 100;
      ///////////////////////////////////////////////////////////////
}
