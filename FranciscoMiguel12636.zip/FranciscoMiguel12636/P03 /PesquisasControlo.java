
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: FormDefesa.java
**  Nome: Francisco André Miguel
**	Data: 29 de Junho de 2016
**	Numero: 12636
**  Objectivo : Controlar Todas As Minhas Pesquisas
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.ArrayList;
import java.util.Date;

import java.text.*;
import java.util.List;
import yb.hashtableyb.Gravavel;

public class PesquisasControlo
{
  private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
  private GravadorClienteModelo gravador = new GravadorClienteModelo();
  private GravadorContaModelo gravadorConta = new GravadorContaModelo();

  public PesquisasControlo ()
  {

  }

  public int verificaDatasup (DataModelo data1,DataModelo data2)
  {
      if (data1.getAno () > data2.getAno ())	return 0;
      if (data1.getAno () < data2.getAno ())	return 1;
      if (data1.getAno () == data2.getAno ())
      {
        if (data1.getMes () > data2.getMes())	return 0;
        if (data1.getMes () < data2.getMes())	return 1;
          if (data1.getMes () == data2.getMes())
            {
              if (data1.getDia () > data2.getDia ())	return 0;
              if (data1.getDia () < data2.getDia ())	return 1;
            }
      }
      return -1;
  }

		public Vector<String> carregarNomeJList()
	  {
	    Vector<String> listaNumeroConta = new Vector<String>();
	    try
	    {
	       ClienteModelo modelo;
	       lista = gravador.lerTodos();
	       for(Gravavel gravavel : lista)
	       {
	         modelo = (ClienteModelo) gravavel;
           listaNumeroConta.add(modelo.getNomeCompleto());
	       }
	     }catch(IOException e){}
	    return listaNumeroConta;
	  }

  	public Comparator getComparadorClienteNome()
     {
         return new Comparator()
         {

             public int compare(Object o1, Object o2)
             {
                 ClienteModelo dado1 = ( ClienteModelo ) o1;
                 ClienteModelo dado2 = ( ClienteModelo ) o2;

                 return dado1.getNomeCompleto().compareToIgnoreCase(dado2.getNomeCompleto());
             }
         };
     }
     public Comparator getComparadorPessoa()
      {
          return new Comparator()
          {

              public int compare(Object o1, Object o2)
              {
                  ClienteModelo dado1 = ( ClienteModelo ) o1;
                  ClienteModelo dado2 = ( ClienteModelo ) o2;

                  return dado1.getNomeCompleto().compareToIgnoreCase(dado2.getNomeCompleto());
              }
          };
      }

    public  Vector<String> getApelidos()
 		{
 			Vector<String> vector = new Vector<String>();
 			ClienteModelo modelo;
 			try
 			{
 				lista = gravador.lerTodos();
 				for( Gravavel gravavel : lista )
 				{
 					modelo = (ClienteModelo) gravavel;
 					String[] nomeSeparado = modelo.getNomeCompleto().split(" ");
          if (!vector.contains(nomeSeparado[nomeSeparado.length - 1]))
 					    vector.add(nomeSeparado[nomeSeparado.length - 1]);
 				}
 			}catch (IOException ex) {}
 			Collections.sort(vector);
 			return vector;
 		}

    public  Vector<String> getTipoContas()
 		{
 			Vector<String> vector = new Vector<String>();
 			ContaModelo modelo;
 			try
 			{
 				lista = gravadorConta.lerTodos();
 				for( Gravavel gravavel : lista )
 				{
 					modelo = (ContaModelo) gravavel;
 					if (!vector.contains(modelo.getTipoConta ().toString ()))
 					    vector.add(modelo.getTipoConta ().toString ());
 				}
 			}catch (IOException ex) {}
 			Collections.sort(vector);
 			return vector;
 		}

    public  Vector<String> getNumeroTitular()
 		{
 			Vector<String> vector = new Vector<String>();
 			ContaModelo modelo;
 			try
 			{
 				lista = gravadorConta.lerTodos();
 				for( Gravavel gravavel : lista )
 				{
 					modelo = (ContaModelo) gravavel;
 					if (!vector.contains(modelo.getNumeroConta ().toString ()))
 					    vector.add(modelo.getNumeroConta ().toString ());
 				}
 			}catch (IOException ex) {}
 			Collections.sort(vector);
 			return vector;
 		}





    public  Vector<String> getDominioEmail()
 		{
 			Vector<String> vector = new Vector<String>();
 			ClienteModelo modelo;
 			try
 			{
 				lista = gravador.lerTodos();
 				for( Gravavel gravavel : lista )
 				{
 					modelo = (ClienteModelo) gravavel;
 					String[] emailSeparado = modelo.getEmail().split("@");
          if (!vector.contains(emailSeparado[emailSeparado.length - 1]))
 					    vector.add(emailSeparado[emailSeparado.length - 1]);
 				}
 			}catch (IOException ex) {}
 			Collections.sort(vector);
 			return vector;
 		}
}
