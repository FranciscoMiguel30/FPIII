public class Definicoes
{
   public static  final String FILEPROVINCIAS = "Ficheiros/provincias.tab";
   public static  final String FILEMUNICIPIOS = "Ficheiros/municipios.tab";
   public static  final String FILEBAIRROS = "Ficheiros/bairros.tab";
   public static  final String FILETIPOCONTA = "Ficheiros/tipoConta.tab";
   public static  final String FILESEXO = "Ficheiros/sexo.tab";
   public static  final String FILEREGIME = "Ficheiros/regime.tab";
   public static  final String FILEPESSOAS = "Ficheiros/pessoas.dat";
   public static  final String FILEBALCAO = "Ficheiros/balcao.tab";
   public static  final String FILEHABILITACAO = "Ficheiros/habilitacao.tab";
   public static  final String FILEORDEMDEPOSITO = "Ficheiros/ordemDeposito.tab";
   public static  final String FILEESTADOCIVIL = "Ficheiros/estadoCivil.tab";
   public static  final String FILEDOCUMENTOID = "Ficheiros/documentoId.tab";
   public static  final String FILENACIONALIDADE = "Ficheiros/nacionalidade.tab";
   public static  final String FILEDOMINIOEMAIL = "Ficheiros/dominioEmail.tab";
   public static  final String FILECLIENTES = "Ficheiros/clientes.dat";
   public static  final String FILEFUNCIONARIO = "Ficheiros/funcionario.dat";
   public static  final String FILECODIGOPESSOA = "Ficheiros/codigoPessoa.dat";
   public static  final String FILECODIGO = "Ficheiros/codigos.dat";
   public static  final String FILECODIGOCONTA = "Ficheiros/codigoConta.dat";
   public static  final String FILECODIGOFUNCIONARIO = "Ficheiros/codigoFuncionario.dat";
   public static  final String FILECONTAS = "Ficheiros/contas.dat";
}
