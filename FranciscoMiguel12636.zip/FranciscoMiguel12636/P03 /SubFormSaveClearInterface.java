import javax.swing.*;
public abstract class SubFormSaveClearInterface extends SubFormClearInterface 
	implements SaveClearInterface
{
	public void save() { }  // deve ser redefinido
}



