
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: AlterarClienteVisao.java
**	Objectivo: Formulario Do Cliente Para Alterar,Eliminar Clientes
**  Nome: Francisco André Miguel
**	Data: 19 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import yb.hashtableyb.GravadorGenericoHT;
import java.util.regex.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.text.*;


public class AlterarClienteVisao extends JFrame{

  private JPanel  painelCentro,painelBotoes;
  private JTextField nomeJtf,numeroDocumentoIdJtf,apelidoJtf,nomePaiJtf,nomeMaeJtf,dataNascimentoJtf,dataEmissaoJtf;
  private JTextField codigoClienteJtf,numeroDeContribuinteJtf,emailJtf;
  private JComboBoxPersonal provinciasJcb, municipiosJcb, bairrosJcb;
  private JFormattedTextField contactoJtf;
  private MaskFormatter mascara;
  private JButton okJb, limparJb,cancelJb;
  private JComboBoxTabela3_Tabela3 provinciasMunicipiosBairrosJcb;
  private JComboBox sexoJcb,estadoCivilJcb,documentoIdJcb,nacionalidadeJcb,habilitacaoJcb,dominioEmailJcb;
  private JTextFieldData dataEmissao,dataNascimento;

  public AlterarClienteVisao (String parmString, boolean btn){
    geraPainelBotoes();
    criaGui(parmString, btn);
    Container ct = this.getContentPane();
    ct.add(painelCentro, BorderLayout.CENTER);
    ct.add(painelBotoes, BorderLayout.SOUTH);
    setTitle("Formulario Cliente");
    setResizable(false);
    setDefaultCloseOperation (JFrame.DISPOSE_ON_CLOSE);
    setSize (600, 500);
    setLocationRelativeTo(null);
    TrataEventos eventos = new TrataEventos ();
    okJb.addActionListener (eventos);
    limparJb.addActionListener (eventos);
    cancelJb.addActionListener (eventos);
    setVisible(true);
	}

  private void criaGui (String dadoAlterar, boolean btn) {
    painelCentro = new JPanel();
    painelCentro.setLayout(new GridLayout( 12, 4));

    provinciasMunicipiosBairrosJcb = new JComboBoxTabela3_Tabela3(Definicoes.FILEPROVINCIAS, Definicoes.FILEMUNICIPIOS,
                                                                  Definicoes.FILEBAIRROS);

    addCodigoCliente ();
    addnumeroCliente ();
    addContacto ();
    addNomeCompleto ();
    addApelido ();
    addDataNascimento ();
    addProvincias ();
    addDocumentoId ();
    addMunicipios ();
    addDataEmissao ();
    addBairro ();
    addNomePai ();
    addNomeMae ();
    addNacionalidade ();
    addNumeroContribuinte ();
    addSexo ();
    addEstadoCivil ();
    addEmail ();
    addHabilitacao ();
    //Carrega o Dado a alterar
    procurarElemento(dadoAlterar);

  }


 public void procurarElemento(String dadoAlterar2)
 {
    ClienteModelo dadoAlterar = new ClienteModelo();
    GravadorClienteModelo gravador = new GravadorClienteModelo();
    try{

      dadoAlterar = (ClienteModelo)gravador.ler(dadoAlterar2.trim());
      if(dadoAlterar != null){
        codigoClienteJtf.setText( "" + dadoAlterar.getCodigo());
        numeroDocumentoIdJtf.setText(dadoAlterar.getNumeroBi());
        nomeJtf.setText(dadoAlterar.getNomeCompleto());
        apelidoJtf.setText(dadoAlterar.getApelido());
        nomePaiJtf.setText(dadoAlterar.getNomeDoPai());
        nomeMaeJtf.setText(dadoAlterar.getNomeDaMae());
        documentoIdJcb.setSelectedItem(dadoAlterar.getDocumentoId());
        nacionalidadeJcb.setSelectedItem(dadoAlterar.getNacionalidade());
        habilitacaoJcb.setSelectedItem(dadoAlterar.getHabilitacao());
        dataNascimentoJtf.setText(dadoAlterar.getDataDeNascimento());
        dataEmissaoJtf.setText(dadoAlterar.getDataEmissao());
        numeroDeContribuinteJtf.setText(dadoAlterar.getNumeroDeContribuinte());
        contactoJtf.setText(dadoAlterar.getTelefone());
        emailJtf.setText(dadoAlterar.getEmail());
        provinciasJcb.setSelectedItem(dadoAlterar.getProvincia());
        municipiosJcb.setSelectedItem(dadoAlterar.getMunicipio());
        bairrosJcb.setSelectedItem(dadoAlterar.getBairro());
        sexoJcb.setSelectedItem(dadoAlterar.getSexo());
        estadoCivilJcb.setSelectedItem(dadoAlterar.getEstadoCivil());

      }else {
      JOptionPane.showMessageDialog(null, "dado bum!");
      }

    }catch(IOException exp){
       JOptionPane.showMessageDialog(null, "Erro ao ler o ficheiro!");
    }
 }

public void addCodigoCliente ()
{
  painelCentro.add(new JLabel ("Codigo Cliente"));
  codigoClienteJtf = new JTextField ();
  codigoClienteJtf.setEnabled (false);
  painelCentro.add(codigoClienteJtf);
}
 public void addnumeroCliente ()
 {
   painelCentro.add(new JLabel ("Nº BI"));
   numeroDocumentoIdJtf = new JTextField ();
   painelCentro.add(numeroDocumentoIdJtf);
 }

 public void addContacto ()
 {
   try{
      mascara = new MaskFormatter ("#########");
      mascara.setPlaceholderCharacter ('_');
   }
   catch (ParseException e){}
   painelCentro.add(new JLabel ("  Nº De Telefone"));
   contactoJtf = new JFormattedTextField (mascara);
   painelCentro.add (contactoJtf);
 }

 public void addNomeCompleto ()
 {

   painelCentro.add(new JLabel ("Nome Completo"));
   nomeJtf = new JTextField ();
   painelCentro.add(nomeJtf);
 }

 public void addApelido ()
 {
   apelidoJtf = new JTextField ();
   painelCentro.add( new JLabel ("Apelido"));
   painelCentro.add(apelidoJtf);
 }

 public void addHabilitacao ()
 {
   habilitacaoJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEHABILITACAO).getItems () );
   painelCentro.add( new JLabel ("  Habilitacao"));
   painelCentro.add(habilitacaoJcb);
 }

 public void addDataNascimento ()
 {
   painelCentro.add( new JLabel ("Data de Nascimento"));
   DataPanel dataNascimentoPainel = new DataPanel("Data de Nascimento");
   dataNascimentoJtf = dataNascimentoPainel.getDTestField();
   painelCentro.add(dataNascimentoPainel);
 }

 public void addProvincias ()
 {
   painelCentro.add(new JLabel ("Provincia"));
   provinciasJcb = provinciasMunicipiosBairrosJcb.getComboBoxFather();
   painelCentro.add(provinciasJcb);
 }

 public void addDocumentoId ()
 {
   documentoIdJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEDOCUMENTOID).getItems () );
   painelCentro.add( new JLabel ("Doc. de Identificação"));
   painelCentro.add(documentoIdJcb);
 }

 public void addMunicipios ()
 {
   painelCentro.add(new JLabel ("Municipio"));
   municipiosJcb = provinciasMunicipiosBairrosJcb.getComboBoxSun();
   painelCentro.add(municipiosJcb);
 }

 public void addDataEmissao ()
 {
   painelCentro.add(new JLabel ("Data De Emissão"));
   DataPanel dataEmissaoPainel = new DataPanel("");
   dataEmissaoJtf = dataEmissaoPainel.getDTestField();
   painelCentro.add(dataEmissaoPainel);
 }

 public void addBairro ()
 {
   painelCentro.add(new JLabel ("Bairro"));
   bairrosJcb = provinciasMunicipiosBairrosJcb.getComboBoxNeto();
   painelCentro.add(bairrosJcb);
 }

 public void addNomePai ()
 {
   nomePaiJtf = new JTextField ();
   painelCentro.add(new JLabel ("Nome Do Pai"));
   painelCentro.add(nomePaiJtf);
 }

 public void addNomeMae ()
 {
   nomeMaeJtf = new JTextField ();
   painelCentro.add(new JLabel ("Nome da Mãe"));
   painelCentro.add(nomeMaeJtf);
 }

 public void addNacionalidade ()
 {
   nacionalidadeJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILENACIONALIDADE).getItems () );
   painelCentro.add(new JLabel ("Nacionalidade"));
   painelCentro.add(nacionalidadeJcb);
 }

 public void addNumeroContribuinte ()
 {
   numeroDeContribuinteJtf = new JTextField ();
   painelCentro.add(new JLabel ("Nº de Contribuinte"));
   painelCentro.add (numeroDeContribuinteJtf);
 }

 public void addSexo ()
 {
   sexoJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILESEXO).getItems () );
   painelCentro.add(new JLabel ("Sexo"));
   painelCentro.add(sexoJcb);
 }

 public void addEstadoCivil ()
 {
   estadoCivilJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEESTADOCIVIL).getItems () );
   painelCentro.add( new JLabel ("Estado Civil"));
   painelCentro.add(estadoCivilJcb);
 }

 public void addEmail ()
 {
   emailJtf = new JTextField ();
   painelCentro.add(new JLabel ("Email"));
   painelCentro.add (emailJtf);
 }

 public int getCodigoCliente ()
 {
   return Integer.parseInt (codigoClienteJtf.getText ().toString ().trim ());
 }

 public String getNumeroDocumentoIdJtf ()
 {
   return numeroDocumentoIdJtf.getText ().toString ().trim ();
 }

 public String getContactoJtf ()
 {

   return contactoJtf.getText ().toString ().trim ();
 }

 public String getNomeJtf ()
 {
   return nomeJtf.getText ().toString ().trim ();
 }

 public String getApelidoJtf ()
 {
   return apelidoJtf.getText ().toString ().trim ();
 }

 public String getNacionalidadeJcb ()
 {
   return nacionalidadeJcb.getSelectedItem().toString ();
 }

 public String getSexoJcb ()
 {
   return sexoJcb.getSelectedItem().toString ();
 }

 public String getEstadoCivilJcb ()
 {
   return estadoCivilJcb.getSelectedItem().toString ();
 }

 public String getHabilitacaoJcb ()
 {
   return habilitacaoJcb.getSelectedItem().toString ();
 }

 public String getNomePaiJtf ()
 {
   return nomePaiJtf.getText ().toString ().trim ();
 }

 public String getNomeMaeJtf ()
 {
   return nomeMaeJtf.getText ().toString ().trim ();
 }

 public String getNumeroDeContribuinteJtf ()
 {
   return numeroDeContribuinteJtf.getText ().toString ().trim ();
 }

 public String getEmailJtf ()
 {
   return emailJtf.getText ().toString ().trim ();
 }

 public String getDocumentoIdJcb ()
 {
   return documentoIdJcb.getSelectedItem().toString ();
 }

 public String getDominioEmail ()
 {
   return dominioEmailJcb.getSelectedItem().toString ();
 }

 public String getProvincia ()
 {
   return provinciasJcb.getSelectedItem().toString ();
 }

 public String getMunicipio ()
 {
   return municipiosJcb.getSelectedItem().toString ();
 }

 public String getBairro ()
 {
   return bairrosJcb.getSelectedItem().toString ();
 }

 public void limparFormulario()
 {
   contactoJtf.setText("");
   nomeJtf.setText("");
   apelidoJtf.setText("");
   nomePaiJtf.setText("");
   nomeMaeJtf.setText("");
   numeroDeContribuinteJtf.setText("");
   dataNascimentoJtf.setText("");
   dataEmissaoJtf.setText("");
   emailJtf.setText("");
 }//Fim do metodo limparFormulario()--------------------------------------------------------

 public void actualizarDados()
 {
    ClienteModelo modelo = new ClienteModelo();
    GravadorClienteModelo gravador = new GravadorClienteModelo();
    ListarClientes list;

    modelo.setCodigo (getCodigoCliente ());
    modelo.setNumeroBi(getNumeroDocumentoIdJtf ());
    modelo.setNomeCompleto(getNomeJtf ());
    modelo.setApelido(getApelidoJtf ());
    modelo.setNumeroDeContribuinte(getNumeroDeContribuinteJtf ());
    modelo.setEstadoCivil(getEstadoCivilJcb ());
    modelo.setDataDeNascimento(dataNascimentoJtf.getText ().trim ());
    modelo.setProvincia(getProvincia ());
    modelo.setMunicipio(getMunicipio ());
    modelo.setBairro( getBairro ());
    modelo.setNomeDoPai(getNomePaiJtf ());
    modelo.setNomeDaMae(getNomeMaeJtf ());
    modelo.setNacionalidade(getNacionalidadeJcb ());
    modelo.setHabilitacao(getHabilitacaoJcb ());
    modelo.setEmail(getEmailJtf ());
    modelo.setSexo(getSexoJcb ());
    modelo.setTelefone(getContactoJtf ());
    modelo.setDocumentoId(getDocumentoIdJcb ());
    modelo.setDataEmissao(dataEmissaoJtf.getText ().trim ());
    //lista = gravador.lerTodos();

    String oldKey = getNumeroDocumentoIdJtf ();
    try
        {

    if( gravador.editar(oldKey, modelo))
            {
                JOptionPane.showMessageDialog(this, "Dados alterados com sucesso","Alterar",JOptionPane.INFORMATION_MESSAGE);
                this.dispose();
                list = new ListarClientes (true);
                list.mostrarTudo ();
            }
    else
    if(oldKey != (String) modelo.getChave())
        {
           list = new ListarClientes ();
           gravador.editar(oldKey, modelo);
           JOptionPane.showMessageDialog(this, "Dados alterados com sucesso","Alterar",JOptionPane.INFORMATION_MESSAGE);
           this.dispose();
           list = new ListarClientes (true);
           list.mostrarTudo ();
        }
          else
          {
              JOptionPane.showMessageDialog(this, "Nao foi possivel alterar os dados\n Verifique se ja nao existe um cliente com o mesmo nome","Alterar",JOptionPane.ERROR_MESSAGE);
          }
        }
        catch (IOException e)
        {
            JOptionPane.showMessageDialog(this, "Erro ao alterar o registo");
        }
 }

  public void geraPainelBotoes()
  {
    painelBotoes = new JPanel();
    okJb = new JButton("Alterar");
    limparJb = new JButton("Limpar");
    cancelJb = new JButton("Cancelar");
    painelBotoes.setLayout(new FlowLayout());
    painelBotoes.add(okJb);
    painelBotoes.add(limparJb);
    painelBotoes.add(cancelJb);
  }

  private class TrataEventos implements ActionListener
  {
      public void actionPerformed(ActionEvent evento)
      {
          if (evento.getSource() == okJb)
          {
              actualizarDados();
          }//Fim Botao Salvar--------------------------------------------------------

          else if (evento.getSource() == cancelJb)
          {
              dispose ();
          }//Fim Botao cancelar--------------------------------------------------------

          else if (evento.getSource() == limparJb)
          {
              limparFormulario();
          }//Fim Botao Limpar -------------------------------------------------------
      }
  }//Fim Da Classe TrataEventos -----------------------------------------------------
}
