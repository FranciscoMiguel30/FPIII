


	/*******************************************************************************************************************
	********************************************************************************************************************
	**
	**	Nome do ficheiro: MessageSystem.java
	**	Autor: Francisco André Miguel
	**	Data:	20 de Maio de 2013
	**	Número: 12636
	**	Descricão: Responsável pelas mensagens que o Sistema emite ao fazer ou tentar fazer certas operações
	**
	*********************************************************************************************************************
	*********************************************************************************************************************!

	*/

	public class MessageSystem
	{

		public static String SUCESSO_MENSAGEM = "Operação concluída com sucesso ! ";

		public static String CAMPO_VAZIO_MENSAGEM = "Existência de pelo menos um campo vazio ! ";

		public static String DADOS_REDUNDANTES_MENSAGEM = "Dado redundante ! ";

		public static String ERRO_LOGIN_MENSAGEM = "Usuário ou Senha errada !";

		public static String ERRO_NOME_MENSAGEM = " inválido !\nOBS: Um nome não deve incluir números nem caracteres especiais !";

		public static String ERRO_TELEFONE_MENSAGEM = "Número de telefone inválido !\nOBS: Não deve conter letras, caracteres de separação, nem indicativos ( Ex.: +244 )  !";

		public static String ERRO_EMAIL_MENSAGEM = "Email inválido !\nOBS: Certifique-se de seguir o padrão: yyy@hhh.--- !";

		public static String ERRO_DATA_MENSAGEM = "Idade inválida !\nOBS: A idade mínima é ";

		public static String ERRO_REDUNDANCIA_MENSAGEM = " O dado a inserir já existe no ficheiro ! ";

		public static String ERRO_BUSCA_MENSAGEM = " Nenhum dado correspondente ao valor de busca foi encontrado ! ";

		public static String ERRO_TABELA_VAZIA_MENSAGEM = " A tabela está vazia ! ";

		public static String ERRO_TABELA_NAO_SELECAO_MENSAGEM= " Nenhum dos dados da tabela foi selecionado ! ";

		public static String ERRO_NUM_DADOS_SELECAO_MENSAGEM = " Para a operação em questão apenas um dado pode ser selecionado ! ";

		public static String ERRO_REMOCAO_CORRESPONDENCIA_DESPACHADA = " As correspondências despachadas não podem ser removidas ! ";

		public static String ERRO_REMOCAO_ALUNO_COM_CORRESPONDENCIA = "Os alunos associados à correspondências não podem ser removidos!";

		public static String ERRO_REMOCAO_FUNCIONARIO_COM_CORRESPONDENCIA = "Os funcionários associados à correspondências não podem ser removidos!";

		public static String ERRO_DATA_ENTRADA_VERSUS_DATA_DESPACHO = "A data de entrada não pode ser superior a data de despacho ! ";

		public static String ERRO_DATA_DESPACHO_VERSUS_DATA_EXIBICAO = "A data de despacho não pode ser superior a data de exibição ! ";



	}
