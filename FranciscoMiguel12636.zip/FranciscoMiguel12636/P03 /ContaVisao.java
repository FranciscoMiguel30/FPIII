
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: ContaVisao.java
**	Objectivo: Formulario Da Conta
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import java.util.regex.*;
import yb.hashtableyb.GravadorGenericoHT;
import java.io.*;
import java.util.regex.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.text.*;

public class ContaVisao extends JFrame
{
  private JPanel painelCentro,painelBotoes,painelTipoConta;
  private JTextField saldoJtf,numeroContaJtf,nomeJtf,nomeFuncionarioJtf,titular2Jtf,titular3Jtf;
  private JComboBox codigoClienteJcb,codigoFuncionarioJcb;
  private JTextFieldData dataAberturaJtfd;
  private JComboBox tipoContaJcb,balcaoJcb,ordemDepositoJcb,codigoTitular2Jcb,codigoTitular3Jcb;

  private JButton okJb,limparJb,cancelJb;
  private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
  private GravadorClienteModelo gravador = new GravadorClienteModelo();
  private GravadorFuncionarioModelo gravadorFuncionario = new GravadorFuncionarioModelo();


  public ContaVisao ()
  {
    super("Formulario De Conta - BFA");

    geraPainelCentro();
    geraPainelBotoes();
    Container ct = this.getContentPane();
    ct.add(painelTipoConta, BorderLayout.NORTH);
    ct.add(painelCentro, BorderLayout.CENTER);
    ct.add(painelBotoes, BorderLayout.SOUTH);
    pack ();
    painelCentro.setBorder ( new TitledBorder (new BevelBorder(1,Color.black,Color.black)," Criar Conta ") );
    //setSize(300, 200);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setLocationRelativeTo ( null );
    setVisible(true);
    TrataEventos eventos = new TrataEventos ();
    okJb.addActionListener (eventos);

    codigoTitular2Jcb.addActionListener ( new EventoComboBox ( ) );
    codigoTitular3Jcb.addActionListener ( new EventoComboBox ( ) );
    tipoContaJcb.addActionListener ( new EventoComboBox ( ) );
    codigoClienteJcb.addActionListener ( new EventoComboBox ( ) );
    codigoFuncionarioJcb.addActionListener ( new EventoComboBox ( ) );
    limparJb.addActionListener (eventos);
    cancelJb.addActionListener (eventos);

  }

  public void geraPainelCentro()
  {
    painelCentro = new JPanel();
    painelCentro.setLayout(new GridLayout( 14,1));

    addNumeroConta ();
    addnumeroPessoa ();
    addNomeCompleto ();
    addCodigoTitular2 ();
    addTitular2 ();
    addCodigoTitular3 ();
    addTitular3 ();
    addCodigoFuncionario ();
    addNomeFuncionario ();
    addSaldo ();
    addDataAbertura ();
    addTipoConta ();
    addBalcao ();
    addOrdemDeposito ();

  }

  public JPanel createPanelDataAbertura()
  {
    JPanel panel = new JPanel();
    panel.setLayout(new GridLayout(1, 2));
    dataAberturaJtfd = new JTextFieldData ("");
    panel.add (dataAberturaJtfd.getDTestField());
    panel.add (dataAberturaJtfd.getDButton());
    return panel;
  }

  public int geraNumConta()
  {
      GeraCodigo gerar = new GeraCodigo();
      int cod = gerar.getNumConta();
      return cod;
  }// Fim do metodo geraNumPessoa()--------------------------------------------------------

  public void incrementaNumeroConta(int codPessoa)
  {
      GeraCodigo gerar = new GeraCodigo ();
      gerar.setNumConta(codPessoa + 1);
  }//Fim do metodo incrementaNumeroDoPessoa(int codPessoa)-------------------------------------------

  public Vector<String> carregarCodigoCliente(){
    Vector<String> listaCode = new Vector<String>();
    try
    {
       ClienteModelo modelo;
       lista = gravador.lerTodos();
       for(Gravavel gravavel : lista)
       {
         modelo = (ClienteModelo) gravavel;
         String codigo = "1";
         listaCode.addElement(codigo.valueOf(modelo.getCodigo()));
       }
     }catch(IOException e){}
    return listaCode;
  }

  public Vector<String> carregarCodigoFuncionario(){
    Vector<String> listaCode = new Vector<String>();
    try
    {
       FuncionarioModelo modelo;
       lista = gravadorFuncionario.lerTodos();
       for(Gravavel gravavel : lista)
       {
         modelo = (FuncionarioModelo) gravavel;
         listaCode.add(modelo.getCodigoFuncionario());
       }
     }catch(IOException e){}
    return listaCode;
  }

  private class EventoComboBox implements ActionListener
  {
    public void actionPerformed ( ActionEvent evento )
    {
      if ( evento.getSource ( ) ==  codigoClienteJcb)
          preencherNomeClienteModelo ( nomeDoClienteModelo (Integer.parseInt (codigoClienteJcb.getSelectedItem ().toString ().trim ())));
      else if (evento.getSource ( ) ==  codigoFuncionarioJcb)
          preencherNomeFuncionariModelo (nomeDoFuncionarioModelo (codigoFuncionarioJcb.getSelectedItem().toString ().trim ()));
      else if (evento.getSource ( ) ==  codigoTitular2Jcb)
          preencherTitular2Modelo (titular2ClienteModelo (Integer.parseInt (codigoTitular2Jcb.getSelectedItem().toString ().trim ())));
      else if (evento.getSource ( ) ==  codigoTitular3Jcb)
          preencherTitular3Modelo (titular3ClienteModelo (Integer.parseInt (codigoTitular3Jcb.getSelectedItem().toString ().trim ())));
      else if (evento.getSource ( ) ==  tipoContaJcb)
        {
          if (tipoContaJcb.getSelectedItem().toString().equals ("Individual"))
            {
              codigoTitular2Jcb.setEnabled (false);
              codigoTitular3Jcb.setEnabled (false);
            }
            else
            {
              codigoTitular2Jcb.setEnabled (true);
              codigoTitular3Jcb.setEnabled (true);
            }
        }
    }
  }


  public ClienteModelo nomeDoClienteModelo ( int codigo )
  {

    try
    {
       lista = gravador.lerTodos();
       ClienteModelo modelo;
       for(Gravavel gravavel : lista)
       {
         modelo = (ClienteModelo) gravavel;
         //JOptionPane.showMessageDialog (null,"nome ComboBox : " + nome + "nome File" + modelo.getNomeCompleto () );
         if (codigo == modelo.getCodigo ())
            return modelo;
       }
     }catch(IOException e){}
    return new ClienteModelo ( );
  }

  public ClienteModelo titular2ClienteModelo ( int codigo )
  {

    try
    {
       lista = gravador.lerTodos();
       ClienteModelo modelo;
       for(Gravavel gravavel : lista)
       {
         modelo = (ClienteModelo) gravavel;
         if (codigo == modelo.getCodigo ())
            return modelo;
       }
     }catch(IOException e){}
    return new ClienteModelo ( );
  }

  public ClienteModelo titular3ClienteModelo ( int codigo )
  {

    try
    {
       lista = gravador.lerTodos();
       ClienteModelo modelo;
       for(Gravavel gravavel : lista)
       {
         modelo = (ClienteModelo) gravavel;
         if (codigo == modelo.getCodigo ())
            return modelo;
       }
     }catch(IOException e){}
    return new ClienteModelo ( );
  }

  public FuncionarioModelo nomeDoFuncionarioModelo ( String codigo )
  {

    try
    {
       lista = gravadorFuncionario.lerTodos();
       FuncionarioModelo modelo;
       for(Gravavel gravavel : lista)
       {
         modelo = (FuncionarioModelo) gravavel;
         if (codigo.equals (modelo.getCodigoFuncionario ()))
            return modelo;
       }
     }catch(IOException e){}
    return new FuncionarioModelo ( );
  }

  public Vector<String> OrdenarcarregarCodigo( Vector<String> codigos){
    Collections.sort (codigos);
    return codigos;
  }

  public void preencherNomeClienteModelo ( ClienteModelo cliente )
  {
    nomeJtf.setText ("" + cliente.getNomeCompleto ( ) );
  }

  public void preencherTitular2Modelo ( ClienteModelo cliente )
  {
    titular2Jtf.setText ("" + cliente.getNomeCompleto ( ) );
  }

  public void preencherTitular3Modelo ( ClienteModelo cliente )
  {
    titular3Jtf.setText ("" + cliente.getNomeCompleto ( ) );
  }

  public void preencherNomeFuncionariModelo ( FuncionarioModelo funcionario )
  {
    nomeFuncionarioJtf.setText ("" + funcionario.getNomeCompleto ( ) );
  }

  public void addNumeroConta ()
  {
    painelCentro.add (new JLabel ("Numero Da Conta"));
    numeroContaJtf = new JTextField ("" + geraNumConta ());
    numeroContaJtf.setEnabled (false);
    painelCentro.add (numeroContaJtf);
  }

  public void addnumeroPessoa ()
  {
    painelCentro.add(new JLabel ("Codigo Do 1º Titular"));
    codigoClienteJcb = new JComboBox ( OrdenarcarregarCodigo (carregarCodigoCliente ()));
    painelCentro.add(codigoClienteJcb);
  }

  public void addCodigoTitular2 ()
  {
    painelCentro.add(new JLabel ("Codigo Do 2º Titular"));
    codigoTitular2Jcb = new JComboBox ( OrdenarcarregarCodigo (carregarCodigoCliente ()));
    codigoTitular2Jcb.setEnabled (false);
    painelCentro.add(codigoTitular2Jcb);
  }

  public void addCodigoTitular3 ()
  {
    painelCentro.add(new JLabel ("Codigo Do 3º Titular"));
    codigoTitular3Jcb = new JComboBox ( OrdenarcarregarCodigo (carregarCodigoCliente ()));
    codigoTitular3Jcb.setEnabled (false);
    painelCentro.add(codigoTitular3Jcb);
  }

  public void addCodigoFuncionario ()
  {
    painelCentro.add(new JLabel ("Codigo Do Funcionario"));
    codigoFuncionarioJcb = new JComboBox ( OrdenarcarregarCodigo (carregarCodigoFuncionario ()));
    painelCentro.add(codigoFuncionarioJcb);
  }

  public void addNomeFuncionario ()
  {
    painelCentro.add(new JLabel ("Nome Do Funcionario"));
    nomeFuncionarioJtf = new JTextField ();
    nomeFuncionarioJtf.setEnabled (false);
    painelCentro.add(nomeFuncionarioJtf);
  }

  public void addNomeCompleto ()
  {
    painelCentro.add(new JLabel ("Nome Do Cliente"));
    nomeJtf = new JTextField ();
    nomeJtf.setEnabled (false);
    painelCentro.add(nomeJtf);
  }

  public void addTitular2 ()
  {
    painelCentro.add(new JLabel ("Nome Do 2º Titular"));
    titular2Jtf = new JTextField ();
    titular2Jtf.setEnabled (false);
    painelCentro.add(titular2Jtf);
  }

  public void addTitular3 ()
  {
    painelCentro.add(new JLabel ("Nome Do 3º Titular"));
    titular3Jtf = new JTextField ();
    titular3Jtf.setEnabled (false);
    painelCentro.add(titular3Jtf);
  }

  public void addSaldo ()
  {
    painelCentro.add(new JLabel ("Saldo"));
    saldoJtf = new JTextField ();
    painelCentro.add(saldoJtf);
  }

  public void addDataAbertura ()
  {
    painelCentro.add( new JLabel ("Data de Abertura"));
    painelCentro.add(createPanelDataAbertura());
  }

  public void addTipoConta ()
  {
    painelTipoConta = new JPanel (new FlowLayout ());
    painelTipoConta.setBorder (new TitledBorder (""));
    tipoContaJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILETIPOCONTA).getItems () );
    painelTipoConta.add( new JLabel ("Tipo De Conta"));
    painelTipoConta.add(tipoContaJcb);
  }

  public void addBalcao ()
  {
    balcaoJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEBALCAO).getItems () );
    painelCentro.add( new JLabel ("Balcao"));
    painelCentro.add(balcaoJcb);
  }

  public void addOrdemDeposito ()
  {
    ordemDepositoJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEORDEMDEPOSITO).getItems () );
    painelCentro.add( new JLabel ("Ordem De Deposito"));
    painelCentro.add(ordemDepositoJcb);
  }

  public void geraPainelBotoes()
  {
    painelBotoes = new JPanel();
    okJb = new JButton("Ok");
    limparJb = new JButton("Limpar");
    cancelJb = new JButton("Cancelar");
    painelBotoes.setLayout(new FlowLayout());
    painelBotoes.add(okJb);
    painelBotoes.add(limparJb);
    painelBotoes.add(cancelJb);
  }

  public void limparFormulario()
  {
    dataAberturaJtfd.setDtestField("");
    saldoJtf.setText("");
    tipoContaJcb.setSelectedItem("");
    balcaoJcb.setSelectedItem("");
    ordemDepositoJcb.setSelectedItem("");
  }//Fim do metodo limparFormulario()--------------------------------------------------------


  public ContaModelo pegarModelo ()
  {
    ContaModelo modelo = new ContaModelo();
    modelo.setCodigoCliente (codigoClienteJcb.getSelectedItem().toString ());
    modelo.setNomeCompleto (nomeJtf.getText().toString ());
    modelo.setCodigoTitular2 (codigoTitular2Jcb.getSelectedItem().toString ());
    modelo.setTitular2 (titular2Jtf.getText().toString ());
    modelo.setCodigoTitular3 (codigoTitular3Jcb.getSelectedItem().toString ());
    modelo.setTitular3 (titular3Jtf.getText().toString ());
    modelo.setCodigoFuncionario (codigoFuncionarioJcb.getSelectedItem().toString ());
    modelo.setNomeCompletoFuncionario (nomeFuncionarioJtf.getText().toString ());
		modelo.setNumeroConta (numeroContaJtf.getText().trim ());
    modelo.setSaldoConta (saldoJtf.getText().toString ().trim ());
    modelo.setDataAbertura ( dataAberturaJtfd.getDTestField().getText () );
    modelo.setTipoConta ( tipoContaJcb.getSelectedItem().toString ());
    modelo.setBalcao (balcaoJcb.getSelectedItem ().toString ());
    modelo.setOrdemDeposito (ordemDepositoJcb.getSelectedItem ().toString ());
    modelo.setDataLevantar ("");
    modelo.setDataDepositar ("");
    modelo.setDataTransferir ("");

    return modelo;
  }

  public void salvarFile ()
  {

      GravadorContaModelo gravador = new GravadorContaModelo();
        try
        {
            if (validarCampos ())
            {
              boolean gravou = gravador.gravar ( pegarModelo() );
              if (gravou)
              {

                  JOptionPane.showMessageDialog(null, "Registro Conta Gravado Com Sucesso","Sucessfull",JOptionPane.INFORMATION_MESSAGE);
                  int codigo = Integer.parseInt (numeroContaJtf.getText ().toString ().trim ());
                  incrementaNumeroConta(codigo);
                  limparFormulario ();
                  numeroContaJtf.setText("" + geraNumConta());
              }
              else
              {
                  JOptionPane.showMessageDialog(null, "Chave ja existente!", "Erro!",JOptionPane.ERROR_MESSAGE);
              }
            }
        }
        catch(IOException ex)
        {
            JOptionPane.showMessageDialog(this, "Erro ao gravar... A Conta");
        }
 }// Fim do metodo salvarFormularioPessoa() ------------------------------------------------


 public boolean validarSaldo(){
    Integer a ;
    try{
       a = new Integer(saldoJtf.getText().trim());
    }catch(NumberFormatException expt){
      return false;
    }
    return true;
  }

 Boolean validarCampos ()
 {
   if (nomeFuncionarioJtf.getText().isEmpty ())
   {
     JOptionPane.showMessageDialog (null,"Nao Existe Nome Do Funcionario, Meu Caro","ERROR",JOptionPane.ERROR_MESSAGE);
     return false;
   }
   else if (nomeJtf.getText().isEmpty ())
   {
     JOptionPane.showMessageDialog (null,"Nao Existe Nome Do Cliente, Meu Caro","ERROR",JOptionPane.ERROR_MESSAGE);
     return false;
   }
   else if (saldoJtf.getText().isEmpty () || !validarSaldo())
   {
     JOptionPane.showMessageDialog (null,"Digite O Saldo Da Conta, Meu Caro","ERROR",JOptionPane.ERROR_MESSAGE);
     return false;
   }
   else if (dataAberturaJtfd.getDTestField().getText ().isEmpty ())
   {
     JOptionPane.showMessageDialog (null,"Digite A Data De Abertura Da Conta","ERROR",JOptionPane.ERROR_MESSAGE);
     return false;
   }
   return true;
 }

 private class TrataEventos implements ActionListener
  {
    public void actionPerformed(ActionEvent evento)
    {
        if (evento.getSource() == okJb)
        {
            salvarFile ();
        }//Fim Botao Salvar--------------------------------------------------------

        else if (evento.getSource() == cancelJb)
        {
            dispose();
        }//Fim Botao cancelar--------------------------------------------------------

        else if (evento.getSource() == limparJb)
        {
            limparFormulario();
        }//Fim Botao Limpar -------------------------------------------------------
    }
  }//Fim Da Classe TrataEventos -----------------------------------------------------
}
