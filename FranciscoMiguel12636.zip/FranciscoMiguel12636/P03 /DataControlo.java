



	import java.util.GregorianCalendar;

	import java.util.Date;


	public class DataControlo
	{

		public DataControlo ( )
		{

		}


		public DataModelo montaData ( String dataStr )
		{

			DataModelo data = new DataModelo ( );

			String dataPartes [ ];

			if ( dataStr != null )
				if ( ! dataStr.trim ( ).isEmpty ( ) )
				{

					dataPartes = dataStr.split ( "-" );

					data.setDia ( Integer.parseInt ( dataPartes [ 0 ] ) );
					data.setMes ( tabelaMesInt ( dataPartes [ 1 ] ) );
					data.setAno ( Integer.parseInt ( dataPartes [ 2 ] ) );

					return data;

				}

			return null;

		}


		public int tabelaMesInt ( String mes )
		{

			if ( mes != null )
			{

				switch ( mes )
				{

					case "Jan": 	return 1;


					case "Fev": 	return 2;


					case "Mar": 	return 3;


					case "Abr": 	return 4;


					case "Mai": 	return 5;


					case "Jun": 	return 6;


					case "Jul": 	return 7;


					case "Ago": 	return 8;


					case "Set": 	return 9;


					case "Out": 	return 10;


					case "Nov": 	return 11;


					case "Dez": 	return 12;
				}

			}


			return -1;

		}


		public String tabelaIntMes ( int mes )
		{

			if ( mes > 0 && mes < 13 )
			{

				switch ( mes )
				{

					case 1: return "Jan";


					case 2: return "Fev";


					case 3: return "Mar";


					case 4: return "Abr";


					case 5: return "Mai";


					case 6: return "Jun";


					case 7: return "Jul";


					case 8: return "Ago";


					case 9: return "Set";


					case 10: return "Out";


					case 11: return "Nov";


					case 12: return "Dez";
				}

			}


			return null;

		}


		public String tabelaIntDiaSemana ( int diaSemana )
		{

			if ( diaSemana > 0 && diaSemana < 8 )
			{

				switch ( diaSemana )
				{

					case 2: return "Segunda-Feira";


					case 3: return "Terça-Feira";


					case 4: return "Quarta-Feira";


					case 5: return "Quinta-Feira";


					case 6: return "Sexta-Feira";


					case 7: return "Sábado";


					case 1: return "Domingo";
				}

			}


			return null;

		}


		public String montaData2 ( DataModelo data )
		{

			return "" + data.getDia ( ) + "-" + tabelaIntMes ( data.getMes ( ) ) + "-" + data.getAno ( );

		}


		public boolean validarIdade ( int anoNascimento, int idadeMinima )
		{

			int idade = ( new GregorianCalendar ( ).get ( GregorianCalendar.YEAR ) - anoNascimento );


			return ( idade >= idadeMinima && ( idade <= 100 ) );

		}


		public boolean intervalo ( Date dataInf, Date dataSup, Date data )
		{

			Date aux;


			if ( dataInf.after ( dataSup ) )
			{

				aux = new Date ( );

				aux = dataInf;
				dataInf = dataSup;
				dataSup = aux;

			}


			if ( data.after ( dataInf ) || data.equals ( dataInf ) )
				if ( data.before ( dataSup ) || data.equals ( dataSup ) )
					return true;


			return false;

		}

	}
