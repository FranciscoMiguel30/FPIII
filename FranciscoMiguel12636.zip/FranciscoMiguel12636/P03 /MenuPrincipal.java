/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: MenuPrincipal.java
**	Objectivo: Menu Principal do Software
**  Nome: Francisco André Miguel
**	Data: 9 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.event.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class MenuPrincipal extends JFrame implements ActionListener
{
	private JMenu ficheiroMenu, contasMenu,clientesMenu, pesquisasMenu,operacoesMenu,tabelasMenu, ajudaMenu;
	private JMenu funcionarioMenu,defesaMenu;
	private JMenuItem sairItem,logOutItem,defesaMenuItem;
	private JMenuItem novaContaItem, alterarContaItem, eliminarContaItem,consultasContasItem;
	private JMenuItem novoClienteItem,consultasClientesItem,eliminarClienteItem,alterarClienteItem;
	private JMenuItem alterarFuncionarioItem,eliminarFuncionarioItem;
	private JMenuItem listarContasItem,pesquisasClienteNomeItem;
	private JMenuItem novoFuncionarioItem,consultasFuncionarioItem;
	private JMenuItem pesquisarClientePorNumeroConta;
	private JMenuItem depositarItem,levantamentoItem,transferenciasItem,extractoItem;
	private JMenuItem provinciasItem,municipiosItem,bairrosItem,tipoContaItem,ordemDepositoItem,sexoItem,estadoCivilItem;
	private JMenuItem documentoIdItem,dominioEmailItem,nacionalidadeItem,balcaoItem,habilitacaoItem;
	private JMenuItem ajudaAutorItem, ajudaAplicacaoItem;
	private JMenuBar menuBar;
	private ImageSystem image;
	private JLabel lblFundo;

	public MenuPrincipal()
	{
		super ( "Banco Fomento De Angola - Menu Principal" );


		instanciarComponentes ();
		adicionarComponentes ();
		adicionarEventos ();
		image = new ImageSystem ();
		lblFundo = new JLabel (image.criarIcone (image.MENU_IMG));

		ImageIcon icon = new ImageIcon ( image.BFA_IMG );
    setIconImage ( icon.getImage ( ) );
		getContentPane( ).add ( lblFundo, BorderLayout.CENTER );
		setJMenuBar ( menuBar );
		setDefaultCloseOperation ( EXIT_ON_CLOSE );
		setSize ( 900, 674 );
		setLocationRelativeTo ( null );
		setVisible ( true );
		setResizable (false);

	}

	public void instanciarComponentes()
	{
		menuBar = new JMenuBar();
    ficheiroMenu = new JMenu ( "Ficheiro" );
		contasMenu = new JMenu ( "Contas" );
		clientesMenu = new JMenu ( "Clientes" );
		funcionarioMenu  = new JMenu ( "Funcionarios" );
		operacoesMenu = new JMenu ("Operacoes De Conta");
		pesquisasMenu = new JMenu ("Pesquisas");
		tabelasMenu = new JMenu ( "Tabelas" );
		ajudaMenu = new JMenu ( "Ajuda" );
		defesaMenu = new JMenu ( "Fundamentos De Programacao III" );

		novoClienteItem = new JMenuItem ( "Novo Cliente",image.criarIcone (image.ADD_IMG));
		alterarClienteItem = new JMenuItem ( "Alterar/Editar ",image.criarIcone (image.EDIT_IMG));
		eliminarClienteItem = new JMenuItem ( "Eliminar",image.criarIcone (image.DELETE_IMG));
		consultasClientesItem = new JMenuItem ( "Consultar ",image.criarIcone (image.FIND_IMG));

		novoFuncionarioItem = new JMenuItem ( "Novo Funcionario",image.criarIcone (image.ADD_IMG));
		alterarFuncionarioItem  = new JMenuItem ( "Alterar/Editar ",image.criarIcone (image.EDIT_IMG));
		eliminarFuncionarioItem = new JMenuItem ( "Eliminar",image.criarIcone (image.DELETE_IMG));
		consultasFuncionarioItem  = new JMenuItem ( "Consultar ",image.criarIcone (image.FIND_IMG));


		sairItem = new JMenuItem ( "Sair",image.criarIcone (image.ENCERRAR_IMG));
		logOutItem = new JMenuItem ( "Logout",image.criarIcone (image.LOGOUT_IMG));

		novaContaItem = new JMenuItem ( "Nova Conta",image.criarIcone (image.ADD_IMG));
		alterarContaItem = new JMenuItem ( "Alterar/Editar ",image.criarIcone (image.EDIT_IMG));
		eliminarContaItem = new JMenuItem ( "Eliminar",image.criarIcone (image.DELETE_IMG) );
		consultasContasItem =  new JMenuItem ( "Consultar",image.criarIcone (image.FIND_IMG) );

		pesquisasClienteNomeItem = new JMenuItem ( "Pesquisar Clientes Por Nome",image.criarIcone (image.SEARCH_IMG));
		pesquisarClientePorNumeroConta = new JMenuItem ( "Pesquisar Clientes Por Numero Da Conta",image.criarIcone (image.SEARCH_IMG));

		depositarItem = new JMenuItem ( "Depositar",image.criarIcone (image.DEPOSITAR_IMG) );
		levantamentoItem = new JMenuItem ( "Levantamento",image.criarIcone (image.LEVANTAR_IMG) );
		transferenciasItem = new JMenuItem ( "Transferencias",image.criarIcone (image.TRANSFERIR_IMG) );
		extractoItem =  new JMenuItem ( "Extracto",image.criarIcone (image.EXTRACTO_IMG) );

		provinciasItem = new JMenuItem ( "Provincias",image.criarIcone (image.TABELAS_BOTAO_IMG));
		municipiosItem = new JMenuItem ( "Municipios",image.criarIcone (image.TABELAS_BOTAO_IMG));
		bairrosItem = new JMenuItem ( "Bairros",image.criarIcone (image.TABELAS_BOTAO_IMG));
		tipoContaItem = new JMenuItem ( "Tipo De Contas",image.criarIcone (image.TABELAS_BOTAO_IMG) );
		ordemDepositoItem = new JMenuItem ( "Ordem De Deposito",image.criarIcone (image.TABELAS_BOTAO_IMG));
		sexoItem = new JMenuItem ( "Sexo",image.criarIcone (image.TABELAS_BOTAO_IMG));
		balcaoItem = new JMenuItem ( "Balcão",image.criarIcone (image.TABELAS_BOTAO_IMG));
		estadoCivilItem = new JMenuItem ( "Estado Civil ",image.criarIcone (image.TABELAS_BOTAO_IMG));
		documentoIdItem = new JMenuItem ( "Documento De Identificação",image.criarIcone (image.TABELAS_BOTAO_IMG));
		dominioEmailItem = new JMenuItem ( "Dominio De Email",image.criarIcone (image.TABELAS_BOTAO_IMG));
		nacionalidadeItem = new JMenuItem ( "Nacionalidade",image.criarIcone (image.TABELAS_BOTAO_IMG));
		habilitacaoItem = new JMenuItem ( "Habilitação",image.criarIcone (image.TABELAS_BOTAO_IMG));

		ajudaAutorItem = new JMenuItem ( "Sobre O Autor",image.criarIcone (image.HELP_IMG));
		ajudaAplicacaoItem = new JMenuItem ( "Sobre Aplicacao",image.criarIcone (image.HELP_IMG));

		defesaMenuItem =  new JMenuItem ( "Defesa Do Projecto",image.criarIcone (image.SEARCH_IMG));
	}

	public void adicionarComponentes()
	{
		menuBar.add ( ficheiroMenu );
		menuBar.add ( clientesMenu );
		menuBar.add ( funcionarioMenu );
		menuBar.add ( contasMenu );
		menuBar.add ( operacoesMenu );
		menuBar.add ( pesquisasMenu );
		menuBar.add ( tabelasMenu );
		menuBar.add ( ajudaMenu );
		menuBar.add ( defesaMenu );


	//------- items do menu ficheiro
		ficheiroMenu.add ( logOutItem );
		ficheiroMenu.add ( sairItem );

	//------- items do menu Clientes

		clientesMenu.add ( novoClienteItem );
		clientesMenu.add ( alterarClienteItem );
		clientesMenu.add ( eliminarClienteItem );
		clientesMenu.add ( consultasClientesItem );

	//------- items do menu Funcionario

		funcionarioMenu.add ( novoFuncionarioItem );
		funcionarioMenu.add ( alterarFuncionarioItem );
		funcionarioMenu.add ( eliminarFuncionarioItem );
		funcionarioMenu.add ( consultasFuncionarioItem );

	//------- items do menu de Pesquisas

		pesquisasMenu.add ( pesquisasClienteNomeItem );
		pesquisasMenu.add ( pesquisarClientePorNumeroConta );



	//------- items do menu Conta

		contasMenu.add ( novaContaItem );
		contasMenu.add ( alterarContaItem );
		contasMenu.add ( eliminarContaItem );
		contasMenu.add ( consultasContasItem );

	//------- items do menu operacoes

		operacoesMenu.add ( depositarItem );
		operacoesMenu.add ( levantamentoItem );
		operacoesMenu.add ( transferenciasItem );
		operacoesMenu.add ( extractoItem );

	//------- items do menu tabelas

		tabelasMenu.add (provinciasItem);
		tabelasMenu.add (municipiosItem);
		tabelasMenu.add (bairrosItem);
		tabelasMenu.add (tipoContaItem);
		tabelasMenu.add (ordemDepositoItem);
		tabelasMenu.add (sexoItem);
		tabelasMenu.add (estadoCivilItem);
		tabelasMenu.add (documentoIdItem);
		tabelasMenu.add (dominioEmailItem);
		tabelasMenu.add (nacionalidadeItem);
		tabelasMenu.add (balcaoItem);
		tabelasMenu.add (habilitacaoItem);


	//------- items do menu ajuda

		ajudaMenu.add ( ajudaAutorItem );
		ajudaMenu.add ( ajudaAplicacaoItem );

	//------- items do menu Defesa

		defesaMenu.add (defesaMenuItem);
	}

	public void adicionarEventos()
	{
		novaContaItem.addActionListener ( this );
		alterarContaItem.addActionListener ( this );
		eliminarContaItem.addActionListener ( this );
		consultasContasItem.addActionListener ( this );
		provinciasItem.addActionListener ( this );
		municipiosItem.addActionListener ( this );
		bairrosItem.addActionListener ( this );
		tipoContaItem.addActionListener ( this );
		ordemDepositoItem.addActionListener ( this );
		logOutItem.addActionListener ( this );
		sairItem.addActionListener ( this );
		sexoItem.addActionListener ( this );
		estadoCivilItem.addActionListener ( this );
		depositarItem.addActionListener ( this );
		levantamentoItem.addActionListener ( this );
		transferenciasItem.addActionListener ( this );
		extractoItem.addActionListener ( this );
		documentoIdItem.addActionListener ( this );
		dominioEmailItem.addActionListener ( this );
		nacionalidadeItem.addActionListener ( this );
		balcaoItem.addActionListener ( this );
		novoClienteItem.addActionListener ( this );
		pesquisasClienteNomeItem.addActionListener ( this );
		novoFuncionarioItem.addActionListener ( this );
		alterarClienteItem.addActionListener ( this );
		eliminarClienteItem.addActionListener ( this );
		pesquisarClientePorNumeroConta.addActionListener ( this );
		consultasClientesItem.addActionListener ( this );
		consultasFuncionarioItem.addActionListener ( this );
		alterarFuncionarioItem.addActionListener ( this );
		eliminarFuncionarioItem.addActionListener ( this );
		habilitacaoItem.addActionListener ( this );
		ajudaAutorItem.addActionListener ( this );
		ajudaAplicacaoItem.addActionListener ( this );
		defesaMenuItem.addActionListener ( this );
	}

	public void actionPerformed ( ActionEvent evt )
	{

	 if (evt.getSource() == provinciasItem)
			Tabela2.editarNovosItems(Definicoes.FILEPROVINCIAS, "Nova Provincia");
		else if (evt.getSource() == municipiosItem)
			Tabela3_2.editarNovosItems( Definicoes.FILEPROVINCIAS, Definicoes.FILEMUNICIPIOS, "Província", "Municipio", "Novo Municipio");
		else if (evt.getSource() == bairrosItem)
			Tabela3_3.editarNovosItems( Definicoes.FILEPROVINCIAS, Definicoes.FILEMUNICIPIOS, Definicoes.FILEBAIRROS, "Província", "Municipio",
			 														"Bairro", "Novo Bairro");
    else if ( evt.getSource () == tipoContaItem )
        Tabela2.editarNovosItems( Definicoes.FILETIPOCONTA, "Novo Tipo De Conta");
		else if ( evt.getSource () == balcaoItem )
				Tabela2.editarNovosItems( Definicoes.FILEBALCAO, "Novo Balcao");
	  else if ( evt.getSource () == ordemDepositoItem )
        Tabela2.editarNovosItems( Definicoes.FILEORDEMDEPOSITO, "Nova Ordem De Deposito");
		else if ( evt.getSource () == sexoItem )
	      Tabela2.editarNovosItems( Definicoes.FILESEXO, "Sexo");
		else if ( evt.getSource () == estadoCivilItem )
			  Tabela2.editarNovosItems( Definicoes.FILEESTADOCIVIL, "Estado Civil");
		else if ( evt.getSource () == documentoIdItem )
			  Tabela2.editarNovosItems( Definicoes.FILEDOCUMENTOID, "Documento De Identificação");
		else if ( evt.getSource () == dominioEmailItem )
			  Tabela2.editarNovosItems( Definicoes.FILEDOMINIOEMAIL, "Dominio De Email");
		else if ( evt.getSource () == nacionalidadeItem )
			  Tabela2.editarNovosItems( Definicoes.FILENACIONALIDADE, "Nacionalidade");
		else if ( evt.getSource () == habilitacaoItem )
			  Tabela2.editarNovosItems( Definicoes.FILEHABILITACAO, "Habilitação");
		else if ( evt.getSource () == logOutItem)
			{
				dispose ( );
				new Login ( ).show ( );
			}
		else if ( evt.getSource () == alterarClienteItem)
		{
			ListarClientes list =	new ListarClientes (true);
			list.show ();
			list.mostrarTudo ();
		}
		else if ( evt.getSource () == consultasContasItem )
			new ListarContas ().show ();
		else if ( evt.getSource () == alterarContaItem)
		{
			ListarContas list =	new ListarContas (true);
			list.show ();
			list.mostrarTudo ();
		}
		else if ( evt.getSource () == eliminarClienteItem)
		{
			ListarClientes list =	new ListarClientes (false);
			list.show ();
			list.mostrarTudo ();
		}
		else if ( evt.getSource () == eliminarContaItem)
		{
			ListarContas list =	new ListarContas (false);
			list.show ();
			list.mostrarTudo ();
		}
		else if ( evt.getSource () == novoClienteItem)
			new ClienteVisao ();
		else if ( evt.getSource () == novaContaItem)
			new ContaVisao ();
		else if ( evt.getSource () == sairItem)
			dispose ( );
		else if ( evt.getSource () == depositarItem)
			new DepositarVisao ();
		else if ( evt.getSource () == levantamentoItem)
			new LevantamentoVisao ();
		else if ( evt.getSource () == novoFuncionarioItem)
				new FuncionarioVisao ();
		else if ( evt.getSource () == alterarFuncionarioItem)
		{
			ListarFuncionarios list =	new ListarFuncionarios (true);
			list.show ();
			list.mostrarTudo ();
		}
		else if ( evt.getSource () == eliminarFuncionarioItem)
		{
			ListarFuncionarios list =	new ListarFuncionarios (false	);
			list.show ();
			list.mostrarTudo ();
		}
		else if ( evt.getSource () == consultasFuncionarioItem)
			new ListarFuncionarios ();
		else if ( evt.getSource () == transferenciasItem)
			new TransferenciasVisao ();
		else if ( evt.getSource ( ) == extractoItem)
			new ExtractoVisao ();
		else if ( evt.getSource ( ) == consultasClientesItem)
			new ListarClientes ();
		else if ( evt.getSource ( ) == pesquisasClienteNomeItem)
			new PesquisarClientePorNome ();
		else if ( evt.getSource ( ) == defesaMenuItem)
			new FormDefesa ();
		else if ( evt.getSource ( ) == pesquisarClientePorNumeroConta)
				new PesquisarClientePorNumeroConta ();
		else if ( evt.getSource ( ) == ajudaAutorItem)
			Debug.debug("Sou o Francisco André Miguel mais conhecido por Berbahouse ou Curry kkkk, for more information search me on UCAN");
		else if ( evt.getSource ( ) == ajudaAplicacaoItem)
			Debug.debug("Sistema para para automatizar a gestao de clientes e contas Num Banco...");
		}	//new FormDefesa ();
}
