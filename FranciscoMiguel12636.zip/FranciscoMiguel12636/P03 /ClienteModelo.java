/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: ClienteModelo.java
**	Objectivo: Preparar Os Dados Para mandar para o ficheiro
**  Nome: Francisco André Miguel
**	Data: 15 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.GravadorGenericoHT;
import java.io.RandomAccessFile;
import java.io.IOException;
import yb.hashtableyb.*;

public class ClienteModelo extends Pessoa implements Gravavel
{
	private int codigo;

	public ClienteModelo()
	{
		this(0,"","", "", "","","","","","", "","","","", "","","","","","");
	}

	public ClienteModelo(int codigo,String numeroBi,String apelido, String nomeCompleto, String numeroDeContribuinte,String dominioEmail,
											 String estadoCivil,String dataDeNascimento, String provincia, String municipio, String bairro,
											 String nomeDoPai, String nomeDaMae, String nacionalidade, String email, String sexo, String telefone,
											 String documentoId,String dataEmissao,String habilitacao)
  {
			super (numeroBi,apelido,nomeCompleto,numeroDeContribuinte,dominioEmail,estadoCivil,dataDeNascimento,provincia,
						  municipio,bairro,nomeDoPai,nomeDaMae,nacionalidade,email,sexo,telefone,documentoId,dataEmissao,
							habilitacao);
			setCodigo (codigo);
  }

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	//---------------------! Area dos Gets !------------------------

	public int getCodigo() {
		return codigo;
	}

	//-------------! Implementação Interface Gravavel !--------
	public Gravavel getNovaInstancia ()
	{

	   return new ClienteModelo();
	}

	public int getSizeof ()
	{
		return ((19 * 100) + 4);
	}

	public Object getChave (){
		return getNumeroBi	();
	}

	public void gravarRegisto(  RandomAccessFile stream ) throws IOException
	{
		stream.writeInt (codigo);
		numeroBi.write(stream);
		nomeCompleto.write(stream);
		apelido.write(stream);
		numeroDeContribuinte.write(stream);
		estadoCivil.write(stream);
		dataDeNascimento.write(stream);
		provincia.write(stream);
		municipio.write(stream);
		bairro.write(stream);
		nomeDoPai.write(stream);
		nomeDaMae.write(stream);
		nacionalidade.write(stream);
		email.write(stream);
		sexo.write(stream);
		telefone.write(stream);
		dataEmissao.write(stream);
		documentoId.write(stream);
		dominioEmail.write(stream);
		habilitacao.write(stream);
	}

	public void lerRegisto( RandomAccessFile stream ) throws IOException
	{
		codigo = stream.readInt();
		numeroBi.read(stream);
		nomeCompleto.read(stream);
		apelido.read(stream);
		numeroDeContribuinte.read(stream);
		estadoCivil.read(stream);
		dataDeNascimento.read(stream);
		provincia.read(stream);
		municipio.read(stream);
		bairro.read(stream);
		nomeDoPai.read(stream);
		nomeDaMae.read(stream);
		nacionalidade.read(stream);
		email.read(stream);
		sexo.read(stream);
		telefone.read(stream);
		dataEmissao.read(stream);
		documentoId.read(stream);
		dominioEmail.read(stream);
		habilitacao.read(stream);
	}

	public void gravarRegistoVazio( RandomAccessFile stream ) throws IOException
	{
		setCodigo (0);
		setNumeroBi ("");
		setApelido ("");
		setNomeCompleto ("");
		setNumeroDeContribuinte ("");
		setEstadoCivil ("");
		setDataDeNascimento ("");
		setProvincia ("");
		setMunicipio ("");
		setBairro ("");
		setNomeDoPai ("");
		setNomeDaMae ("");
		setNacionalidade ("");
		setEmail ("");
		setSexo ("");
		setTelefone ("");
		setDominioEmail ("");
		setDocumentoId ("");
		setDataEmissao ("");
		setHabilitacao("");

		try
    	{
    		gravarRegisto(stream);
    	}
    	catch (Exception ex)
    	{
    		JOptionPane.showMessageDialog (null, "Erro ao tentar gravar o Cliente vazio. Erro do tipo: "+ex);
    	}
	}

	public String toString()
	{
		String str = "---! Armazenando os dados no Ficheiro dos Clientes !---\n";
		str += "Numero BI :                 " + getNumeroBi() +"\n";
		str += "Nome Completo:           " + getNomeCompleto() +"\n";
		str += "Numero de Contribuinte:  " + getNumeroDeContribuinte() +"\n";
		str += "Estado Civil:            " + getEstadoCivil() +"\n";
		str += "Data de Nascimento:      " + getDataDeNascimento() +"\n";
		str += "Provincia:               " + getProvincia() +"\n";
		str += "Municipio:               " + getMunicipio() +"\n";
		str += "bairro:                  " + getBairro() +"\n";
		str += "Nome do Pai:             " + getNomeDoPai() +"\n";
		str += "Nome da Mae:             " + getNomeDaMae() +"\n";
		str += "Nacionalidade:           " + getNacionalidade() +"\n";
		str += "Sexo:                    " + getSexo() +"\n";
		str += "Telefone:                " + getTelefone() +"\n";
		return str;
	}
}
