import javax.swing.*;

public interface DebugInterface
{
	public void debug();
}
