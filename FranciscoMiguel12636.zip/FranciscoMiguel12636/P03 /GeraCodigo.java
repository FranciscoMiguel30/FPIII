/**********************************************************************************************/
/* Ficheiro.: GeraCodigo.java																																		*/
/* Data.: 20 De Junho de 2016																																	*/
/* Autor.: Francisco André Miguel																															*/
/* Descricao.: Criar um sistema para gerenciar os Cliente e Contas de Um Banco								*/
/**********************************************************************************************/


import java.io.*;
import javax.swing.*;

public class GeraCodigo{

    private NumModelo modelo;

    public GeraCodigo(){
    }

    public void gravaMod(NumModelo modelo){
        try{
            FileOutputStream fos= new FileOutputStream(new File(Definicoes.FILECODIGO));
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(modelo);
            oos.close();
        }
        catch(IOException ioex){
            JOptionPane.showMessageDialog(null, "Erro na gravacão do codigo no ficheiro de\n codigos: ficheiro/geracodigos.dat","File error",JOptionPane.ERROR_MESSAGE);
        }
    }
    public void inicializa(){
    gravaMod(new NumModelo());
    }

  public void leModelo(){
    try
    {
        File file = new File(Definicoes.FILECODIGO);
            if(file.exists())
            {
                FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis);

                modelo = (NumModelo)ois.readObject();
                    ois.close();
            }
            else
            {
                inicializa();
                FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis);
                modelo = (NumModelo)ois.readObject();
                ois.close();
            }
        }
        catch(IOException ioex){
            JOptionPane.showMessageDialog(null, "Falha na leitura dos dados do codigo no geracodigos.dat");
            ioex.printStackTrace();
        }
        catch(ClassNotFoundException cnfex){
            JOptionPane.showMessageDialog(null, "Classe Não encontrada");
            cnfex.printStackTrace();
        }
    }

    public int getNumCliente(){
        leModelo();
        return modelo.getNumCliente();
    }

    public void setNumCliente(int num){
        leModelo();
        modelo.setNumCliente(num);
        gravaMod(modelo);
    }

    public int getNumConta(){
        leModelo();
        return modelo.getNumConta();
    }

    public void setNumConta(int num){
        leModelo();
        modelo.setNumConta(num);
        gravaMod(modelo);
    }

    public int getNumPessoa(){
        leModelo();
        return modelo.getNumPessoa();
    }

    public void setNumPessoa(int num){
        leModelo();
        modelo.setNumPessoa(num);
        gravaMod(modelo);
    }

    public int getNumFuncionario(){
        leModelo();
        return modelo.getNumFuncionario();
    }

    public void setNumFuncionario(int num){
        leModelo();
        modelo.setNumFuncionario(num);
        gravaMod(modelo);
    }
}
