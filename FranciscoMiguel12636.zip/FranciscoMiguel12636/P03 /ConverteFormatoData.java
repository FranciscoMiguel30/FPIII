/***********************************************************************************************/
/* Autor: Armindo Binje                                                                        */
/* Ficheiro: ConverteFormatoData.java                                                          */
/* Data: 2013-07-14                                                                            */
/* Descrição: Esta Classe Representa a classe para  Converter O Formato de Data 	           */
/***********************************************************************************************/

import java.util.*;

public class ConverteFormatoData{
	  private String dataS;
	  private String[] meses = { "Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez" };

	  public ConverteFormatoData(String data){
		this.dataS = data;
	  }
	  public ConverteFormatoData(){
		this.dataS = null;
	  }


	  public String getDataS(){
		return this.dataS;
	  }

	  public void setDataS(String dataS){
		this.dataS = dataS;
	  }

	  public String[] getData(){
		 String[] string = new String[3];
		 StringTokenizer st = new StringTokenizer(getDataS(), "-");
		 for(int i = 0; st.hasMoreTokens(); i++)
			 string[i] = st.nextToken();
		 return string;
	  }

	  public String getDia(){
		 String[] string = getData();
		 return ( string[0] );
	  }

	  public String getAno(){
		 String[] string = getData();
		 return string[ 2 ];
	 }

	 public String getMes(){
		int i;
		String[] string = getData();
		for ( i = 0; i< meses.length ; i++) {
			if( string[ 1 ].compareTo( meses[ i ] )==0 )
			   break;
		}
		if(i < 10){
		  return ""+0+(i+1);
		}else{
		  return ""+(i+1);
		}
	 }

	 public String getMes( int i ){
		String mesesSt[]= meses;
		return mesesSt[ i ];
	 }

	 public int getDataInt(){
		String dataST = getDia ().trim();
		dataST += getMes().trim();
		dataST += getAno().trim();
		return Integer.parseInt( dataST );
	}


}
