/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: TransferenciasVisao.java
**	Objectivo: Fazer a operacao De Transferencias De Uma Conta Para Outra
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import java.util.regex.*;
import yb.hashtableyb.GravadorGenericoHT;
import java.io.*;

public class TransferenciasVisao extends JFrame
{
  private JComboBox numeroContaTransferirJcb;
  private JTextField nomeTitularTransferirJtf,nomeTitularRecebeJtf,valorTransferirJtf;
  private JComboBox numeroContaDepositarJcb;
  private JTextFieldData dataTransferenciaJtfd;
  private JPanel painelCentro,painelBotoes;
  private JButton okJb,limparJb,cancelJb;
  private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
  private GravadorContaModelo gravador = new GravadorContaModelo();

  public TransferenciasVisao ()
  {
    super("Transferencias - BFA");
    geraPainelCentro();
    geraPainelBotoes();
    Container ct = this.getContentPane();
    ct.add(painelCentro, BorderLayout.CENTER);
    ct.add(painelBotoes, BorderLayout.SOUTH);
    pack ();
    //setSize(300, 200);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setLocationRelativeTo ( null );
    setVisible(true);
    TrataEventos eventos = new TrataEventos ();
    okJb.addActionListener (eventos);
    limparJb.addActionListener (eventos);
    cancelJb.addActionListener (eventos);

    EventoComboBox eventosCombo = new EventoComboBox ();
    numeroContaDepositarJcb.addActionListener ( eventosCombo );
    numeroContaTransferirJcb.addActionListener ( eventosCombo );

  }

  public String getNumeroContaTransferir ()
  {
    return numeroContaTransferirJcb.getSelectedItem ().toString ().trim ();
  }

  public String getNumeroContaDepositar ()
  {
    return  numeroContaDepositarJcb.getSelectedItem ().toString ().trim ();
  }

  public String getValorTransferir ()
  {
    return valorTransferirJtf.getText ().toString ().trim ();
  }

  public String getDataTransferir ()
  {
    return dataTransferenciaJtfd.getDTestField ().toString ().trim ();
  }

  public void geraPainelCentro()
  {
    painelCentro = new JPanel();
    painelCentro.setLayout(new GridLayout( 6,1));

    addNumeroContaTransferir ();
    addNomeTitularTransferencia ();
    addNumeroContaDepositar ();
    addNomeTitularRecebe ();
    addValorTransferir ();
    addDataTransferencias ();
  }


  public JPanel createPanelDataTransferencias()
  {
    JPanel panel = new JPanel();
    panel.setLayout(new GridLayout(1, 2));
    dataTransferenciaJtfd = new JTextFieldData ("");
    panel.add (dataTransferenciaJtfd.getDTestField());
    panel.add (dataTransferenciaJtfd.getDButton());
    return panel;
  }

  private class EventoComboBox implements ActionListener
  {
    public void actionPerformed ( ActionEvent evento )
    {
      if ( evento.getSource ( ) ==  numeroContaTransferirJcb)
      {
          preencherNomeClienteModelo ( nomeDoClienteModelo (getNumeroContaTransferir () ));
          if (getNumeroContaTransferir ().equals ("") )
              nomeTitularRecebeJtf.setText ("");
          else if (getNumeroContaDepositar ().equals (getNumeroContaTransferir ()))
          {
            JOptionPane.showMessageDialog (null,"Error, Escolha Um Outro Cliente Meu Caro","Error",JOptionPane.ERROR_MESSAGE);
            numeroContaDepositarJcb.setSelectedItem (-1);
            nomeTitularRecebeJtf.setText ("");
          }
      }
      else if (evento.getSource ( ) ==  numeroContaDepositarJcb)
        {
          if (getNumeroContaDepositar ().equals (""))
              nomeTitularRecebeJtf.setText ("");
          else if (getNumeroContaDepositar ().equals (getNumeroContaTransferir ()))
          {
            JOptionPane.showMessageDialog (null,"Error, Escolha Um Outro Cliente Meu Caro","Error",JOptionPane.ERROR_MESSAGE);
            numeroContaDepositarJcb.setSelectedItem (-1);
            nomeTitularRecebeJtf.setText ("");
          }
          else
            preencherNomeClienteModeloDeposita ( nomeDoClienteModelo (getNumeroContaDepositar ()));
        }
    }
  }

  public Vector<String> carregarNumeroConta()
  {
    Vector<String> listaNumeroConta = new Vector<String>();
    int i = 0;
    listaNumeroConta.add (i,"");
    try
    {
       ContaModelo modelo;
       lista = gravador.lerTodos();
       for(Gravavel gravavel : lista)
       {
         modelo = (ContaModelo) gravavel;
         listaNumeroConta.add(++i,modelo.getNumeroConta());
       }
       ordenarComboBox (listaNumeroConta);
     }catch(IOException e){}
    return listaNumeroConta;
  }

  public JComboBox ordenarComboBox ( Vector vectorItens)
  {
    Collections.sort ( vectorItens );

    return new JComboBox ( vectorItens );
  }

  public ContaModelo nomeDoClienteModelo ( String numeroConta )
  {

    try
    {
       lista = gravador.lerTodos();
       ContaModelo modelo;
       for(Gravavel gravavel : lista)
       {
         modelo = (ContaModelo) gravavel;
         //JOptionPane.showMessageDialog (null,"nome ComboBox : " + nome + "nome File" + modelo.getNomeCompleto () );
         if (numeroConta.equals (modelo.getNumeroConta ()))
            return modelo;
       }
     }catch(IOException e){}

    return new ContaModelo ( );
  }

  public void preencherNomeClienteModelo ( ContaModelo clienteConta )
  {
    nomeTitularTransferirJtf.setText ("" + clienteConta.getNomeCompleto ( ) );
  }

  public void preencherNomeClienteModeloDeposita ( ContaModelo clienteConta )
  {
    nomeTitularRecebeJtf.setText ("" + clienteConta.getNomeCompleto ( ) );
  }

  public void addDataTransferencias ()
  {
    painelCentro.add( new JLabel ("Data Da Transferencia"));
    painelCentro.add(createPanelDataTransferencias());
  }

  public void addNumeroContaTransferir ()
  {
    painelCentro.add (new JLabel ("Numero Da Conta A Transferir"));
    numeroContaTransferirJcb = new JComboBox (carregarNumeroConta ());
    painelCentro.add (numeroContaTransferirJcb);
  }

  public void addNumeroContaDepositar ()
  {
    painelCentro.add (new JLabel ("Numero Da Conta A Depositar"));
    numeroContaDepositarJcb = new JComboBox (carregarNumeroConta ());
    painelCentro.add (numeroContaDepositarJcb);
  }

  public void addNomeTitularTransferencia ()
  {

    painelCentro.add(new JLabel ("Titular A Transferir "));
    nomeTitularTransferirJtf = new JTextField ();
    nomeTitularTransferirJtf.setEnabled (false);
    painelCentro.add(nomeTitularTransferirJtf);
  }

  public void addNomeTitularRecebe ()
  {

    painelCentro.add(new JLabel ("Titular A Receber "));
    nomeTitularRecebeJtf = new JTextField ();
    nomeTitularRecebeJtf.setEnabled (false);
    painelCentro.add(nomeTitularRecebeJtf);
  }

  public void addValorTransferir ()
  {

    painelCentro.add(new JLabel ("Valor A Transferir"));
    valorTransferirJtf = new JTextField ();
    painelCentro.add(valorTransferirJtf);
  }

  public void geraPainelBotoes()
  {
    painelBotoes = new JPanel();
    okJb = new JButton("Ok");
    limparJb = new JButton("Limpar");
    cancelJb = new JButton("Cancelar");
    painelBotoes.setLayout(new FlowLayout());
    painelBotoes.add(okJb);
    painelBotoes.add(limparJb);
    painelBotoes.add(cancelJb);
  }

  public void transferenciasConta ()
  {
    ContaModelo clienteTransfere,clienteRecebe;
    if (validarCampos ())
    {
      try
      {
         clienteTransfere = (ContaModelo) gravador.ler(getNumeroContaTransferir());
         clienteRecebe = (ContaModelo) gravador.ler(getNumeroContaDepositar());

        if (clienteRecebe != null && clienteTransfere != null)
        {
         //JOptionPane.showMessageDialog (null,"nome ComboBox : " + nome + "nome File" + modelo.getNomeCompleto () );
           int valorTransferir1 = Integer.parseInt (clienteTransfere.getSaldoConta ());
           int valorTransferir2 = Integer.parseInt (getValorTransferir () );
           int valorReceber1 = Integer.parseInt (clienteRecebe.getSaldoConta ());
           int totalTransferir = valorTransferir1 - valorTransferir2;
           int totalReceber = valorReceber1 + valorTransferir2;
           if (totalTransferir > 0)
           {
             //new ExtractoVisao (false).setOperacao (0);
             //new ExtractoVisao (false).seeExtracto (depositar.getOperacao ());
             clienteTransfere.setSaldoConta ("" + totalTransferir);
             clienteRecebe.setSaldoConta ("" + totalReceber);
             clienteTransfere.setDataTransferir ("" + getDataTransferir ());
             gravador.editar(getNumeroContaDepositar (), clienteRecebe);
             gravador.editar(getNumeroContaTransferir (), clienteTransfere);
             JOptionPane.showMessageDialog (null,"Transferencias Efectuado Com Sucesso","Informacao",
                                              JOptionPane.INFORMATION_MESSAGE);
          }
          else
            JOptionPane.showMessageDialog (null,"Error, Meu Caro Teu Money Não Chega Para Efectuar Essa Operacao",
                                            "Error",JOptionPane.ERROR_MESSAGE);
        }
      }catch(IOException e){}
    }
  }
  public Boolean validarCampos ()
  {
    if (nomeTitularTransferirJtf.getText ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite O Nome Do Titular A Transferir","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if (nomeTitularRecebeJtf.getText ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite O Nome Do Titular A Receber","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if (dataTransferenciaJtfd.getDTestField ().getText ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite A Data Da Transferencia","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if (getValorTransferir ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite O Dinheiro Inicial Meu Caro","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    return true;
  }
  public void limparFormulario()
  {
    dataTransferenciaJtfd.setDtestField("");
    nomeTitularTransferirJtf.setText("");
    nomeTitularRecebeJtf.setText("");
    valorTransferirJtf.setText("");
    numeroContaTransferirJcb.setSelectedItem (-1);
    numeroContaDepositarJcb.setSelectedItem (-1);
  }//Fim do metodo limparFormulario()--------------------------------------------------------

  private class TrataEventos implements ActionListener
  {
      public void actionPerformed(ActionEvent evento)
      {
          if (evento.getSource() == okJb)
          {
              transferenciasConta ();
          }//Fim Botao Salvar--------------------------------------------------------

          else if (evento.getSource() == cancelJb)
          {
              dispose();
          }//Fim Botao cancelar--------------------------------------------------------

          else if (evento.getSource() == limparJb)
          {
              limparFormulario();
          }//Fim Botao Limpar -------------------------------------------------------
      }
    }//Fim Da Classe TrataEventos -----------------------------------------------------
}
