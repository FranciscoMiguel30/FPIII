import java.util.*;
import javax.swing.*;



public class SubFormJTextFieldComboBoxSave extends SubFormJTextFieldComboBox
	implements SaveClearInterface
{	
	public SubFormJTextFieldComboBoxSave() 	{  	}
  	public void save() 	{ 	}
}
