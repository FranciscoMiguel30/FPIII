

/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: DepositaExtractoControlo.java
**	Objectivo: Controla O Tipo De Operacao Para Incluir No Extrato
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import java.util.regex.*;
import yb.hashtableyb.GravadorGenericoHT;
import java.io.*;

public class LevantamentoExtractoControlo extends ExtractoVisao
{
  Iterator it;
  public LevantamentoExtractoControlo ()
  {
  /*  super.dispose ();
    setOperacao (1);
    it = getOperacao ().iterator ();
    while (it.hasNext())
    {
      //JOptionPane.showMessageDialog (null,"" + new ExtractoVisao (false).getOperacao ().size ());
      JOptionPane.showMessageDialog (null,"proximo : " + it.next ());
    }*/
  }
    public Iterator getIterator ()
    {
      return it;
    }
}
