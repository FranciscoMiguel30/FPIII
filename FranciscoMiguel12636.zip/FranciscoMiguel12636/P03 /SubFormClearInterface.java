import javax.swing.*;

public abstract class SubFormClearInterface extends JPanel 
	implements ClearInterface
{
  	public void clear() { }
}