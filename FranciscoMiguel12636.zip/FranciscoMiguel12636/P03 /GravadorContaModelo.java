/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: GravadorContaModelo.java
**	Objectivo: Armazenar cliente na HashTable
**  Nome: Francisco André Miguel
**	Data: 17 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import yb.hashtableyb.GravadorGenericoHT;

public class GravadorContaModelo extends GravadorGenericoHT
{
  public GravadorContaModelo ()
  {
    super(Definicoes.FILECONTAS, 50, new ContaModelo());
  }
}
