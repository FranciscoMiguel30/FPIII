import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CaixaDeDialogo extends JFrame
{
	public CaixaDeDialogo(String msg, int largura, int altura)
	{
		JScrollPane mensagem = new JScrollPane ( new JTextArea(msg));
		setVisible(true);
		setSize(largura, altura);
		add(mensagem, BorderLayout.CENTER);
	
		switch (JOptionPane.showConfirmDialog(null, "Deseja Continuar ?", "Deseja Continuar", JOptionPane.YES_NO_OPTION))
		{
			case JOptionPane.YES_OPTION:
				dispose ();
			break;
		}

	}
}

