/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: MenuPrincipal.java
**	Objectivo: Preparar Os Dados Para mandar para o ficheiro
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import yb.hashtableyb.GravadorGenericoHT;
import java.io.*;
import yb.hashtableyb.*;

public class ContaModelo implements Gravavel
{
  private StringBufferModelo numeroConta,nomeCompleto,nomeCompletoFuncionario,codigoFuncionario;
	private StringBufferModelo saldoConta,codigoCliente,dataAbertura,tipoConta,balcao,ordemDeposito;
  private StringBufferModelo codigoTitular2,codigoTitular3,titular2,titular3,dataDepositar;
  private StringBufferModelo dataLevantar,dataTransferir;

	public ContaModelo()
	{
		this("", "", "", "","","","","","","","","","","","","","");
	}

  public ContaModelo(String numeroConta,String nomeCompleto,String saldoConta, String codigoCliente, String dataAbertura,String tipoConta,
									   String balcao,String ordemDeposito,String codigoFuncionario,String nomeCompletoFuncionario,
                     String codigoTitular2,String codigoTitular3,String titular2,String titular3,
                     String dataDepositar,String dataLevantar,String dataTransferir)
  {
      setNumeroConta (numeroConta);
      setNomeCompleto (nomeCompleto);
      setCodigoFuncionario (codigoFuncionario);
      setNomeCompletoFuncionario (nomeCompletoFuncionario);
      setCodigoCliente (codigoCliente);
      setSaldoConta (saldoConta);
			setDataAbertura (dataAbertura);
      setTipoConta (tipoConta);
			setBalcao (balcao);
      setOrdemDeposito (ordemDeposito);
      setCodigoTitular2 (codigoTitular2);
      setTitular2 (titular2);
      setCodigoTitular3 (codigoTitular3);
      setTitular3 (titular3);
      setDataDepositar (dataDepositar);
      setDataLevantar (dataLevantar);
      setDataTransferir (dataTransferir);
  }

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = new StringBufferModelo(nomeCompleto, 50);
	}

  public void setCodigoFuncionario(String codigoFuncionario) {
		this.codigoFuncionario = new StringBufferModelo(codigoFuncionario, 50);
	}

  public void setNomeCompletoFuncionario(String nomeCompletoFuncionario) {
		this.nomeCompletoFuncionario = new StringBufferModelo(nomeCompletoFuncionario, 50);
	}

  public void setCodigoCliente(String codigoCliente) {
		this.codigoCliente = new StringBufferModelo(codigoCliente, 50);
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = new StringBufferModelo(numeroConta, 50);
	}

	public void setSaldoConta(String saldoConta) {
		this.saldoConta = new StringBufferModelo(saldoConta, 50);
	}

	public void setDataAbertura(String dataAbertura) {
		this.dataAbertura = new StringBufferModelo(dataAbertura, 50);
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = new StringBufferModelo(tipoConta, 50);
	}

	public void setBalcao(String balcao) {
		this.balcao = new StringBufferModelo(balcao, 50);
	}

	public void setCodigoTitular2(String codigoTitular2) {
		this.codigoTitular2 = new StringBufferModelo( codigoTitular2, 50);
	}

  public void setTitular2(String titular2) {
		this.titular2 = new StringBufferModelo( titular2, 50);
	}

  public void setCodigoTitular3(String codigoTitular3) {
		this.codigoTitular3 = new StringBufferModelo( codigoTitular3, 50);
	}

  public void setTitular3(String titular3) {
		this.titular3 = new StringBufferModelo( titular3, 50);
	}

  public void setOrdemDeposito(String ordemDeposito) {
		this.ordemDeposito = new StringBufferModelo( ordemDeposito, 50);
	}

  public void setDataLevantar(String levantar) {
		this.dataLevantar  = new StringBufferModelo( levantar, 50);
	}

  public void setDataDepositar(String depositar) {
    this.dataDepositar = new StringBufferModelo( depositar, 50);
  }

  public void setDataTransferir(String transferir) {
		this.dataTransferir = new StringBufferModelo( transferir, 50);
	}

  //---------------------! Area dos Gets !------------------------

	public String getCodigoCliente() {
		return codigoCliente.toStringEliminatingSpaces();
	}

  public String getNomeCompleto() {
		return nomeCompleto.toStringEliminatingSpaces();
	}

  public String getNomeCompletoFuncionario() {
		return nomeCompletoFuncionario.toStringEliminatingSpaces();
	}

  public String getCodigoFuncionario() {
    return codigoFuncionario.toStringEliminatingSpaces();
  }

	public String getNumeroConta() {
		return numeroConta.toStringEliminatingSpaces();
	}

	public String getSaldoConta() {
		return saldoConta.toStringEliminatingSpaces();
	}

	public String getDataAbertura() {
		return dataAbertura.toStringEliminatingSpaces();
	}

	public String getTipoConta() {
		return tipoConta.toStringEliminatingSpaces();
	}

	public String getBalcao() {
		return balcao.toStringEliminatingSpaces();
	}

	public String getOrdemDeposito() {
		return ordemDeposito.toStringEliminatingSpaces();
	}

  public String getCodigoTitular2() {
		return codigoTitular2.toStringEliminatingSpaces();
	}

  public String getTitular2() {
		return titular2.toStringEliminatingSpaces();
	}

  public String getCodigoTitular3() {
		return codigoTitular3.toStringEliminatingSpaces();
	}

  public String getTitular3() {
		return titular3.toStringEliminatingSpaces();
	}

  public String getDataDepositar() {
		return dataDepositar.toStringEliminatingSpaces();
	}

  public String getDataLevantar() {
		return dataLevantar.toStringEliminatingSpaces();
	}

  public String getDataTransferir() {
		return dataTransferir.toStringEliminatingSpaces();
	}

  //-------------! Implementação Interface Gravavel !--------
	public Gravavel getNovaInstancia ()
	{
	   return new ContaModelo();
	}

	public int getSizeof ()
	{
		return (17 * 100);
	}

	public Object getChave (){
		return getNumeroConta();
	}

	public void gravarRegisto(  RandomAccessFile stream ) throws IOException
	{
		codigoCliente.write(stream);
    nomeCompleto.write(stream);
		numeroConta.write(stream);
		saldoConta.write(stream);
		dataAbertura.write(stream);
		tipoConta.write(stream);
		balcao.write(stream);
		ordemDeposito.write(stream);
    nomeCompletoFuncionario.write(stream);
    codigoFuncionario.write(stream);
    codigoTitular2.write(stream);
    titular2.write(stream);
    codigoTitular3.write(stream);
    titular3.write(stream);
    dataDepositar.write(stream);
    dataLevantar.write(stream);
    dataTransferir.write(stream);
	}

	public void lerRegisto( RandomAccessFile stream ) throws IOException
	{
		codigoCliente.read(stream);
    nomeCompleto.read(stream);
		numeroConta.read(stream);
		saldoConta.read(stream);
		dataAbertura.read(stream);
		tipoConta.read(stream);
		balcao.read(stream);
		ordemDeposito.read(stream);
    codigoFuncionario.read(stream);
    nomeCompletoFuncionario.read(stream);
    codigoTitular2.read(stream);
    titular2.read(stream);
    codigoTitular3.read(stream);
    titular3.read(stream);
    dataDepositar.read(stream);
    dataLevantar.read(stream);
    dataTransferir.read(stream);
	}

	public void gravarRegistoVazio( RandomAccessFile stream ) throws IOException
	{
		setCodigoCliente ("");
    setNomeCompleto ("");
		setNumeroConta ("");
		setSaldoConta ("");
		setDataAbertura ("");
		setTipoConta ("");
		setBalcao ("");
		setOrdemDeposito ("");
    setCodigoFuncionario ("");
    setNomeCompletoFuncionario ("");
    setCodigoTitular2 ("");
    setCodigoTitular3 ("");
    setTitular2 ("");
    setTitular3 ("");
    setDataLevantar ("");
    setDataDepositar ("");
    setDataTransferir ("");

    try
      {
        gravarRegisto(stream);
      }
      catch (Exception ex)
      {
        JOptionPane.showMessageDialog (null, "Erro ao tentar gravar A Conta vazio. Erro do tipo: "+ex);
      }
	}

	public String toString()
	{
		String str = "---! Armazenando os dados no Ficheiro de Conta !---\n";
	  str += "Nome Completo Do Titular :            " + getNomeCompleto() +"\n";
    str += "Nome Completo Do Funcionario :        " + getNomeCompletoFuncionario() +"\n";
		str += "Numero Da Conta:                      " + getNumeroConta() +"\n";
		str += "Saldo Da Conta:                       " + getSaldoConta() +"\n";
		str += "Data De Abertura:                     " + getDataAbertura() +"\n";
		str += "Tipo De Conta:                        " + getTipoConta() +"\n";
		str += "Balcao:                               " + getBalcao() +"\n";
		str += "Ordem Deposito:                       " + getOrdemDeposito() +"\n";

		return str;
	}
}
