
import java.util.*;

public class Hashtable_Contentor_Tabela_Contentor extends Hashtable
{
  public Hashtable_Contentor_Tabela_Contentor()
  {
    super(100);
  }

  public Vector_Tabelas getStream(String File)
  {
    return (Vector_Tabelas) get(File);
  }
}
