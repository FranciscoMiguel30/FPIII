
public interface SaveClearInterface extends ClearInterface
{
  public void save();
}