


/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: ListarClientes.java
**	Objectivo: ListarClientes,Alterar  e eliminar Clientes
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import java.util.regex.*;


public class ListarClientes extends JFrame implements ActionListener{

  private String[] colunas = new String[]{"Codigo","Nº BI","Nome Completo","Sexo","Documento Identificacao","Data de Emissão",
                   "Data Nascimento","Nacionalidade","Comuna","Provincia","Municipio","Estado Civil","Nº Tel.","Nome Mãe",
    "Nome Pai","E - Mail","Nº Contribuinte"};
  private JPanel painelTab, painelBtn, painelPesquisa;
  private JTable table;
  private DefaultTableModel modelo;
  private JButton btnCancelar, btnEliminar, btnAlterar, btnVerTodos, btnOrdenar;
  private Object[][] dados = new Object[][]{{},{}};
  private JScrollPane scrool;
  private JLabel lblPesquisa;
  private JTextField jtfPesquisa;
  private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
  private GravadorClienteModelo gravador = new GravadorClienteModelo();

  public ListarClientes (){
    setTitle("Listar Clientes");
    setSize (600, 600);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setResizable(false);
    criaGui();
    setVisible(true);
  }

  public ListarClientes (Boolean status){
    setSize (600, 600);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setResizable(false);
    criaGui();
    setVisible(true);

    btnVerTodos.setVisible (false);
    if (!status){
      setTitle("Eliminar Clientes");
      btnEliminar.setVisible (true);
      btnAlterar.setVisible (false);
    }else{

        setTitle("Alterar Clientes");
        btnAlterar.setVisible (true);
        btnEliminar.setVisible (false);
    }

  }


  public void criaGui(){
    painelPesquisa = new JPanel(new GridBagLayout());
    painelTab = new JPanel();
    painelBtn = new JPanel(new FlowLayout());
    btnEliminar = new JButton ("Eliminar");
    btnAlterar = new JButton ("Alterar");
    btnEliminar.setVisible (false);
    btnAlterar.setVisible (false);
    modelo = (new DefaultTableModel(dados, colunas)
    {
			public boolean isCellEditable(int row, int column) {
					return false;
			}
		});
    table = new JTable();
    final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(modelo);
    table.setRowSorter(sorter);
    modelo.setRowCount(0);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    table.setModel(modelo);

    scrool = new JScrollPane(table, scrool.VERTICAL_SCROLLBAR_ALWAYS, scrool.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    scrool.setPreferredSize(new Dimension(560,485));
    painelTab.add(scrool);

    table.getColumnModel().getColumn(0).setPreferredWidth(200);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(2).setPreferredWidth(125);
		table.getColumnModel().getColumn(3).setPreferredWidth(125);
		table.getColumnModel().getColumn(4).setPreferredWidth(120);
		table.getColumnModel().getColumn(5).setPreferredWidth(175);
		table.getColumnModel().getColumn(6).setPreferredWidth(175);
		table.getColumnModel().getColumn(7).setPreferredWidth(125);
		table.getColumnModel().getColumn(8).setPreferredWidth(125);
		table.getColumnModel().getColumn(9).setPreferredWidth(175);
		table.getColumnModel().getColumn(10).setPreferredWidth(125);
		table.getColumnModel().getColumn(11).setPreferredWidth(75);
		table.getColumnModel().getColumn(12).setPreferredWidth(75);
		table.getColumnModel().getColumn(13).setPreferredWidth(75);
		table.getColumnModel().getColumn(14).setPreferredWidth(125);
		table.getColumnModel().getColumn(15).setPreferredWidth(175);
		table.getColumnModel().getColumn(16).setPreferredWidth(175);
    table.getColumnModel().getColumn(16).setPreferredWidth(175);

    painelPesquisa.setLayout(null);
    jtfPesquisa = new JTextField();
    jtfPesquisa.addKeyListener(new KeyListener(){
         public void keyTyped(KeyEvent e) {
              String text = jtfPesquisa.getText().trim();
              //JOptionPane.showMessageDialog(null, "Por favor, "+text.length(),"Erro",JOptionPane.ERROR_MESSAGE);
              procuraTable(text);
         }
         public void keyPressed(KeyEvent e){}
         public void keyReleased(KeyEvent e) {}
    });

    btnCancelar = new JButton ("Cancelar");
    btnCancelar.setToolTipText("Fecha a janela");
    btnCancelar.addActionListener(this);
    btnVerTodos = new JButton ("Listar Clientes");
    btnVerTodos.setToolTipText("Lista todos elementos na Tabela");
    btnVerTodos.addActionListener(this);
    btnOrdenar = new JButton ("Ordenar");
    btnOrdenar.addActionListener(this);
    btnOrdenar.setToolTipText("Ordena os elementos na tabela");
    btnOrdenar.setVisible (false);
    btnAlterar.addActionListener(this);
    btnEliminar.addActionListener(this);
    painelBtn.add(btnAlterar);
    painelBtn.add(btnEliminar);
    painelBtn.add(btnVerTodos);
    painelBtn.add(btnOrdenar);
    painelBtn.add(btnCancelar);

    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(painelPesquisa, BorderLayout.NORTH);
    getContentPane().add(painelTab, BorderLayout.CENTER);
    getContentPane().add(painelBtn, BorderLayout.SOUTH);
  }

   public void mostrarTudo(){
    modelo.setRowCount(0);
    try
    {
      lista = gravador.lerTodos();
      ClienteModelo formulario;
      for( Gravavel gravavel : lista )
      {
        formulario = (ClienteModelo) gravavel;
        Object[] object = new Object[17];
        object[0] = formulario.getCodigo();
        object[1] = formulario.getNumeroBi();
        object[2] = formulario.getNomeCompleto();
        object[3] = formulario.getSexo();
        object[4] = formulario.getDocumentoId();
        object[5] = formulario.getDataEmissao();
        object[6] = formulario.getDataDeNascimento();
        object[7] = formulario.getNacionalidade();
        object[8] = formulario.getBairro();
        object[9] = formulario.getProvincia();
        object[10] = formulario.getMunicipio();
        object[11] = formulario.getEstadoCivil();
        object[12] = formulario.getTelefone();
        object[13] = formulario.getNomeDaMae();
        object[14] = formulario.getNomeDoPai();
        object[15] = formulario.getEmail();
        object[16] = formulario.getNumeroDeContribuinte();
        modelo.addRow(object);
        ordenarLista();
      }
    }
    catch (IOException ex)
    {
      JOptionPane.showMessageDialog(this, "Ocorreu um erro ao fazer a leitura do ficheiro");
    }

  }

   public void ordenarLista(){
     if(table.getRowCount() > 0){
      Collections.sort(lista, getComparadorPessoaCod());
      modelo.setRowCount(0);
          ClienteModelo formulario;
          for( Gravavel gravavel : lista )
          {
            formulario = (ClienteModelo) gravavel;
            Object[] object = new Object[17];
            object[0] = formulario.getCodigo();
            object[1] = formulario.getNumeroBi();
            object[2] = formulario.getNomeCompleto();
            object[3] = formulario.getSexo();
            object[4] = formulario.getDocumentoId();
            object[5] = formulario.getDataEmissao();
            object[6] = formulario.getDataDeNascimento();
            object[7] = formulario.getNacionalidade();
            object[8] = formulario.getBairro();
            object[9] = formulario.getProvincia();
            object[10] = formulario.getMunicipio();
            object[11] = formulario.getEstadoCivil();
            object[12] = formulario.getTelefone();
            object[13] = formulario.getNomeDaMae();
            object[14] = formulario.getNomeDoPai();
            object[15] = formulario.getEmail();
            object[16] = formulario.getNumeroDeContribuinte();
            modelo.addRow(object);
         }
     }else{
         JOptionPane.showMessageDialog(null, "Carregue primeiro os registos na tabela - click vet todos!!!");
     }


   }

   private Comparator getComparadorPessoa()
    {
        return new Comparator()
        {

            public int compare(Object o1, Object o2)
            {
                ClienteModelo dado1 = ( ClienteModelo ) o1;
                ClienteModelo dado2 = ( ClienteModelo ) o2;

                return dado1.getNomeCompleto().compareToIgnoreCase(dado2.getNomeCompleto());
            }
        };
    }

    private Comparator getComparadorPessoaCod()
     {
         return new Comparator()
         {

             public int compare(Object o1, Object o2)
             {
                ClienteModelo dado1 = ( ClienteModelo ) o1;
                ClienteModelo dado2 = ( ClienteModelo ) o2;
                String codigo1 = "1",codigo2 = "1";
                return codigo1.valueOf (dado1.getCodigo()).compareToIgnoreCase(codigo2.valueOf (dado2.getCodigo()));
             }
         };
     }

   public void eliminarChave(){
     ClienteModelo dadoAEliminar = new ClienteModelo();
     GravadorClienteModelo gravadorE = new GravadorClienteModelo();
     Gravavel gravavel;
     int linha = table.getSelectedRow();
     if(linha > -1){
       // JOptionPane.showMessageDialog(null, "Linha "+nome);
       gravavel = (Gravavel) lista.get(linha);
       dadoAEliminar = (ClienteModelo) gravavel;

       try
            {
                if( gravadorE.remover(dadoAEliminar.getChave()) )
                {
                    JOptionPane.showMessageDialog(null, "Registo Eliminado com sucesso!!!");
                    ((DefaultTableModel)table.getModel()).removeRow(linha);
                    lista.remove(linha);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Nao foi possivel Eliminar o registo!!!");
                }
            }
            catch (Exception e)
            {
                JOptionPane.showMessageDialog(null, "Ocorreu um erro ao Eliminar o registo!!!");
            }
     }
     else{
       JOptionPane.showMessageDialog(null, "Por favor, selecione a linha a eliminar","Erro",JOptionPane.ERROR_MESSAGE);
     }
   }



   public void alterar(){
     String chave;
     int linha = table.getSelectedRow();
     ClienteModelo dadoAlterar = new ClienteModelo();
     Gravavel gravavel;
     if(linha > -1){
       gravavel = (Gravavel) lista.get(linha);
       dadoAlterar = (ClienteModelo) gravavel;
       chave = dadoAlterar.getNumeroBi();
       new AlterarClienteVisao (chave, true);
     }else{
       JOptionPane.showMessageDialog(null, "Por favor, selecione a linha a Alterar","Erro",JOptionPane.ERROR_MESSAGE);
     }
   }

  public void actionPerformed(ActionEvent e){
    if(e.getSource() == btnVerTodos){
      mostrarTudo();
      if(table.getRowCount() <= 0){
        JOptionPane.showMessageDialog(this, "Ficheiro Vazio");
      }else{
        // Set the second visible column to 100 pixels wide
        int vColIndex = 3;
        TableColumn col = table.getColumnModel().getColumn(vColIndex);
        int width = 200;
        col.setPreferredWidth(width);
      }

    }
    if(e.getSource() == btnCancelar){
      dispose();
    }
    else if(e.getSource() == btnAlterar){
      this.dispose ();
      alterar ();
    }
    else if(e.getSource() == btnEliminar){
      eliminarChave ();
    }
    else if(e.getSource() == btnOrdenar){
      ordenarLista();
    }
  }

  private void procuraTable(String nome){
     int tamanho = nome.length();
     if(tamanho > 1){
     for (int linha = 0; linha < table.getRowCount(); linha++){
         String nomeTabela = (String)table.getValueAt(linha, 1);
         try{
            if (nomeTabela.substring(0,tamanho).toUpperCase().equals(nome.toUpperCase())){
              table.setRowSelectionInterval(linha,linha);
            }
         }catch(StringIndexOutOfBoundsException a){
         }
     }
     }
   }
}
