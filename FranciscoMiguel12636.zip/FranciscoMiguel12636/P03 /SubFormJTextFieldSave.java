import java.util.*;
import javax.swing.*;

public class SubFormJTextFieldSave extends SubFormJTextField
	implements SaveClearInterface
{	
	public SubFormJTextFieldSave() { }	
  	public void save() { }
}