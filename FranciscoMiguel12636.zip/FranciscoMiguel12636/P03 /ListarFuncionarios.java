

/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: ListarFuncionarios.java
**	Objectivo: ListarFuncionarios,Alterar  e eliminar Funcionarios
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import java.util.regex.*;


public class ListarFuncionarios extends JFrame implements ActionListener{

  private String[] colunas = new String[]{"Codigo Funcionario","Nome Funcionario","Email Do Funcionario"};
  private JPanel painelTab, painelBtn, painelPesquisa;
  private JTable table;
  private DefaultTableModel modelo;
  private JButton btnCancelar, btnEliminar, btnAlterar, btnVerTodos, btnOrdenar;
  private Object[][] dados = new Object[][]{{},{}};
  private JScrollPane scrool;
  private JLabel lblPesquisa;
  private JTextField jtfPesquisa;
  private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
  private GravadorFuncionarioModelo gravador = new GravadorFuncionarioModelo();

  public ListarFuncionarios (){
    setTitle("Listar Funcionarios");
    setSize (600, 600);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setResizable(false);
    criaGui();
    setVisible(true);
  }

  public ListarFuncionarios (Boolean status){
    setSize (600, 600);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setResizable(false);
    criaGui();
    setVisible(true);
    btnVerTodos.setVisible (false);
    if (!status){

        setTitle("Eliminar Funcionarios");
        btnEliminar.setVisible (true);
        btnAlterar.setVisible (false);
    }else{

        setTitle("Alterar Funcionarios");
        btnAlterar.setVisible (true);
        btnEliminar.setVisible (false);
    }
  }

  public void criaGui(){
    btnEliminar = new JButton ("Eliminar");
    btnAlterar = new JButton ("Alterar");
    btnEliminar.setVisible (false);
    btnAlterar.setVisible (false);
    painelTab = new JPanel();
    painelBtn = new JPanel(new FlowLayout());
    modelo = (new DefaultTableModel(dados, colunas)
    {
			public boolean isCellEditable(int row, int column) {
					return false;
			}
		});
    table = new JTable();
    final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(modelo);
    table.setRowSorter(sorter);
    modelo.setRowCount(0);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    table.setModel(modelo);

    scrool = new JScrollPane(table, scrool.VERTICAL_SCROLLBAR_ALWAYS, scrool.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    scrool.setPreferredSize(new Dimension(560,485));
    painelTab.add(scrool);

    table.getColumnModel().getColumn(0).setPreferredWidth(250);
		table.getColumnModel().getColumn(1).setPreferredWidth(250);
		table.getColumnModel().getColumn(2).setPreferredWidth(250);

    btnCancelar = new JButton ("Cancelar");
    btnCancelar.setToolTipText("Fecha a janela");
    btnCancelar.addActionListener(this);
    btnVerTodos = new JButton ("Listar Funcionarios");
    btnVerTodos.setToolTipText("Lista todos elementos na Tabela");
    btnVerTodos.addActionListener(this);
    btnOrdenar = new JButton ("Ordenar");
    btnOrdenar.addActionListener(this);
    btnOrdenar.setToolTipText("Ordena os elementos na tabela");
    btnOrdenar.setVisible (false);
    btnAlterar.addActionListener(this);
    btnEliminar.addActionListener(this);
    painelBtn.add(btnAlterar);
    painelBtn.add(btnEliminar);
    painelBtn.add(btnVerTodos);
    painelBtn.add(btnOrdenar);
    painelBtn.add(btnCancelar);

    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(painelTab, BorderLayout.CENTER);
    getContentPane().add(painelBtn, BorderLayout.SOUTH);
  }

   public void mostrarTudo(){
    modelo.setRowCount(0);
    try
    {
      lista = gravador.lerTodos();
      FuncionarioModelo formulario;
      for( Gravavel gravavel : lista )
      {
        formulario = (FuncionarioModelo) gravavel;
        Object[] object = new Object[4];
        object[0] = formulario.getCodigoFuncionario();
        object[1] = formulario.getNomeCompleto();
        object[2] = formulario.getEmail ();
        modelo.addRow(object);
        ordenarLista();
      }
    }
    catch (IOException ex)
    {
      JOptionPane.showMessageDialog(this, "Ocorreu um erro ao fazer a leitura do ficheiro");
    }

  }

   public void ordenarLista(){
     if(table.getRowCount() > 0){
      Collections.sort(lista, getComparadorPessoaCod());
      modelo.setRowCount(0);
          FuncionarioModelo formulario;
          for( Gravavel gravavel : lista )
          {
            Object[] object = new Object[4];
            formulario = (FuncionarioModelo) gravavel;
            object[0] = formulario.getCodigoFuncionario();
            object[1] = formulario.getNomeCompleto();
            object[2] = formulario.getEmail ();
            modelo.addRow(object);
         }
     }else{
         JOptionPane.showMessageDialog(null, "Carregue primeiro os registos na tabela - click vet todos!!!");
     }


   }

   private Comparator getComparadorPessoa()
    {
        return new Comparator()
        {

            public int compare(Object o1, Object o2)
            {
                FuncionarioModelo dado1 = ( FuncionarioModelo ) o1;
                FuncionarioModelo dado2 = ( FuncionarioModelo ) o2;

                return dado1.getNomeCompleto().compareToIgnoreCase(dado2.getNomeCompleto());
            }
        };
    }

    private Comparator getComparadorPessoaCod()
     {
         return new Comparator()
         {

             public int compare(Object o1, Object o2)
             {
                 FuncionarioModelo dado1 = ( FuncionarioModelo ) o1;
                 FuncionarioModelo dado2 = ( FuncionarioModelo ) o2;
                return dado1.getCodigoFuncionario().compareToIgnoreCase(dado2.getCodigoFuncionario());
             }
         };
     }

     public void eliminarChave(){
       FuncionarioModelo dadoAEliminar = new FuncionarioModelo();
       GravadorFuncionarioModelo gravadorE = new GravadorFuncionarioModelo();
       Gravavel gravavel;
       int linha = table.getSelectedRow();
       if(linha > -1){
         // JOptionPane.showMessageDialog(null, "Linha "+nome);
         gravavel = (Gravavel) lista.get(linha);
         dadoAEliminar = (FuncionarioModelo) gravavel;

         try
              {
                  if( gravadorE.remover(dadoAEliminar.getChave()) )
                  {
                      JOptionPane.showMessageDialog(null, "Registo Eliminado com sucesso!!!");
                      ((DefaultTableModel)table.getModel()).removeRow(linha);
                      lista.remove(linha);
                  }
                  else
                  {
                      JOptionPane.showMessageDialog(null, "Nao foi possivel Eliminar o registo!!!");
                  }
              }
              catch (Exception e)
              {
                  JOptionPane.showMessageDialog(null, "Ocorreu um erro ao Eliminar o registo!!!");
              }
       }
       else{
         JOptionPane.showMessageDialog(null, "Por favor, selecione a linha a eliminar","Erro",JOptionPane.ERROR_MESSAGE);
       }
     }



   public void alterar(){
     String chave;
     int linha = table.getSelectedRow();
     FuncionarioModelo dadoAlterar = new FuncionarioModelo();
     Gravavel gravavel;
     if(linha > -1){
       gravavel = (Gravavel) lista.get(linha);
       dadoAlterar = (FuncionarioModelo) gravavel;
       chave = dadoAlterar.getCodigoFuncionario();
       new AlterarFuncionarioVisao (chave, true);
     }else{
       JOptionPane.showMessageDialog(null, "Por favor, selecione a linha a Alterar","Erro",JOptionPane.ERROR_MESSAGE);
     }
   }


  public void actionPerformed(ActionEvent e){
    if(e.getSource() == btnVerTodos){
      mostrarTudo();
    }
    else if(e.getSource() == btnAlterar){
      this.dispose ();
      alterar ();
    }
    else if(e.getSource() == btnEliminar)
      eliminarChave ();
    else if(e.getSource() == btnCancelar){
      dispose();
    }
  }

  private void procuraTable(String nome){
     int tamanho = nome.length();
     if(tamanho > 1){
     for (int linha = 0; linha < table.getRowCount(); linha++){
         String nomeTabela = (String)table.getValueAt(linha, 1);
         try{
            if (nomeTabela.substring(0,tamanho).toUpperCase().equals(nome.toUpperCase())){
              table.setRowSelectionInterval(linha,linha);
            }
         }catch(StringIndexOutOfBoundsException a){
         }
     }
     }
   }
}
