
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: Login.java
**  Nome: Francisco Andre Miguel
**	Data: 8 de Junho de 2016
**	Numero: 12636
**	Descricao: Fazer O Login Para Entrada Do Menu Principal
**
*********************************************************************************************************************
********************************************************************************************************************/


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import javax.swing.Icon;


public class Login extends JFrame {

	private JTextField jtUtilizador;
	private JPasswordField jpSenha;
	private JLabel jlUtilizador, jlSenha, loading;
  private JButton jbOk, jbCancelar;
	ImageSystem image;

    public Login() {

	    	super ( " Login ");
	      setLayout ( null );
				image = new ImageSystem ();

				ImageIcon icon = new ImageIcon ( image.LOCKER );
		    setIconImage ( icon.getImage ( ) );

      	Icon bug1 = new ImageIcon( getClass ( ).getResource( image.OK ) );
      	Icon bug3 = new ImageIcon( getClass( ).getResource( image.CANCEL ) );

      	jtUtilizador = new JTextField ( 20 );
      	jpSenha = new JPasswordField ( 20 );
      	jpSenha.setEchoChar ( '*' );
      	JLabel espaco = new JLabel ("                                                             " );
      	jlUtilizador = new JLabel ( "User ID      " );
      	jlSenha = new JLabel ( "Senha        " );
      	jbOk = new JButton ( "Entrar", bug1 );
      	jbOk.setBackground ( Color.WHITE );
      	jbCancelar = new JButton ( "Sair", bug3 );
      	jbCancelar.setBackground ( Color.WHITE );

      	//Icon bug2 = new ImageIcon ( ("Imagens/encrypted.png") );
				//Icon bug2 =
      	JLabel fancy = new JLabel ( image.criarIcone (image.LOCKER) );

      	fancy.setBounds ( 5, 5, 130, 130 );
      	jlUtilizador.setBounds ( 7, 150, 100, 25 );
      	jtUtilizador.setBounds ( 70, 150, 250, 25 );
      	jlSenha.setBounds ( 7, 180, 100, 25 );
	    	jpSenha.setBounds ( 70, 180, 250, 25 );
				jbOk.setBounds ( 100, 210, 90, 25 );
      	jbCancelar.setBounds ( 200, 210, 90, 25 );


	    	Container contentor = getContentPane ( );
      	contentor.setBackground ( Color.white );
      	contentor.add ( fancy );
		contentor.add ( jbOk );
      	contentor.add ( jlUtilizador );
      	contentor.add ( jtUtilizador );
      	contentor.add ( jlSenha );
      	contentor.add ( jpSenha );
      	contentor.add ( jbCancelar );



      	Trata eventos = new Trata ( );
      	jbOk.addActionListener ( eventos );
      	jbCancelar.addActionListener ( eventos );

				setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
      	setSize ( 367,275 );
      	setLocationRelativeTo ( null );
				setVisible ( true );
      	setResizable ( false );
				setForeground (Color.RED);
    }

    private class Trata implements ActionListener {

    	public void actionPerformed ( ActionEvent event ) {

      		if (event.getSource ( ) == jbOk) {

            	// Definindo User e Senha
                String utilizador2 = "root";
                String utilizador1 = ""+jtUtilizador.getText ( );
                String password2 = "root";
                String password1 = ""+jpSenha.getText ( );

                if ( utilizador2.equals ( utilizador1 ) ) {

                	if ( password2.equals ( password1 ) ) {
                    	setVisible ( false );
                      	new MenuPrincipal ( );

                   	}

                   	else {
                      	JOptionPane.showMessageDialog (null,"ENTRADA INVaLIDA\nSenha Errada", "", JOptionPane.ERROR_MESSAGE );
                      	limpa ( );
                   	}
                }

                else {
                    JOptionPane.showMessageDialog (null,"ENTRADA INVaLIDA\nUser ID Errado","", JOptionPane.ERROR_MESSAGE );
                   	limpa ( );
                }
             }

             if (event.getSource ( ) == jbCancelar) {
             	 // setVisible(false);
                 int escolha = JOptionPane.showConfirmDialog ( null, "Tem a certeza que pretende sair ?", "", JOptionPane.YES_NO_OPTION );

                 if ( escolha == JOptionPane.YES_OPTION ) {
                 	dispose ( );
                 }
             }
       }

	}

    public void limpa() {
    	jtUtilizador.setText("");
      	jpSenha.setText("");
    }

}
