import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class TipoConta extends JFrame implements ActionListener{

  private JPanel panel,panelBtn;
  private JComboBox contasJcb;
  private JButton btnPesq, btnCancelar;
  private JLabel contasJlb;
  private String[] tipoConta = {"Conta Individual","Conta Conjunta"};

  public TipoConta(){
    setTitle("Tipo De Conta");
    setLayout(null);
    setSize(500, 200);
    setLocationRelativeTo(null);
    //setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    criaGui();
    setVisible(true);
  }

  public void criaGui()
  {
    panel = new JPanel ( new GridLayout (3,2));
    panelBtn = new JPanel ( new FlowLayout ());
    contasJcb = new JComboBox(tipoConta);
    btnPesq = new JButton("Entrar");
    btnCancelar = new JButton("Cancelar");
    contasJlb = new JLabel("Tipos De Contas");
    contasJlb.setBounds(10,40, 120, 25);
    contasJcb.setBounds(150,40, 250, 25);
    btnCancelar.setBounds(250,110, 120, 25);
    btnPesq.setBounds(120,110, 120, 25);

    getContentPane().add(contasJlb);
    getContentPane().add(contasJcb);
    getContentPane().add(btnPesq);
    getContentPane().add(btnCancelar);

    btnPesq.addActionListener(this);
    btnCancelar.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e){
    if(e.getSource() == btnCancelar){
       dispose();
    }
    if(e.getSource() == btnPesq){
        if (contasJcb.getSelectedItem ().toString ().equals (tipoConta[0]))
        {
            this.dispose ();
            new ContaVisao ();
        }
        else
            JOptionPane.showMessageDialog (null,"Conta Conjunta");
    }
  }
}
