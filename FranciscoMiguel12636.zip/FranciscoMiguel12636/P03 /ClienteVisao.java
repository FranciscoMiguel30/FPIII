/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: ClienteVisao.java
**	Objectivo: Formulario De Cliente
**  Nome: Francisco André Miguel
**	Data: 15 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import yb.hashtableyb.GravadorGenericoHT;
import java.util.regex.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.text.*;

public class ClienteVisao extends JFrame
{
  private JPanel  painelCentro,painelBotoes,painelCodigo;
  private JTextField nomeJtf,numeroDocumentoIdJtf,apelidoJtf,nomePaiJtf,nomeMaeJtf,dataNascimentoJtf,dataEmissaoJtf;
  private JTextField numeroDeContribuinteJtf,emailJtf,codigoJtf;
  private JFormattedTextField contactoJtf;
  private MaskFormatter mascara;
  private JComboBoxPersonal provinciasJcb, municipiosJcb, bairrosJcb;
  private JButton okJb, limparJb,cancelJb;
  private JComboBoxTabela3_Tabela3 provinciasMunicipiosBairrosJcb;
  private JComboBox sexoJcb,estadoCivilJcb,habilitacaoJcb,documentoIdJcb,nacionalidadeJcb,dominioEmailJcb,regimeJcb;
  private JTextFieldData dataEmissao,dataNascimento;
  private JComboBox codigoJcb;
  private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
  private GravadorClienteModelo gravador = new GravadorClienteModelo();

  public ClienteVisao()
	{
    geraPainelCentro();
    geraPainelBotoes();
    painelCentro.setBorder ( new TitledBorder (new BevelBorder(1,Color.black,Color.black)," Cliente ") );
    getContentPane().add(painelCentro, BorderLayout.CENTER);
    getContentPane().add(painelCodigo, BorderLayout.NORTH);
    getContentPane().add(painelBotoes, BorderLayout.SOUTH);
    setTitle("Formulario De Clientes - BFA");
    setSize(700, 400);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setLocationRelativeTo ( null );
    setVisible(true);

    TrataEventos eventos = new TrataEventos ();
    okJb.addActionListener (eventos);
    limparJb.addActionListener (eventos);
    cancelJb.addActionListener (eventos);
	}

  public void geraPainelCentro()
  {
    painelCentro = new JPanel();
    painelCentro.setLayout(new GridLayout( 10, 4));

    provinciasMunicipiosBairrosJcb = new JComboBoxTabela3_Tabela3(Definicoes.FILEPROVINCIAS, Definicoes.FILEMUNICIPIOS,
                                                                 Definicoes.FILEBAIRROS);



    addCodigoCliente ();
    addNomeCompleto ();
    addApelido ();
    addContacto ();
    addnumeroCliente ();
    addDataNascimento ();
    addDataEmissao ();
    addProvincias ();
    addDocumentoId ();
    addMunicipios ();
    addNomePai ();
    addBairro ();
    addNomeMae ();
    addNacionalidade ();
    addNumeroContribuinte ();
    addSexo ();
    addEstadoCivil ();
    addEmail ();
    addDominioEmail ();
    addHabilitacao ();
  }

  public Vector<String> carregarCodigo(){
    Vector<String> listaCodigo = new Vector<String>();
    try
    {
       ClienteModelo modelo;
       lista = gravador.lerTodos();
       for(Gravavel gravavel : lista)
       {
         modelo = (ClienteModelo) gravavel;
         String codigo = "1";
         listaCodigo.addElement(codigo.valueOf (modelo.getCodigo()));
       }
     }catch(IOException e){}
    return listaCodigo;
  }

  public void addCodigoCliente ()
  {
    codigoJtf = new JTextField (10);
    codigoJtf.setText ("" + geraNumCliente ());
    codigoJtf.setEnabled (false);
    painelCodigo = new JPanel ();
    painelCodigo.setBorder (new TitledBorder (""));
    painelCodigo.add( new JLabel ("Codigo Do Cliente"));
    painelCodigo.add(codigoJtf);
  }

  public void addHabilitacao ()
  {
    habilitacaoJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEHABILITACAO).getItems () );
    painelCentro.add( new JLabel ("  Habilitacao"));
    painelCentro.add(habilitacaoJcb);
  }

  public void addnumeroCliente ()
  {
    painelCentro.add(new JLabel ("   Nº BI"));
    numeroDocumentoIdJtf = new JTextField ();
    painelCentro.add(numeroDocumentoIdJtf);
  }

  public void addContacto ()
  {
    try{
       mascara = new MaskFormatter ("#########");
       mascara.setPlaceholderCharacter ('_');
    }
    catch (ParseException e){}
    painelCentro.add(new JLabel ("  Nº De Telefone"));
    contactoJtf = new JFormattedTextField (mascara);
    painelCentro.add (contactoJtf);
  }

  public void addNomeCompleto ()
  {

    painelCentro.add(new JLabel ("  Nome"));
    nomeJtf = new JTextField ();
    painelCentro.add(nomeJtf);
  }

  public void addApelido ()
  {
    apelidoJtf = new JTextField ();
    painelCentro.add( new JLabel ("   Apelido"));
    painelCentro.add(apelidoJtf);
  }

  public void addDataNascimento ()
  {
    painelCentro.add( new JLabel ("  Data de Nascimento"));
    DataPanel dataNascimentoPainel = new DataPanel("");
    //painelCentro.add(createPanelDataNascimento());
    dataNascimentoJtf = dataNascimentoPainel.getDTestField();
    painelCentro.add(dataNascimentoPainel);
  }

  public void addProvincias ()
  {
    painelCentro.add(new JLabel ("  Provincia"));
    provinciasJcb = provinciasMunicipiosBairrosJcb.getComboBoxFather();
    painelCentro.add(provinciasJcb);
  }

  public void addDocumentoId ()
  {
    documentoIdJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEDOCUMENTOID).getItems () );
    painelCentro.add( new JLabel ("   Doc. de Identificação"));
    painelCentro.add(documentoIdJcb);
  }

  public void addMunicipios ()
  {
    painelCentro.add(new JLabel ("  Municipio"));
    municipiosJcb = provinciasMunicipiosBairrosJcb.getComboBoxSun();
    painelCentro.add(municipiosJcb);
  }

  public void addDataEmissao ()
  {
    painelCentro.add(new JLabel ("   Data De Emissão"));

    DataPanel dataEmissaoPainel = new DataPanel("");
    dataEmissaoJtf = dataEmissaoPainel.getDTestField();
    painelCentro.add(dataEmissaoPainel);
  }

  public void addBairro ()
  {
    painelCentro.add(new JLabel ("  Bairro"));
    bairrosJcb = provinciasMunicipiosBairrosJcb.getComboBoxNeto();
    painelCentro.add(bairrosJcb);
  }

  public void addNomePai ()
  {
    nomePaiJtf = new JTextField ();
    painelCentro.add(new JLabel ("   Nome Do Pai"));
    painelCentro.add(nomePaiJtf);
  }

  public void addNomeMae ()
  {
    nomeMaeJtf = new JTextField ();
    painelCentro.add(new JLabel ("   Nome da Mãe"));
    painelCentro.add(nomeMaeJtf);
  }

  public void addNacionalidade ()
  {
    nacionalidadeJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILENACIONALIDADE).getItems () );
    painelCentro.add(new JLabel ("  Nacionalidade"));
    painelCentro.add(nacionalidadeJcb);
  }

  public void addNumeroContribuinte ()
  {
    numeroDeContribuinteJtf = new JTextField ();
    painelCentro.add(new JLabel ("   Nº de Contribuinte"));
    painelCentro.add (numeroDeContribuinteJtf);
  }

  public void addSexo ()
  {
    sexoJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILESEXO).getItems () );
    painelCentro.add(new JLabel ("  Sexo"));
    painelCentro.add(sexoJcb);
  }

  public void addEstadoCivil ()
  {
    estadoCivilJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEESTADOCIVIL).getItems () );
    painelCentro.add( new JLabel ("   Estado Civil"));
    painelCentro.add(estadoCivilJcb);
  }

  public void addEmail ()
  {
    emailJtf = new JTextField ();
    painelCentro.add(new JLabel ("  Email"));
    painelCentro.add (emailJtf);
  }

  public void addDominioEmail ()
  {
    dominioEmailJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEDOMINIOEMAIL).getItems () );
    painelCentro.add(dominioEmailJcb);
    painelCentro.add( new JLabel (""));
  }

  public int getCodigo ()
  {
    return Integer.parseInt (codigoJtf.getText ().toString ().trim ());
  }

  public String getnumeroDocumentoIdJtf ()
  {
    return numeroDocumentoIdJtf.getText ().toString ().trim ();
  }

  public String getHabilitacaoJcb ()
  {
    return habilitacaoJcb.getSelectedItem().toString ();
  }

  public String getCodigoJtf ()
  {
    return codigoJtf.getText ().toString ().trim ();
  }

  public String getContactoJtf ()
  {

    return contactoJtf.getText ().toString ().trim ();
  }

  public String getNomeJtf ()
  {
    return nomeJtf.getText ().toString ().trim ();
  }

  public String getApelidoJtf ()
  {
    return apelidoJtf.getText ().toString ().trim ();
  }

  public String getNacionalidadeJcb ()
  {
    return nacionalidadeJcb.getSelectedItem().toString ();
  }

  public String getSexoJcb ()
  {
    return sexoJcb.getSelectedItem().toString ();
  }

  public String getEstadoCivilJcb ()
  {
    return estadoCivilJcb.getSelectedItem().toString ();
  }


  public String getNomePaiJtf ()
  {
    return nomePaiJtf.getText ().toString ().trim ();
  }

  public String getNomeMaeJtf ()
  {
    return nomeMaeJtf.getText ().toString ().trim ();
  }

  public String getNumeroDeContribuinteJtf ()
  {
    return numeroDeContribuinteJtf.getText ().toString ().trim ();
  }

  public String getEmailJtf ()
  {
    return emailJtf.getText ().toString ().trim ();
  }

  public String getDocumentoIdJcb ()
  {
    return documentoIdJcb.getSelectedItem().toString ();
  }

  public String getDominioEmail ()
  {
    return dominioEmailJcb.getSelectedItem().toString ();
  }

  public String getProvincia ()
  {
    return provinciasJcb.getSelectedItem().toString ();
  }

  public String getMunicipio ()
  {
    return municipiosJcb.getSelectedItem().toString ();
  }

  public String getBairro ()
  {
    return bairrosJcb.getSelectedItem().toString ();
  }

  public void limparFormulario()
  {
    contactoJtf.setText("");
    numeroDocumentoIdJtf.setText("");
    nomeJtf.setText("");
    apelidoJtf.setText("");
    nomePaiJtf.setText("");
    nomeMaeJtf.setText("");
    numeroDeContribuinteJtf.setText("");
    dataNascimentoJtf.setText("");
    dataEmissaoJtf.setText("");
    emailJtf.setText("");
  }//Fim do metodo limparFormulario()--------------------------------------------------------

  public ClienteModelo clienteModelo ( String codigo )
  {

    try
    {
       lista = gravador.lerTodos();
       ClienteModelo modelo;
       for(Gravavel gravavel : lista)
       {
         modelo = (ClienteModelo) gravavel;
         if (codigo.equals (modelo.getCodigo ()))
            return modelo;
       }
     }catch(IOException e){}

    return new ClienteModelo ( );
  }

/*  public void preencherClienteModelo ( ClienteModelo Cliente )
  {
    nomeJtf.setText ("" + Cliente.getNomeCompleto ( ) );
    regimeJtf.setText ("" + Cliente.getRegime ( ) );
    numeroDocumentoIdJtf.setText ("" + Cliente.getDocumentoId ( ) );
    contactoJtf.setText ("" + Cliente.getTelefone ( ) );
    apelidoJtf.setText ("" + Cliente.getApelido ( ) );
    dataNascimentoJtf.setText ("" + Cliente.getDataDeNascimento ( ) );
    provinciasJtf.setText ("" + Cliente.getProvincia ( ) );
    documentoIdJtf.setText ("" + Cliente.getDocumentoId ( ) );
    municipiosJtf.setText ("" + Cliente.getMunicipio ( ) );
    dataEmissaoJtf.setText ("" + Cliente.getDataEmissao ( ) );
    bairrosJtf.setText ("" + Cliente.getBairro ( ) );
    nomePaiJtf.setText ("" + Cliente.getNomeDoPai ( ) );
    nomeMaeJtf.setText ("" + Cliente.getNomeDaMae ( ) );
    nacionalidadeJtf.setText ("" + Cliente.getNacionalidade ( ) );
    numeroDeContribuinteJtf.setText ("" + Cliente.getNumeroDeContribuinte ( ) );
    sexoJtf.setText ("" + Cliente.getSexo ( ) );
    estadoCivilJtf.setText ("" + Cliente.getEstadoCivil ( ) );
    emailJtf.setText ("" + Cliente.getEmail ( ) + " " + Cliente.getDominioEmail() );
  }*/

  public ClienteModelo pegarModelo()
  {
    ClienteModelo modelo = new ClienteModelo();

    modelo.setCodigo (getCodigo ());
    modelo.setNumeroBi (getnumeroDocumentoIdJtf ());
		modelo.setNomeCompleto (getNomeJtf ());
    modelo.setApelido (getApelidoJtf ());
    modelo.setNumeroDeContribuinte ( getNumeroDeContribuinteJtf ());
    modelo.setEstadoCivil ( getEstadoCivilJcb ());
    modelo.setDominioEmail (getDominioEmail());
    modelo.setDataDeNascimento (dataNascimentoJtf.getText ().trim ());
    modelo.setProvincia (getProvincia ());
    modelo.setMunicipio (getMunicipio ());
    modelo.setBairro (getBairro());
    modelo.setNomeDoPai (getNomePaiJtf ());
    modelo.setNomeDaMae (getNomeMaeJtf ());
    modelo.setNacionalidade (getNacionalidadeJcb ());
    modelo.setEmail (getEmailJtf ());
    modelo.setSexo (getSexoJcb ());
    modelo.setTelefone (getContactoJtf ());
    modelo.setDocumentoId (getDocumentoIdJcb ());
    modelo.setDataEmissao (dataEmissaoJtf.getText ().trim () );
    modelo.setHabilitacao (getHabilitacaoJcb ());
    return modelo;
  }

  public boolean validarCampos()
  {
    String str = "";
    if(nomeJtf.getText().equals("")){
      str += "Insira um valor valido para o Nome\n";
    }
    if(emailJtf.getText().equals("")){
      str += "Insira um valor valido para o Apelido\n";
    }
    if(str.equals("")){
      return true;
    }
    return false;
  }

  public void salvarFile ()
  {    
      try
      {
          boolean gravou = gravador.gravar ( pegarModelo() );
          if (gravou)
          {
              JOptionPane.showMessageDialog(null, "Registro Cliente Gravado Com Sucesso","Sucessfull",JOptionPane.INFORMATION_MESSAGE);
              int codigo = Integer.parseInt (codigoJtf.getText ().toString ().trim ());
              incrementaNumeroDoCliente(codigo);
              codigoJtf.setText("" + geraNumCliente());
              limparFormulario ();
          }
          else
          {
              JOptionPane.showMessageDialog(null, "Chave ja existente!", "Erro!",JOptionPane.ERROR_MESSAGE);
          }
      }
      catch(IOException ex)
      {
          JOptionPane.showMessageDialog(this, "Erro ao gravar... a Cliente");
      }
 }// Fim do metodo salvarFormularioCliente() ------------------------------------------------

  public void geraPainelBotoes()
  {
    painelBotoes = new JPanel();
    okJb = new JButton("Ok");
    limparJb = new JButton("Limpar");
    cancelJb = new JButton("Cancelar");
    painelBotoes.setLayout(new FlowLayout());
    painelBotoes.add(okJb);
    painelBotoes.add(limparJb);
    painelBotoes.add(cancelJb);
  }

  public int geraNumCliente ()
  {
      GeraCodigo gerar = new GeraCodigo();
      int cod = gerar.getNumCliente();
      return cod;
  }// Fim do metodo geraNumCliente()--------------------------------------------------------

  public void incrementaNumeroDoCliente(int codCliente)
  {
      GeraCodigo gerar = new GeraCodigo();
      gerar.setNumCliente(codCliente + 1);
  }//Fim do metodo incrementaNumeroDoCliente(int codCliente)-------------------------------------------

  private class TrataEventos implements ActionListener
    {
        public void actionPerformed(ActionEvent evento)
        {
            if (evento.getSource() == okJb)
            {
                salvarFile ();
            }//Fim Botao Salvar--------------------------------------------------------

            else if (evento.getSource() == cancelJb)
            {
                dispose();
            }//Fim Botao cancelar--------------------------------------------------------

            else if (evento.getSource() == limparJb)
            {
                limparFormulario();
            }//Fim Botao Limpar -------------------------------------------------------
        }
    }//Fim Da Classe TrataEventos -----------------------------------------------------
}
