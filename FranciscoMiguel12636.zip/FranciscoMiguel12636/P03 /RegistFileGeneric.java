
import java.io.*;


public interface RegistFileGeneric
{
	public long sizeof();
	public void append(RegistGeneric registo);
}

