
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: PesquisarClientePorNome.java
**  Nome: Francisco André Miguel
**	Data: 17 de Junho de 2016
**	Numero: 12636
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.List;
import java.util.ArrayList;
import java.util.List;
import yb.hashtableyb.Gravavel;

public class PesquisarClientePorNome extends JFrame  implements ActionListener{

	  private JPanel painelNome,painelData, painelData1, painelData2, painelCentro, painelBtn,painelTabela,painelJediEpainelJuntos,painelmedia;
	  private JTextArea editorPane;
	  private JLabel jlbNome;
	  private JTextField jtfNome;
	  private JScrollPane editorScrollPane,jspTabela;
	  private JButton btnPesquisar, btnCancelar,btnVerTodos;
	  // Dados para Tabela
	  private Object[][] dados = new Object[][]{{}};
	  private JTable table;
	  private DefaultTableModel modelo;

		private String[] colunas = new String[]{"Nº BI","Nome","Apelido","Sexo","Documento Identificacao","Data de Emissão",
										 "Data Nascimento","Nacionalidade","Comuna","Provincia","Municipio","Estado Civil","Nº Tel.","Nome Mãe",
			"Nome Pai","E - Mail","Nº Contribuinte"};

		private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
	  private GravadorClienteModelo gravador = new GravadorClienteModelo();

	  private String str = "";

	  public PesquisarClientePorNome(){
			setTitle("Pesquisar Clientes Por Nome");
			setLayout(new BorderLayout());
			setSize(800,600);
			setLocationRelativeTo(null);
			setResizable(true);
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			criaGui();
			setVisible(true);
	  }

	  public void criaGui(){
	   //Instanciado JEditorPane
		editorPane = new JTextArea("");
		editorPane.setEditable(false);
		editorScrollPane = new JScrollPane(editorPane,editorScrollPane.VERTICAL_SCROLLBAR_ALWAYS, editorScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		editorScrollPane.setPreferredSize(new Dimension(700,150));

		//Instanciando Paineis
		painelTabela = new JPanel(new GridBagLayout());
		painelmedia = new JPanel(new GridBagLayout());
		painelBtn = new JPanel(new FlowLayout());
    painelNome = new JPanel(new FlowLayout());
		painelData = new JPanel(new FlowLayout());
		painelData1 = new JPanel();
		painelData2 = new JPanel();
		painelCentro = new JPanel(new BorderLayout());

		//Instanciando os Botãoes
		btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(this);
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(this);
		btnVerTodos = new JButton("Ver Todos");
		btnVerTodos.addActionListener(this);

		//Labels e Cambos de Edicao
		jlbNome = new JLabel("Digite Nome: ");
		jtfNome = new JTextField(10);


		//  Criando a Tabela
		modelo = (new DefaultTableModel(dados, colunas)
		{
			public boolean isCellEditable(int row, int column) {
					return false;
			}
		});

		Mouse mouse = new Mouse();
		table = new JTable();

		final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(modelo);

		table.setRowSorter(sorter);
		modelo.setRowCount(0);

		//Acoes nos Botoes
		table.addMouseListener(mouse);
  	table.addKeyListener(mouse);

		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setModel(modelo);

		//Ajuste da Tabela
		table.getColumnModel().getColumn(0).setPreferredWidth(200);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(2).setPreferredWidth(125);
		table.getColumnModel().getColumn(3).setPreferredWidth(125);
		table.getColumnModel().getColumn(4).setPreferredWidth(125);
		table.getColumnModel().getColumn(5).setPreferredWidth(175);
		table.getColumnModel().getColumn(6).setPreferredWidth(175);
		table.getColumnModel().getColumn(7).setPreferredWidth(125);
		table.getColumnModel().getColumn(8).setPreferredWidth(125);
		table.getColumnModel().getColumn(9).setPreferredWidth(175);
		table.getColumnModel().getColumn(10).setPreferredWidth(125);
		table.getColumnModel().getColumn(11).setPreferredWidth(75);
		table.getColumnModel().getColumn(12).setPreferredWidth(75);
		table.getColumnModel().getColumn(13).setPreferredWidth(75);
		table.getColumnModel().getColumn(14).setPreferredWidth(125);
		table.getColumnModel().getColumn(15).setPreferredWidth(175);
		table.getColumnModel().getColumn(16).setPreferredWidth(125);

		jspTabela = new JScrollPane(table, jspTabela.VERTICAL_SCROLLBAR_ALWAYS, jspTabela.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jspTabela.setPreferredSize(new Dimension(700,200));
		painelTabela.add(jspTabela, new GridBagConstraints(0,2,12,1,0,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5,5,5,5),0,0));
		painelmedia.add(editorScrollPane, new GridBagConstraints(0,0,8,1,0,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(10,10,10,0),0,0));

		painelTabela.setBorder(BorderFactory.createTitledBorder("Dados Encontrados"));

		painelNome.add(jlbNome);
		painelNome.add(jtfNome);
		painelNome.setBorder(BorderFactory.createTitledBorder("Nome"));

		painelBtn.add(btnPesquisar);
		painelBtn.add(btnVerTodos);
		painelBtn.add(btnCancelar);

		painelCentro.add(painelTabela, BorderLayout.CENTER);
		painelCentro.add(painelmedia, BorderLayout.SOUTH);

		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(painelNome, BorderLayout.NORTH);
		getContentPane().add(painelCentro, BorderLayout.CENTER);
		getContentPane().add( painelBtn, BorderLayout.SOUTH);

	  }

	  //Eventos de Mouse
	  public class Mouse implements MouseListener,KeyListener
	  {
	    	    public void mouseClicked(MouseEvent e){
 						ClienteModelo elemento = (ClienteModelo) lista.get (table.getSelectedRow ());

						editorPane.setText(elemento.toString());
						editorPane.setFont(new Font("Arial", Font.ITALIC, 16));
						editorPane.setBackground(Color.blue);
						editorPane.setForeground(Color.WHITE);
					}

					public void mousePressed(MouseEvent e)
					{  }
					public void mouseReleased(MouseEvent e) { }
					public void mouseEntered(MouseEvent e){}
					public void mouseExited(MouseEvent e){}
					public void keyPressed(KeyEvent k){}


					public void keyReleased(KeyEvent k)
					{

					}

					public void keyTyped(KeyEvent k)
  					{  }
		}

		public void mostrarTudo(){
     modelo.setRowCount(0);
     try
     {
       lista = gravador.lerTodos();
       ClienteModelo formulario;
       for( Gravavel gravavel : lista )
       {
         formulario = (ClienteModelo) gravavel;
         Object[] object = new Object[17];
         object[0]= formulario.getNumeroBi();
         object[1]= formulario.getNomeCompleto();
         object[2]= formulario.getApelido();
         object[3]= formulario.getSexo();
         object[4]= formulario.getDocumentoId();
         object[5]= formulario.getDataEmissao();
         object[6]= formulario.getDataDeNascimento();
         object[7]= formulario.getNacionalidade();
         object[8]= formulario.getBairro();
         object[9]= formulario.getProvincia();
         object[10]= formulario.getMunicipio();
         object[11]= formulario.getEstadoCivil();
         object[12]= formulario.getTelefone();
         object[13]= formulario.getNomeDaMae();
         object[14]= formulario.getNomeDoPai();
         object[15]= formulario.getEmail();
         object[16]= formulario.getNumeroDeContribuinte();
         modelo.addRow(object);
         ordenarLista();
       }
     }
     catch (IOException ex)
     {
       JOptionPane.showMessageDialog(this, "Ocorreu um erro ao fazer a leitura do ficheiro");
     }

   	}
		public void ordenarLista(){
      if(table.getRowCount() > 0){
       Collections.sort(lista, getComparadorPessoa());
       modelo.setRowCount(0);
           ClienteModelo formulario;
           for( Gravavel gravavel : lista )
           {
             formulario = (ClienteModelo) gravavel;
             Object[] object = new Object[17];
             object[0] = formulario.getNumeroBi();
             object[1] = formulario.getNomeCompleto();
             object[2] = formulario.getApelido();
             object[3] = formulario.getSexo();
             object[4] = formulario.getDocumentoId();
             object[5] = formulario.getDataEmissao();
             object[6] = formulario.getDataDeNascimento();
             object[7] = formulario.getNacionalidade();
             object[8] = formulario.getBairro();
             object[9] = formulario.getProvincia();
             object[10] = formulario.getMunicipio();
             object[11] = formulario.getEstadoCivil();
             object[12] = formulario.getTelefone();
             object[13] = formulario.getNomeDaMae();
             object[14] = formulario.getNomeDoPai();
             object[15] = formulario.getEmail();
             object[16] = formulario.getNumeroDeContribuinte();
             modelo.addRow(object);
          }
      }else{
          JOptionPane.showMessageDialog(null, "Carregue primeiro os registos na tabela - click vet todos!!!");
      }


    }

		public void pesquisa(String nome)
		{
			modelo.setRowCount(0);
			Collections.sort(lista, getComparadorPessoa());
				try
				{
					lista = gravador.lerTodos();
					ClienteModelo formulario;
					for( Gravavel gravavel : lista )
					{
						formulario = (ClienteModelo) gravavel;
						if(nome.trim ().equalsIgnoreCase(formulario.getNomeCompleto().trim ()))
						{
							Object[] object = new Object[17];
							object[0] = formulario.getNumeroBi();
							object[1] = formulario.getNomeCompleto();
							object[2] = formulario.getApelido();
							object[3] = formulario.getSexo();
							object[4] = formulario.getDocumentoId();
							object[5] = formulario.getDataEmissao();
							object[6] = formulario.getDataDeNascimento();
							object[7] = formulario.getNacionalidade();
							object[8] = formulario.getBairro();
							object[9] = formulario.getProvincia();
							object[10] = formulario.getMunicipio();
							object[11] = formulario.getEstadoCivil();
							object[12] = formulario.getTelefone();
							object[13] = formulario.getNomeDaMae();
							object[14] = formulario.getNomeDoPai();
							object[15] = formulario.getEmail();
							object[16] = formulario.getNumeroDeContribuinte();
							modelo.addRow(object);
							//ordenarLista();
						}
					}
				}catch (IOException ex) {}
	  			int linha = table.getRowCount();
					if(linha == 0)
					{
				    	 JOptionPane.showMessageDialog(null, "Dados Não Encontados!!!", "ERRO NA ENTRADA DE DADOS",JOptionPane.ERROR_MESSAGE );
					}
		} // fim do Metodo


		private Comparator getComparadorPessoa()
    {
       return new Comparator()
       {

           public int compare(Object o1, Object o2)
           {
               ClienteModelo dado1 = ( ClienteModelo ) o1;
               ClienteModelo dado2 = ( ClienteModelo ) o2;

               return dado1.getNomeCompleto().compareToIgnoreCase(dado2.getNomeCompleto());
           }
       };
   	}


	   //Tratamento de Eventos nos Botoes
	   public void actionPerformed(ActionEvent eventos)
	   {
		  if(eventos.getSource() == btnCancelar)
			  dispose();
		  else if (eventos.getSource() == btnPesquisar)
		  {
				pesquisa(jtfNome.getText().toString ().trim ());
		  }
		  else if(eventos.getSource() == btnVerTodos)
			      	mostrarTudo();
	   }
}
