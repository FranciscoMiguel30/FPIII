
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: DepositaExtractoControlo.java
**	Objectivo: Controla O Tipo De Operacao Para Incluir No Extrato
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import java.util.regex.*;
import yb.hashtableyb.GravadorGenericoHT;
import java.io.*;


public class DepositaExtractoControlo
{
  private Iterator it;
  protected Vector<Integer> operacaoAux;
  private ExtractoVisao ext;
  public DepositaExtractoControlo ()
  {
      ext = new ExtractoVisao (operacaoAux);
      ext.dispose ();
      operacaoAux = new Vector<Integer> ();
      operacaoAux.addElement (0);
      it = operacaoAux.iterator ();
      while (it.hasNext())
      {
        //JOptionPane.showMessageDialog (null,"" + new ExtractoVisao (false).getOperacao ().size ());
      }
  }

  public Iterator getIterator ()
  {
    return it;
  }
}
