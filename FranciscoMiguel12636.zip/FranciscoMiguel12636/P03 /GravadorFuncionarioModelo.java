/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: GravadorPessoaModelo.java
**	Objectivo: Armazenar cliente na HashTable
**  Nome: Francisco André Miguel
**	Data: 15 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import yb.hashtableyb.GravadorGenericoHT;

public class GravadorFuncionarioModelo extends GravadorGenericoHT
{
  public GravadorFuncionarioModelo ()
  {
    super(Definicoes.FILEFUNCIONARIO, 50, new FuncionarioModelo());
  }
}
