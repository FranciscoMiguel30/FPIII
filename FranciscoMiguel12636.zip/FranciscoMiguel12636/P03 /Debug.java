import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public final class Debug 
{
	public static void debug(String msg)
	{
		JOptionPane.showMessageDialog(null, msg);
	}
	
}


