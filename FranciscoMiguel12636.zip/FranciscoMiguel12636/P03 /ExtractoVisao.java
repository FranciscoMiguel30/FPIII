

/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: ExtratoVisao.java
**	Objectivo: Formulario Extrato
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import java.util.regex.*;

public class ExtractoVisao extends JFrame implements ActionListener
{
  private String[] colunas = new String[]{"Numero De Conta","Nome","Saldo Da Conta","Tipo De Operacao","Data Da Operacao",
                                          "Saldo Da Operacao"};
  private JPanel painelTab, painelBtn, painelPesquisa;
  private JTable table;
  private DefaultTableModel modelo;
  private JButton btnCancelar,btnVerExtrato;
  private Object[][] dados = new Object[][]{{},{}};
  private JScrollPane scrool;
  private JLabel lblPesquisa;
  private JTextField jtfPesquisa;
  private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
  private GravadorContaModelo gravador = new GravadorContaModelo();
  private Vector<Integer> op;

  public ExtractoVisao (Vector<Integer> operacao){
    operacao = new Vector<Integer> ();
    op = (Vector<Integer>) operacao;
    op.addAll (operacao);
  }

  public ExtractoVisao (){
    setTitle("Visualizar Extracto");
    setSize (600, 600);
    op = new Vector<Integer> ();
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setResizable(false);
    criaGui();

    setVisible(true);
  }

  public void criaGui(){
    painelPesquisa = new JPanel (new FlowLayout());
    painelTab = new JPanel ();
    painelBtn = new JPanel (new FlowLayout());

    jtfPesquisa = new JTextField(17);
    painelPesquisa.add (new JLabel ("Numero Da Conta"));
    painelPesquisa.add (jtfPesquisa);
    modelo = (new DefaultTableModel(dados, colunas)
    {
			public boolean isCellEditable(int row, int column) {
					return false;
			}
		});

    table = new JTable();
    final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(modelo);
    table.setRowSorter(sorter);
    modelo.setRowCount(0);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    table.setModel(modelo);

    scrool = new JScrollPane(table, scrool.VERTICAL_SCROLLBAR_ALWAYS, scrool.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    scrool.setPreferredSize(new Dimension(560,485));
    painelTab.add(scrool);

    table.getColumnModel().getColumn(0).setPreferredWidth(200);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(2).setPreferredWidth(125);
		table.getColumnModel().getColumn(3).setPreferredWidth(200);
    table.getColumnModel().getColumn(4).setPreferredWidth(200);
    table.getColumnModel().getColumn(5).setPreferredWidth(200);

    btnCancelar = new JButton ("Cancelar");
    btnCancelar.setToolTipText("Fecha a janela");
    btnCancelar.addActionListener(this);
    btnVerExtrato = new JButton ("Ver Extracto");
    btnVerExtrato.addActionListener(this);
    btnVerExtrato.setToolTipText("Ver O Historico De Uma Determinada Conta");
    painelBtn.add(btnVerExtrato);
    painelBtn.add(btnCancelar);

    getContentPane().add(painelTab, BorderLayout.CENTER);
    getContentPane().add(painelBtn, BorderLayout.SOUTH);
    getContentPane().add(painelPesquisa, BorderLayout.NORTH);
  }

  public String getNumeroConta ()
  {
    return jtfPesquisa.getText ().toString ().trim ();
  }

   public void seeExtracto(){
    modelo.setRowCount(0);
    ContaModelo modeloConta;
    Vector<Integer>  operacaoAux =  new Vector<Integer> ();
    operacaoAux.addElement (2);
    //Iterator it = getOperacao ().iterator ();
    DepositarVisao depositar = new DepositarVisao ();
    depositar.dispose ();
    //while (it.hasNext ())
    JOptionPane.showMessageDialog (null,"" + op.size ());
    try
    {
      lista = gravador.lerTodos();

        for (Gravavel gravavel : lista)
        {
          modeloConta = (ContaModelo) gravavel;
          if (getNumeroConta ().equals(modeloConta.getNumeroConta ()))
          {
            Object[] object = new Object[6];
            object[0] = modeloConta.getNumeroConta();
            object[1] = modeloConta.getNomeCompleto();
            object[2] = modeloConta.getSaldoConta();
        //    object[3] = it.next() == 0 ? "Levantamento" : "Deposito";
            object[4] = depositar.getValorDeposito();
            object[5] = depositar.getDataDepositar();
            modelo.addRow(object);
          }
        }
        /*if(table.getRowCount() <= 0)
          JOptionPane.showMessageDialog(null, "Ficheiro Vazio");
        else{
          // Set the second visible column to 100 pixels wide
          int vColIndex = 3;
          TableColumn col = table.getColumnModel().getColumn(vColIndex);
          int width = 200;
          col.setPreferredWidth(width);
        }*/
        //ordenarLista();
    }
    catch (IOException ex)
    {
      JOptionPane.showMessageDialog(this, "Ocorreu um erro ao fazer a leitura do ficheiro");
    }
  }

 public void ordenarLista(){
   String srt = "";
   if(table.getRowCount() > 0){
    Collections.sort(lista, getComparadorPessoaCod());
    modelo.setRowCount(0);
    ContaModelo formulario;
    for( Gravavel gravavel : lista )
    {
      formulario = (ContaModelo) gravavel;
      Object[] object = new Object[8];
      object[1] = formulario.getNumeroConta();
      object[2] = formulario.getNomeCompleto();
    //  object[3] = str ? "Levantamento" : "Deposito";

      modelo.addRow(object);
    }
   }else{
       JOptionPane.showMessageDialog(null, "Carregue primeiro os registos na tabela - click vet todos!!!");
   }
 }
 private Comparator getComparadorPessoa()
    {
        return new Comparator()
        {

            public int compare(Object o1, Object o2)
            {
                ContaModelo dado1 = ( ContaModelo ) o1;
                ContaModelo dado2 = ( ContaModelo ) o2;

                return dado1.getNomeCompleto().compareToIgnoreCase(dado2.getNomeCompleto());
            }
        };
    }

    private Comparator getComparadorPessoaCod()
     {
         return new Comparator()
         {

             public int compare(Object o1, Object o2)
             {
                 ContaModelo dado1 = ( ContaModelo ) o1;
                 ContaModelo dado2 = ( ContaModelo ) o2;

                // return Integer.parseInt (dado1.getNumeroDocumentoIdJtf() ) < Integer.parseInt (dado2.getNumeroDocumentoIdJtf());
                return dado1.getNumeroConta().compareToIgnoreCase(dado2.getNumeroConta());
             }
         };
     }

  public void actionPerformed(ActionEvent e){
    if(e.getSource() == btnCancelar)
      dispose();
    if(e.getSource() == btnVerExtrato){
      seeExtracto();
    }
  }

  public static void main (String [] args)
  {
    new ExtractoVisao ();
  }
}
