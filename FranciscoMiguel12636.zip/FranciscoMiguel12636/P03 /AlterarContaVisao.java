
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: AlterarContaVisao.java
**	Objectivo: Formulario Da Conta
**  Nome: Francisco André Miguel
**	Data: 19 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;


public class AlterarContaVisao extends JFrame
{
  private JPanel painelCentro,painelBotoes;
  private JTextField saldoJtf,numeroContaJtf,nomeJtf,codigoClienteJtf;
  private JTextFieldData dataAberturaJtfd;
  private JComboBox tipoContaJcb,balcaoJcb,ordemDepositoJcb;
  private JButton okJb,limparJb,cancelJb;


  public AlterarContaVisao (String parmString, boolean btn){

    super("Formulario De Conta - BFA");

    criaGui(parmString, btn);
    geraPainelBotoes();
    Container ct = this.getContentPane();
    ct.add(painelCentro, BorderLayout.CENTER);
    ct.add(painelBotoes, BorderLayout.SOUTH);
    pack ();
    //setSize(300, 200);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setLocationRelativeTo ( null );
    setVisible(true);
    TrataEventos eventos = new TrataEventos ();
    okJb.addActionListener (eventos);
    limparJb.addActionListener (eventos);
    cancelJb.addActionListener (eventos);
	}

  private void criaGui (String dadoAlterar, boolean btn) {


    painelCentro = new JPanel();
    painelCentro.setLayout(new GridLayout( 8,1));

    addnumeroCliente ();
    addNumeroConta ();
    addNomeCompleto ();
    addSaldo ();
    addDataAbertura ();
    addTipoConta ();
    addBalcao ();
    addOrdemDeposito ();
    //Carrega o Dado a alterar
    procurarElemento(dadoAlterar);

  }


 public void procurarElemento(String dadoAlterar2)
 {
    ContaModelo dadoAlterar = new ContaModelo();
    GravadorContaModelo gravador = new GravadorContaModelo();
    try{

      dadoAlterar = (ContaModelo)gravador.ler(dadoAlterar2.trim());
      if(dadoAlterar != null)
      {
        numeroContaJtf.setText (dadoAlterar.getNumeroConta());
        nomeJtf.setText(dadoAlterar.getNomeCompleto());
        saldoJtf.setText(dadoAlterar.getSaldoConta());
        codigoClienteJtf.setText(dadoAlterar.getCodigoCliente());
        dataAberturaJtfd.setDtestField(dadoAlterar.getDataAbertura());
        tipoContaJcb.setSelectedItem(dadoAlterar.getTipoConta());
        balcaoJcb.setSelectedItem(dadoAlterar.getBalcao());
        ordemDepositoJcb.setSelectedItem(dadoAlterar.getOrdemDeposito());
      }else {
        JOptionPane.showMessageDialog(null, "dado bum!");
      }
    }catch(IOException exp){
       JOptionPane.showMessageDialog(null, "Erro ao ler o ficheiro!");
    }
  }

  public void addnumeroCliente ()
  {
    painelCentro.add(new JLabel ("Codigo Cliente"));
    codigoClienteJtf = new JTextField ();
    codigoClienteJtf.setEnabled (false);
    painelCentro.add(codigoClienteJtf);
  }

 public void addNumeroConta ()
 {

   painelCentro.add(new JLabel ("Numero Da Conta "));
   numeroContaJtf = new JTextField ();
   numeroContaJtf.setEnabled (false);
   painelCentro.add(numeroContaJtf);
 }

 public void addNomeCompleto ()
 {

   painelCentro.add(new JLabel ("Nome"));
   nomeJtf = new JTextField ();
   nomeJtf.setEnabled (false);
   painelCentro.add(nomeJtf);
 }

public void addSaldo ()
 {
   painelCentro.add(new JLabel ("Saldo"));
   saldoJtf = new JTextField ();
   saldoJtf.setEnabled (false);
   painelCentro.add(saldoJtf);
 }
public void addDataAbertura ()
 {
   painelCentro.add( new JLabel ("Data de Abertura"));
   painelCentro.add(createPanelDataAbertura());
 }
public void addTipoConta ()
 {
   tipoContaJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILETIPOCONTA).getItems () );
   painelCentro.add( new JLabel ("Tipo De Conta"));
   painelCentro.add(tipoContaJcb);
 }
 public void addBalcao ()
 {
   balcaoJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEBALCAO).getItems () );
   painelCentro.add( new JLabel ("Balcao"));
   painelCentro.add(balcaoJcb);
 }
public void addOrdemDeposito ()
 {
   ordemDepositoJcb = new JComboBox ( UInterfaceBox.createJComboBoxsTabela2(Definicoes.FILEORDEMDEPOSITO).getItems () );
   painelCentro.add( new JLabel ("Ordem De Deposito"));
   painelCentro.add(ordemDepositoJcb);
 }

 public JPanel createPanelDataAbertura()
 {
   JPanel panel = new JPanel();
   panel.setLayout(new GridLayout(1, 2));
   dataAberturaJtfd = new JTextFieldData ("");
   panel.add (dataAberturaJtfd.getDTestField());
   panel.add (dataAberturaJtfd.getDButton());
   return panel;
 }

public void limparFormulario()
 {
   dataAberturaJtfd.setDtestField("");
   saldoJtf.setText("");
   tipoContaJcb.setSelectedItem("");
   balcaoJcb.setSelectedItem("");
   ordemDepositoJcb.setSelectedItem("");
 }//Fim do metodo limparFormulario()-----------------------------------------------------
 public String getNumeroConta ()
 {
   return numeroContaJtf.getText ().toString ().trim ();
 }

 public String getNomeJtf ()
 {
   return nomeJtf.getText ().toString ().trim ();
 }

 public String getSaldoJtf ()
 {

   return saldoJtf.getText ().toString ().trim ();
 }

 public String getCodigoCliente ()
 {
   return codigoClienteJtf.getText().toString ();
 }

 public String getDataAberturaJtfd ()
 {
   return dataAberturaJtfd.getDTestField().getText();
 }

 public String getOrdemDepositoJcb()
 {
   return ordemDepositoJcb.getSelectedItem().toString ();
 }

 public String getTipoContaJcb()
 {
   return tipoContaJcb.getSelectedItem().toString ();
 }

 public String getBalcaoJcb()
 {
   return balcaoJcb.getSelectedItem().toString ();
 }

 Boolean validarCampos ()
 {
   if (saldoJtf.getText().isEmpty ())
   {
     JOptionPane.showMessageDialog (null,"Digite O Saldo Da Conta","ERROR",JOptionPane.ERROR_MESSAGE);
     return false;
   }
   if (dataAberturaJtfd.getDTestField().getText ().isEmpty ())
   {
     JOptionPane.showMessageDialog (null,"Digite A Data De Abertura Da Conta","ERROR",JOptionPane.ERROR_MESSAGE);
     return false;
   }
   return true;
 }

 public void actualizarDados(){
    ContaModelo modelo = new ContaModelo();
    GravadorContaModelo gravador = new GravadorContaModelo();
    ListarContas list;
    modelo.setNomeCompleto( getNomeJtf () );
    modelo.setNumeroConta(getNumeroConta ());
    modelo.setSaldoConta(getSaldoJtf ());
    modelo.setBalcao(getBalcaoJcb ());
    modelo.setTipoConta(getTipoContaJcb ());
    modelo.setCodigoCliente(getCodigoCliente ());
    modelo.setDataAbertura(getDataAberturaJtfd ());
    modelo.setOrdemDeposito(getOrdemDepositoJcb ());
    //lista = gravador.lerTodos();

    String oldKey = getNumeroConta ();
    try
        {
            if( gravador.editar(oldKey, modelo))
              {
                  JOptionPane.showMessageDialog(this, "Dados alterados com sucesso","Alterar",JOptionPane.INFORMATION_MESSAGE);
                  this.dispose();
                  list = new ListarContas (true);
                  list.mostrarTudo ();
              }
            else if(oldKey != (String)modelo.getChave())
                {
                   list = new ListarContas ();
                   gravador.editar(oldKey, modelo);
                   JOptionPane.showMessageDialog(this, "Dados alterados com sucesso","Alterar",JOptionPane.INFORMATION_MESSAGE);
                   this.dispose();
                   list = new ListarContas (true);
                   list.mostrarTudo ();
                }
                else
                {
                    JOptionPane.showMessageDialog(this, "Nao foi possivel alterar os dados\n Verifique se ja nao existe um cliente com o mesmo nome","Alterar",JOptionPane.ERROR_MESSAGE);
                }
        }
        catch (IOException e)
        {
            JOptionPane.showMessageDialog(this, "Erro ao alterar o registo");
        }
 }

  public void geraPainelBotoes()
  {
    painelBotoes = new JPanel();
    okJb = new JButton("Alterar");
    limparJb = new JButton("Limpar");
    cancelJb = new JButton("Cancelar");
    painelBotoes.setLayout(new FlowLayout());
    painelBotoes.add(okJb);
    painelBotoes.add(limparJb);
    painelBotoes.add(cancelJb);
  }

  private class TrataEventos implements ActionListener
    {
        public void actionPerformed(ActionEvent evento)
        {
            if (evento.getSource() == okJb)
            {
                actualizarDados();
            }//Fim Botao Salvar--------------------------------------------------------

            else if (evento.getSource() == cancelJb)
            {
              dispose ();
            }//Fim Botao cancelar--------------------------------------------------------

            else if (evento.getSource() == limparJb)
            {
              limparFormulario();
            }//Fim Botao Limpar -------------------------------------------------------
        }
    }//Fim Da Classe TrataEventos -----------------------------------------------------
}
