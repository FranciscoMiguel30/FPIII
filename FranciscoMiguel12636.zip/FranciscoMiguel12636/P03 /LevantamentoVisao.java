
/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: LevantamentoVisao.java
**	Objectivo: Levantar Dinheiro De Uma Respectiva Conta
**  Nome: Francisco André Miguel
**	Data: 16 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.Gravavel;
import java.util.regex.*;
import yb.hashtableyb.GravadorGenericoHT;
import java.io.*;

public class LevantamentoVisao extends JFrame
{
  private JComboBox numeroContaLevantarJcb;
  private JTextField nomeTitularJtf,valorLevantaJtf;
  private JTextFieldData dataLevantarJtfd;
  private JPanel painelCentro,painelBotoes;
  private JButton okJb,limparJb,cancelJb;
  private ArrayList<Gravavel> lista = new ArrayList<Gravavel>();
  private GravadorContaModelo gravador = new GravadorContaModelo();

  public LevantamentoVisao ()
  {
      super("Levantamento - BFA");
      geraPainelCentro();
      geraPainelBotoes();
      Container ct = this.getContentPane();
      ct.add(painelCentro, BorderLayout.CENTER);
      ct.add(painelBotoes, BorderLayout.SOUTH);
      pack ();
      //setSize(300, 200);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
      setLocationRelativeTo ( null );
      setVisible(true);
      TrataEventos eventos = new TrataEventos ();
      okJb.addActionListener (eventos);

      numeroContaLevantarJcb.addActionListener ( new EventoComboBox ( ) );
      limparJb.addActionListener (eventos);
      cancelJb.addActionListener (eventos);
  }

  public String getValorLevantar ()
  {
    return valorLevantaJtf.getText ().toString ().trim ();
  }

  public String getNumeroContaLevantar ()
  {
    return numeroContaLevantarJcb.getSelectedItem ().toString ();
  }

  public String getDataLevantar ()
  {
    return dataLevantarJtfd.getDTestField ().toString ();
  }

  public void geraPainelCentro()
  {
    painelCentro = new JPanel();
    painelCentro.setLayout(new GridLayout( 4,1));

    addNumeroContaLevantar ();
    addNomeTitular ();
    addValorLevanta ();
    addDataAbertura ();
  }


  public JPanel createPanelDataLevantar()
  {
    JPanel panel = new JPanel();
    panel.setLayout(new GridLayout(1, 2));
    dataLevantarJtfd = new JTextFieldData ("");
    panel.add (dataLevantarJtfd.getDTestField());
    panel.add (dataLevantarJtfd.getDButton());
    return panel;
  }

  private class EventoComboBox implements ActionListener
  {
    public void actionPerformed ( ActionEvent evento )
    {
      if ( evento.getSource ( ) ==  numeroContaLevantarJcb)
      {
          preencherNomeClienteModelo ( nomeDoClienteModelo ( numeroContaLevantarJcb.getSelectedItem ().toString ().trim ()));
      }
    }
  }

  public Vector<String> carregarNumeroConta()
  {
    Vector<String> listaNumeroConta = new Vector<String>();

    try
    {
       ContaModelo modelo;
       lista = gravador.lerTodos();
       for(Gravavel gravavel : lista)
       {
         modelo = (ContaModelo) gravavel;
         listaNumeroConta.add(modelo.getNumeroConta());
       }
       ordenarComboBox ( listaNumeroConta );
     }catch(IOException e){}
    return listaNumeroConta;
  }

  public ContaModelo nomeDoClienteModelo ( String numeroConta )
  {

    try
    {
       lista = gravador.lerTodos();
       ContaModelo modelo;
       for(Gravavel gravavel : lista)
       {
         modelo = (ContaModelo) gravavel;
         //JOptionPane.showMessageDialog (null,"nome ComboBox : " + nome + "nome File" + modelo.getNomeCompleto () );
         if (numeroConta.equals (modelo.getNumeroConta ()))
            return modelo;
       }
     }catch(IOException e){}

    return new ContaModelo ( );
  }

  public void preencherNomeClienteModelo ( ContaModelo clienteConta )
  {
    nomeTitularJtf.setText ("" + clienteConta.getNomeCompleto ( ) );
  }

  public void addDataAbertura ()
  {
    painelCentro.add( new JLabel ("Data do Levantamento"));
    painelCentro.add(createPanelDataLevantar());
  }

  public void addNumeroContaLevantar ()
  {
    painelCentro.add (new JLabel ("Numero Da Conta A Levantar"));
    numeroContaLevantarJcb = new JComboBox (carregarNumeroConta ());
    painelCentro.add (numeroContaLevantarJcb);
  }

  public void addNomeTitular ()
  {

    painelCentro.add(new JLabel ("Titular"));
    nomeTitularJtf = new JTextField ();
    nomeTitularJtf.setEnabled (false);
    painelCentro.add(nomeTitularJtf);
  }

  public void addValorLevanta ()
  {

    painelCentro.add(new JLabel ("Valor Do levantamento"));
    valorLevantaJtf = new JTextField ();
    painelCentro.add(valorLevantaJtf);
  }

  public void geraPainelBotoes()
  {
    painelBotoes = new JPanel();
    okJb = new JButton("Ok");
    limparJb = new JButton("Limpar");
    cancelJb = new JButton("Cancelar");
    painelBotoes.setLayout(new FlowLayout());
    painelBotoes.add(okJb);
    painelBotoes.add(limparJb);
    painelBotoes.add(cancelJb);
  }

  public void levantamentoConta ()
  {
    ContaModelo modelo = new ContaModelo ();
    try
    {
      if (validarCampos ())
      {
        modelo = (ContaModelo) gravador.ler(getNumeroContaLevantar());
        if (modelo != null)
        {
         //JOptionPane.showMessageDialog (null,"nome ComboBox : " + nome + "nome File" + modelo.getNomeCompleto () );
         if (getNumeroContaLevantar ().equals (modelo.getNumeroConta ()))
            {
               double valor1 = Double.parseDouble ( modelo.getSaldoConta ());
               double valor2 = Double.parseDouble ( getValorLevantar () );
               double total = valor1 - valor2;
               if (total > 0.0)
               {
                 //new LevantamentoExtractoControlo ();
                 modelo.setSaldoConta ("" + total);
                 modelo.setDataLevantar ("" + getDataLevantar () );
                 gravador.editar(modelo.getNumeroConta (), modelo);
                 JOptionPane.showMessageDialog (null,"Levantamento Efectuado Com Sucesso","Informacao",JOptionPane.INFORMATION_MESSAGE);
               }
               else
               JOptionPane.showMessageDialog (null,"Error, Digite O Nome Do Titular A Levantar","Error",JOptionPane.ERROR_MESSAGE);
            }
        }
      }
    }catch(IOException e){}
  }

  public Boolean validarCampos ()
  {
    if (nomeTitularJtf.getText ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite O Nome Do Titular A Levantar","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if (valorLevantaJtf.getText ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite O Valor A Levantar","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if (dataLevantarJtfd.getDTestField ().getText ().isEmpty ())
    {
      JOptionPane.showMessageDialog (null,"Error, Digite A Data A Levantar","Error",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    return true;
  }

  public void limparFormulario()
  {
    dataLevantarJtfd.setDtestField("");
    nomeTitularJtf.setText("");
    valorLevantaJtf.setText("");
  }//Fim do metodo limparFormulario()--------------------------------------------------------

  public JComboBox ordenarComboBox ( Vector vectorItens)
  {
    Collections.sort ( vectorItens );

    return new JComboBox ( vectorItens );
  }//Fim do metodo ordenarComboBox()
  private class TrataEventos implements ActionListener
  {
      public void actionPerformed(ActionEvent evento)
      {
          if (evento.getSource() == okJb)
          {
              levantamentoConta ();
          }//Fim Botao Salvar--------------------------------------------------------

          else if (evento.getSource() == cancelJb)
          {
              dispose();
          }//Fim Botao cancelar--------------------------------------------------------

          else if (evento.getSource() == limparJb)
          {
              limparFormulario();
          }//Fim Botao Limpar -------------------------------------------------------
      }
    }//Fim Da Classe TrataEventos -----------------------------------------------------
}
