import java.io.Serializable;

public class NumModelo implements Serializable{
    int numCliente, numConta, numPessoa, numFuncionario;

    public NumModelo(int numPessoa, int numFuncionario, int numCliente, int numConta){
        this.numCliente = numCliente;
        this.numConta = numConta;
        this.numPessoa= numPessoa;
        this.numFuncionario = numFuncionario;
    }

    public NumModelo(){
        this(1,1,1,1);
    }


    public void setNumFuncionario(int num){
        this.numFuncionario = num;
    }

    public int getNumFuncionario()
    {
        return this.numFuncionario;
    }

    public void setNumPessoa(int num){
        this.numPessoa = num;
    }

    public int getNumPessoa()
    {
        return this.numPessoa;
    }

    public void setNumCliente(int num){
        this.numCliente = num;
    }

    public int getNumCliente(){
        return this.numCliente;
    }

    public void setNumConta(int num){
        this.numConta = num;
    }

    public int getNumConta(){
        return this.numConta;
    }
}
