public class Index_General
{
  int posicao;
  
  public Index_General(int pos)
  {
    posicao = pos;
  }
  public String toString()
  {
    return "" + posicao;
  }
  public int get_Posicao()
  { return posicao; }
}
