
public interface ClearInterface
{
  public void clear();
}
