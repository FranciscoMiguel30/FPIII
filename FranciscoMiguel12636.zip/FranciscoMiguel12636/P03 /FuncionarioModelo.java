/*******************************************************************************************************************
********************************************************************************************************************
**
**	Nome do ficheiro: FuncionarioModelo.java
**	Objectivo: Preparar Os Dados Para mandar para o ficheiro
**  Nome: Francisco André Miguel
**	Data: 15 de Junho de 2016
**	Numero: 12636
**
*********************************************************************************************************************
********************************************************************************************************************/



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.*;
import java.util.*;
import yb.hashtableyb.GravadorGenericoHT;
import java.io.RandomAccessFile;
import java.io.IOException;
import yb.hashtableyb.*;

public class FuncionarioModelo extends Pessoa implements Gravavel
{
	private StringBufferModelo codigoFuncionario;
	
	public FuncionarioModelo()
	{
		this("","","", "", "", "","","","","","","","","","","","","","","");
	}


	public FuncionarioModelo(String codigoFuncionario,String numeroBi,String apelido, String nomeCompleto, String numeroDeContribuinte,String dominioEmail,
											 String estadoCivil,String dataDeNascimento, String provincia, String municipio, String bairro,
											 String nomeDoPai, String nomeDaMae, String nacionalidade, String email, String sexo, String telefone,
											 String documentoId,String dataEmissao,String habilitacao)
  {
			super (numeroBi,apelido,nomeCompleto,numeroDeContribuinte,dominioEmail,estadoCivil,dataDeNascimento,provincia,
						  municipio,bairro,nomeDoPai,nomeDaMae,nacionalidade,email,sexo,telefone,documentoId,dataEmissao,
							habilitacao);
				setCodigoFuncionario (codigoFuncionario);
  }

	public void setCodigoFuncionario(String codigoFuncionario) {
		this.codigoFuncionario = new StringBufferModelo(codigoFuncionario, 50);
	}

	//---------------------! Area dos Gets !------------------------

	public String getCodigoFuncionario() {
		return codigoFuncionario.toStringEliminatingSpaces();
	}

	//-------------! Implementação Interface Gravavel !--------
	public Gravavel getNovaInstancia ()
	{
	   return new FuncionarioModelo();
	}

	public int getSizeof ()
	{
		return (19 * 100); //(18*50 ) = 1604
	}

	public Object getChave (){
		return getCodigoFuncionario	();
	}

	public void gravarRegisto(  RandomAccessFile stream ) throws IOException
	{
		codigoFuncionario.write(stream);
		numeroBi.write(stream);
		nomeCompleto.write(stream);
		apelido.write(stream);
		numeroDeContribuinte.write(stream);
		estadoCivil.write(stream);
		dataDeNascimento.write(stream);
		provincia.write(stream);
		municipio.write(stream);
		bairro.write(stream);
		nomeDoPai.write(stream);
		nomeDaMae.write(stream);
		nacionalidade.write(stream);
		email.write(stream);
		sexo.write(stream);
		telefone.write(stream);
		dataEmissao.write(stream);
		documentoId.write(stream);
		habilitacao.write(stream);
	}

	public void lerRegisto( RandomAccessFile stream ) throws IOException
	{
		codigoFuncionario.read(stream);
		numeroBi.read(stream);
		nomeCompleto.read(stream);
		apelido.read(stream);
		numeroDeContribuinte.read(stream);
		estadoCivil.read(stream);
		dataDeNascimento.read(stream);
		provincia.read(stream);
		municipio.read(stream);
		bairro.read(stream);
		nomeDoPai.read(stream);
		nomeDaMae.read(stream);
		nacionalidade.read(stream);
		email.read(stream);
		sexo.read(stream);
		telefone.read(stream);
		dataEmissao.read(stream);
		documentoId.read(stream);
		habilitacao.read(stream);
	}

	public void gravarRegistoVazio( RandomAccessFile stream ) throws IOException
	{
		setCodigoFuncionario ("");
		setNumeroBi ("");
		setApelido ("");
		setNomeCompleto ("");
		setNumeroDeContribuinte ("");
		setEstadoCivil ("");
		setDataDeNascimento ("");
		setProvincia ("");
		setMunicipio ("");
		setBairro ("");
		setNomeDoPai ("");
		setNomeDaMae ("");
		setNacionalidade ("");
		setEmail ("");
		setSexo ("");
		setTelefone ("");
		setDocumentoId ("");
		setDataEmissao ("");
		setHabilitacao ("");

		try
    	{
    		gravarRegisto(stream);
    	}
    	catch (Exception ex)
    	{
    		JOptionPane.showMessageDialog (null, "Erro ao tentar gravar o Funcionario vazio. Erro do tipo: "+ex);
    	}
	}

	public String toString()
	{
		String str = "---! Armazenando os dados no Ficheiro dos Clientes !---\n";
		str += "Codigo :                 " + getNumeroBi() +"\n";
		str += "Nome Completo:           " + getNomeCompleto() +"\n";
		str += "Numero de Contribuinte:  " + getNumeroDeContribuinte() +"\n";
		str += "Estado Civil:            " + getEstadoCivil() +"\n";
		str += "Data de Nascimento:      " + getDataDeNascimento() +"\n";
		str += "Provincia:               " + getProvincia() +"\n";
		str += "Municipio:               " + getMunicipio() +"\n";
		str += "bairro:                  " + getBairro() +"\n";
		str += "Nome do Pai:             " + getNomeDoPai() +"\n";
		str += "Nome da Mae:             " + getNomeDaMae() +"\n";
		str += "Nacionalidade:           " + getNacionalidade() +"\n";
		str += "Sexo:                    " + getSexo() +"\n";
		str += "Telefone:                " + getTelefone() +"\n";
		return str;
	}
}
